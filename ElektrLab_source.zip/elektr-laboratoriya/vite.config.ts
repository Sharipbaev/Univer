import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  server: { allowedHosts: true },
  build: {
    emptyOutDir: true,
    chunkSizeWarningLimit: 1800,
    rollupOptions: {
      output: { manualChunks: { 'three-vendor': ['three', '@react-three/fiber', '@react-three/drei'], 'charts': ['recharts'], 'math': ['katex'] } }
    }
  }
});
