# ElektrLab — bajarilgan tekshiruvlar

## Avtomatik tekshiruv

- `npm run check`: TypeScript kompilyatsiyasi muvaffaqiyatli.
- `npm test`: **33/33 test**, 3 ta fayl: fizika19, baholash/holat7, hisobot7.
- `npm run build`: Vite ishlab chiqarish buildi muvaffaqiyatli.
- Nazariyadagi barcha formulalar, kattalik belgilarining KaTeX sintaksisi va 13 qurilma formulasi strict rejimda tekshirildi.

Fizik tekshiruvlar: uch fazali MW/MVAr/kV/kA birliklari, R/X/G/B, nominal π va T parametrlar, AD−BC=1, yo‘qotishsiz uzun liniya, Y=0 va Z=0 chegaralari, ekstremal kiritishlar, son kiritish va javob toleransi. Barcha 30 variantning fizik mantiqliligi hamda javoblarining mustaqil bazasi tekshirildi.

Hisobot sinovlari: to‘liq va anonim holatning JSON aylanmasi, soxta ball/`correct` maydonlarini rad etib qayta hisoblash, 30×5 sonli javob, vergulli va ilmiy yozuv, noto‘g‘ri fayl/ID/schema/hajmni rad etish.

## Brauzerda bajarilgan amaliy sinovlar

| Sinov | Kuzatilgan natija |
|---|---|
| Bosh sahifa va navigatsiya | Sakkiz sahifa ochildi; ortga qaytish boshqaruvi mavjud |
| Kalkulyator uzunligi80→160km | R, X, ΔU va ΔP ikki baravar, tok o‘zgarmadi |
| U maydonini bo‘sh qoldirish | Natija yashirildi, tushunarli xabar, eksport o‘chirildi |
| P–Q etalon: P30,Q40,U100,R10,X20 | I0.2887kA, ΔU11kV, ΔP2.5MW chiqdi |
| π sxemada B elementiga bosish | B izohi ochildi, ikkala B/2 ajratildi |
| T va uzun modelga o‘tish | R/2,X/2 joylashuvi va ABCD/natijalar yangilandi |
| Nazariya mini-testi | Javob izohi va20/12 ball ulushi saqlandi |
| Ism orqali variant | «Sinov Talabasi» uchun24-variant barqaror biriktirildi |
| Xato R javobi | Noto‘g‘ri xabar va yo‘naltiruvchi ko‘rsatma chiqdi |
| R uchun10,2 javobi | Vergul qabul qilindi,8ball yozildi |
| Sahifani qayta yuklash | Ism, variant, javob va ball saqlandi |
| Individual sxema/tahlil | To‘g‘ri sxema va uzunlik ta’siri uchun izoh chiqdi |
| Yakuniy nazariy test | To‘g‘ri javobga2ball, izoh va savol holati yangilandi |
| JSON yuklab olish va qayta import | Fayl yaratildi, tasdiqdan keyin holat tiklandi, javoblar qayta tekshirildi |
| 24 mustaqil masala | Masalalar tanlovi, yechilgan namuna va javob maydoni ochildi |
| 3D geometriyaga bevosita bosish | Panjarali tayanch raycaster orqali tanlandi |
| Qurilma ro‘yxati | Izolyator/balandlik tanlandi, izoh va formulalar ochildi |
| Liniyani yoqish/yuklama | Rangli oqim va110kV,209.95A,36MW (120%) ko‘rsatildi |
| Balandlik18→20m | Sim va balandlik ko‘rsatkichi o‘zgardi |
| Laboratoriya vazifalari | Shartlar bajarilganda4/4 va20ball yozildi |
| 3D fokus/reset/aylantirish/masshtab | Perspektiv ko‘rinish o‘zgardi va umumiy kamera tiklandi |
| Mobil390px iframe | Menyu ochildi, sahifa o‘tdi,375px foydali kenglikda content375px: gorizontal chiqish yo‘q |

## Tekshiruvning chegaralari

Sinovdagi bulut brauzeri WebGL2 taqdim etmadi; shu sabab haqiqiy Three.js SVGRenderer 3D rejimi brauzerda tekshirildi. WebGL/R3F rejimi TypeScript va geometrik hisoblar bilan tekshirildi; uni turli GPU, Safari va jismoniy Android/iOS qurilmalarida alohida sinash ushbu muhitda bajarilmadi. Mobil tekshiruv390px iframe viewportida o‘tkazildi, haqiqiy sensorli telefon qurilmasi ishlatilmadi.

O‘qituvchi PINi server autentifikatsiyasi emas. O‘qituvchi yechim ko‘rish va ball yozmaslik shartlari kod ko‘rigi/kompilyatsiyada tekshirildi; brauzerda shaxsiy hisobga kirish bajarilmadi. PDF/chop etish brauzer tizim dialogiga tayanadi; fizik printer natijasi tekshirilmagan.

GitHub Actions konfiguratsiyasi tayyor; foydalanuvchining GitHub hisobida repository yaratish yoki uning nomidan push qilish bajarilmadi. Loyihaning joriy hostingga joylashtirilishi Sites orqali amalga oshiriladi.

## Tekshiruvda topilib tuzatilgan masalalar

- Grafikdagi ayrim ekstremal nuqtalarni model chegarasi bo‘yicha tekshirish.
- Kichik quvvat koeffitsiyentida P–Q grafigining fizik izchilligi.
- O‘qituvchi rejimidan qaytilganda retrospektiv laboratoriya balli yozilishining oldini olish.
- Talaba/variant almashtirilganda avvalgi sonli javoblar aralashmasligi.
- Ism birinchi marta saqlanganda anonim o‘quv progressini saqlab qolish.
- WebGLsiz ishlaydigan haqiqiy3D alternativ renderer.
- SVG3D sahnada katta yer poligoni jihozlarni yopmasligi uchun chizish qatlamlari.

Hisobotda ko‘rsatilgan sinov holatlari haqiqiy talaba natijalari emas.
