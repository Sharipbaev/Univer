# ElektrLab — Elektr uzatish liniyalari

**Mavzu:** Elektr uzatish liniyalarining tuzilishi, almashtiruv sxemalari va ularning parametrlarini hisoblash.

O‘zbek tilida (lotin yozuvi) yaratilgan React + TypeScript veb-ta’lim platformasi. Vite statik build, React Three Fiber / Three.js 3D sahna, Recharts grafiklar va KaTeX formulalar ishlatiladi. Talaba ma’lumotlari shu brauzerdagi localStorage xotirasida saqlanadi. Backend talab qilinmaydi.

## Tez ishga tushirish

Node.js 22 yoki undan yangi mos LTS versiya va npm o‘rnating. Terminalni **package.json joylashgan papkada** oching:

```bash
npm ci
npm run dev
```

Terminal ko‘rsatgan manzilni oching, odatda `http://localhost:5173`. GitHub’dan olingan loyihada `npm ci` aynan package-lock.json dagi versiyalarni o‘rnatadi. Internet faqat birinchi paket o‘rnatish uchun kerak; tayyor build tashqi 3D model, shrift, CDN yoki API ga bog‘liq emas.

Tekshirish va tarqatiladigan build:

```bash
npm run check
npm test
npm run build
npm run preview
```

`npm run build` tayyor saytni `dist/` papkasiga chiqaradi. Brauzerda `index.html` ni `file://` orqali ikki marta bosib ochish o‘rniga HTTP server yoki hostingdan foydalaning. Brauzer ES-modullar uchun mahalliy fayl cheklovlarini qo‘llashi mumkin.

## Platforma bo‘limlari

| Manzil | Mazmuni |
|---|---|
| `#/` | Maqsad, o‘quv natijalari, ism-familiya, yo‘nalishlar va progress |
| `#/nazariya` | 12 batafsil mavzu, sxema, formulalar, birliklar, misollar va 12 mini-test |
| `#/laboratoriya` | 13 interaktiv 3D obyekt, manba/uzuvchi, yuklama, balandlik va 4 vazifa |
| `#/sxemalar` | R, R–X, nominal π, nominal T, aniq taqsimlangan uzun liniya modeli |
| `#/kalkulyator` | Tekshiriladigan parametrlar, jonli natijalar, bosqichli yechim, parametr grafigi va CSV |
| `#/masalalar` | Yechilgan namuna va 24 mustaqil masala |
| `#/variant` | Ismga mos 30 variantdan biri, 4 asosiy topshiriq, 5 baholanuvchi hisob |
| `#/natijalar` | 10 yakuniy test, umumiy ball, tavsiyalar, JSON/CSV va chop etish |

HashRouter ishlatiladi: har bir manzilga bevosita kirish va sahifani yangilash GitHub Pages’da ham 404 keltirib chiqarmaydi. Brauzerning ortga tugmasi va platformadagi ortga navigatsiya ishlaydi.

## Talaba uchun tartib

1. Bosh sahifada ism va familiyani kiriting, saqlang.
2. Nazariyadagi mavzular va mini-testlarni bajaring.
3. 3D laboratoriyada tayanch va izolyatorni ko‘ring; uzuvchi yopiq holatda manbani yoqing; yuklamani kamida 100% ga keltiring; balandlikni kamida 20 m qilib uning obyektini tanlang.
4. Sxemalarda R/X/G/B elementlarini bosing va π/T parametrlar taqsimotini taqqoslang.
5. Namunani o‘rganib, mustaqil masalalarda mashq qiling.
6. «Individual variant» sahifasida «Variant olish» ni bosing. R, X, I, ΔU, ΔP javoblarini kiriting; sxema tanlash va parametr ta’siri topshiriqlarini bajaring.
7. Yakuniy testni bajaring va hisobotni yuklab oling.

Javoblar ±1% nisbiy xatolik bilan tekshiriladi. To‘rtta ahamiyatli raqam tavsiya etiladi. Vergul yoki nuqta va `2.5e-7` kabi ilmiy yozuv qabul qilinadi. Son yoniga birlik yozmang. Mustaqil/individual yechim javob tekshirilgandan keyingina ochiladi; o‘qituvchi rejimida yechimlar ochiq.

### Variant biriktirish

Normallashtirilgan ism-familiya barqaror xesh orqali 1–30 oraliqqa moslanadi. Bir xil ismga bir xil variant beriladi; turli ismlarga bir xil variant tushishi ham mumkin. Bu universitet ro‘yxatidagi noyob ID bilan autentifikatsiya emas. Ismni almashtirish oldingi talabaning mahalliy natijalarini tozalaydi; oldin JSON hisobotni saqlang.

## O‘qituvchi rejimi

Yuqori o‘ngdagi «Talaba rejimi» tugmasini bosing. Standart namoyish PIN-kodi: **2468**.

PIN’ni o‘zgartirish uchun `.env.example` dan `.env.local` yarating:

```dotenv
VITE_TEACHER_PIN=ozingizning_kodingiz
```

Keyin loyihani qayta build qiling. `.env.local` Gitga kiritilmaydi. GitHub Actions’da o‘zgaruvchi kerak bo‘lsa, repository variable yoki secret orqali build bosqichiga uzating.

**Cheklov:** Vite’ning `VITE_` o‘zgaruvchilari tayyor JavaScript ichiga qo‘shiladi. Demak bu PIN kriptografik himoya yoki haqiqiy autentifikatsiya emas. O‘qituvchi rejimi dars namoyishi va yechimlarni oddiy interfeysda yashirish uchun. Server bo‘lmagan holda javoblar bazasi va ballarni o‘zgartirishdan to‘liq himoya qilishning iloji yo‘q. Rasmiy imtihon uchun serverda foydalanuvchi autentifikatsiyasi, javoblarni tekshirish va markaziy saqlash qo‘shilishi kerak.

O‘qituvchi istalgan 30 variantni ko‘ra oladi, barcha javoblar jadvalini ochadi va nazariy test izohlarini o‘qiydi. O‘qituvchi rejimidagi tekshiruvlar talaba ballini oshirmaydi. Qaytish tugmasi mavjud.

## Baholash

| Qism | Hisoblash usuli | Ball |
|---|---|---:|
| Nazariya | 12 ta to‘g‘ri mini-test ulushi × 20 | 20 |
| 3D laboratoriya | 4 amaliy shart × 5 | 20 |
| Hisoblash | Individual variantdagi R, X, I, ΔU, ΔP; har biri 8 | 40 |
| Yakuniy nazariy test | 10 savol × 2 | 20 |
| **Jami** | | **100** |

Hisoblashlar individual variant va natijalar sahifasida aynan bir xil holatga ulanadi; ikki marta ball yozilmaydi. So‘nggi tekshirilgan javob baholanadi. Bir tugmani takror bosish yoki laboratoriya vazifasini takrorlash qo‘shimcha ball bermaydi. 24 mustaqil mashq tayyorgarlik uchun, umumiy ballga qo‘shilmaydi. Sxema va tahlil mashqlari alohida fikr-mulohaza beradi; hisoblashning 40 balli beshta sonli javobga asoslanadi.

## Ma’lumotlar va hisobotlar

- Saqlash kaliti: `elektrlab.student.v1`.
- Backend, elektron pochta yuborish yoki tashqi tahlil kuzatuvchisi yo‘q.
- Boshqa qurilmaga avtomatik sinxronlash mavjud emas. JSON eksport → boshqa qurilmada JSON import orqali davom ettiriladi.
- JSON import hajm/tuzilma/IDlarni tekshiradi va test hamda hisoblash javoblarining to‘g‘riligini qayta hisoblaydi. Fayl ichidagi tayyor `scores` va `correct` qiymatlariga ishonmaydi.
- CSV o‘qituvchiga jadval shaklida topshirish uchun; ism maydonida elektron jadval formulasi boshlanishi zararsizlantiriladi.
- «Hisobotni chop etish» brauzerning bosma/PDF oynasini ochadi. PDF kerak bo‘lsa, «Save as PDF / PDF sifatida saqlash»ni tanlang.
- Brauzer xotirasi tozalansa, shaxsiy natija yo‘qoladi. Hisobotni oldindan yuklab oling. Brauzer xotirasiga yozish bloklansa, platforma xabar chiqaradi.

## Fizik model va birliklar

Tizim: muvozanatlangan uch fazali sinusoidal barqaror rejim, 50 Hz. Barcha qarshilik va o‘tkazuvchanliklar bir fazaning ekvivalent qiymatlari. `U` — qabul tomonidagi liniyalararo effektiv kV, `P` va `Q` — uch fazaning jami MW/MVAr qiymatlari.

```text
R = r₀·l [Ω]       X = x₀·l [Ω]
G = g₀·l [S]       B = b₀·l [S]
S = sqrt(P² + Q²) [MVA]
I = S / (sqrt(3)·U) [kA]
ΔU ≈ (P·R + Q·X) / U [kV]
ΔP = 3·I²·R [MW]
```

P–Q rejimida cosφ avtomatik topiladi. P–cosφ rejimida Q = ±P·tan(arccos(cosφ)): induktiv yuklama uchun musbat, sig‘imli uchun manfiy. I kA bo‘lsa, `3I²R` MW beradi; amper kerak bo‘lsa I ni 1000 ga ko‘paytiring.

Soddalashtirilgan ΔU va ΔP shunt toklarini hisobga olmaydi. π/T/uzun modelda kompleks fazorlar bilan `Vₛ = A·Vᵣ + B_ABCD·Iᵣ` va `Iₛ = C_ABCD·Vᵣ + D·Iᵣ` ishlatiladi. Fazaviy `Vᵣ = U/√3`, `Iᵣ = (P − jQ)/(√3 U)`. Jo‘natish quvvati `3Vₛ conjugate(Iₛ)` orqali topiladi.

| Model | A = D | B_ABCD | C_ABCD |
|---|---|---|---|
| R | 1 | R | 0 |
| R–X | 1 | Z | 0 |
| Nominal π | 1 + ZY/2 | Z | Y(1 + ZY/4) |
| Nominal T | 1 + ZY/2 | Z(1 + ZY/4) | Y |
| Uzun | cosh(γl) | Zc·sinh(γl) | sinh(γl)/Zc |

Bu yerda `Z = R + jX`, `Y = G + jB`, `γ = sqrt(zy)`, `Zc = sqrt(z/y)`. Uzun model nol Z yoki Y chegarasida barqaror limit ifodasi orqali hisoblanadi. Matritsadagi B_ABCD (Ω) sig‘im o‘tkazuvchanligi B (S) bilan bir xil kattalik emas.

0.001 ≤ U ≤ 1000 kV va 0.001 ≤ l ≤ 1000 km. P–cosφ rejimida 0.1 ≤ cosφ ≤ 1. Bo‘sh, manfiy (r₀/x₀/g₀/b₀), nol kuchlanish, cheksiz va model chegarasidan tashqari sonlar xabar bilan rad etiladi. Juda katta tushuvlar uchun yaqinlashuv cheklovi ko‘rsatiladi. Yuklama nol bo‘lsa cosφ aniqlanmaganligi tushuntiriladi.

### 3D sahnaning fizik talqini

Sahna qurilmalarni o‘rganish uchun ko‘rgazmali maket. Gorizontal masofa shartli masshtabda, simning asosiy oraliqdagi minimal balandligi slayderga mos. Transformatorlar nominal ideal vazifada; shamol, termik qizish, izolyatsiya muvofiqligi, avariya himoyasi va haqiqiy dinamik o‘tkinchi jarayonlar hisoblanmaydi. Qabul kuchlanishi 110 kV doimiy. O‘lchovlar yuklamaga qarab qayta hisoblanadi. Yorug‘lik zarrachalari energiya uzatilishini tushuntiradi, elektronlarning haqiqiy drift harakatini emas. Sim balandligini surish b₀ ni avtomatik aniqlamaydi.

Asosiy 3D rejim WebGL2 va React Three Fiber bilan ishlaydi. WebGL2 mavjud bo‘lmasa, platforma avtomatik **Three.js SVGRenderer** asosidagi «Mos 3D rejimi»ga o‘tadi. Unda ham perspektiv kamera, hajmli geometriya, aylantirish, masshtab, raycaster orqali obyekt tanlash va fokuslash mavjud; u GPU o‘rniga brauzer protsessoridan foydalanadi. Sichqoncha bilan aylantirish, g‘ildirak bilan masshtab va qurilmaga fokuslash mavjud. Telefonda bir barmoq aylantiradi, ikki barmoq masshtabni boshqaradi. Mos rejimda SVG ustida strelka, +/− va C tugmalari ham ishlaydi. Nazariya, sxema va hisoblashlar 3D sahnadan mustaqil.

## GitHub Pages’ga joylashtirish

1. GitHub’da yangi repository oching, masalan `elektr-laboratoriya`.
2. **Loyiha papkasi ichidagi fayllarni** repository ildiziga joylashtiring: `package.json`, `package-lock.json`, `src/`, `public/`, `vite.config.ts`, `.github/workflows/deploy.yml` va qolgan konfiguratsiya fayllari. `node_modules` ni yuklamang.
3. Repository **Settings → Pages → Build and deployment → Source → GitHub Actions** ni tanlang.
4. `main` branchga push qiling. Tayyor workflow `npm ci`, `npm test`, `npm run build` ni bajarib `dist/` ni Pages’ga joylashtiradi.
5. **Actions** bo‘limida barcha bosqichlar yashil bo‘lgach, **Settings → Pages** dagi manzilni nusxalang. Odatdagi shakl: `https://FOYDALANUVCHI.github.io/REPOSITORY/`.
6. Shu havolani talabalarga yuboring. Alohida bo‘lim havolasi: `https://FOYDALANUVCHI.github.io/REPOSITORY/#/laboratoriya`.

`vite.config.ts` da `base: './'` va HashRouter ishlatilgani sabab repository nomi yoki ildiz hosting manzili almashsa ham nisbiy asset manzillari moslashadi. Workflow’dagi branch sizda `master` bo‘lsa, uni mos ravishda o‘zgartiring. `.openai/hosting.json` Sites’ga tegishli; GitHub Pages ishlashi uchun talab qilinmaydi va mavjud Site ID’sini yangi loyihaga ko‘chirmaslik kerak.

Terminaldan yangi GitHub repositoryga yuklash (URLni o‘zingiznikiga almashtiring):

```bash
git init
git add .
git commit -m "ElektrLab birinchi versiya"
git branch -M main
git remote add origin https://github.com/FOYDALANUVCHI/elektr-laboratoriya.git
git push -u origin main
```

Agar Git repository allaqachon mavjud bo‘lsa, qayta `git init` yoki mavjud remote’ni o‘zgartirish shart emas; holatni tekshirib mos push buyrug‘ini ishlating. Tayyor source arxivida Git tarixi va Sites maxsus identifikatori yo‘q.

## Boshqa statik hosting

`npm run build` dan so‘ng **dist papkasining barcha tarkibini**, shu jumladan `assets/` va shriftlarni hostingga yuklang. Faqat `index.html` ning o‘zi yetmaydi. Netlify yoki Cloudflare Pages kabi xizmatda build command `npm run build`, output directory `dist`, Node 22 belgilanishi mumkin. ZIP bilan yuklashni qo‘llaydigan hostingda tayyor statik arxivni ochib ishlating. Mahalliy tekshirish uchun `npm run preview` faqat preview server; ishlab chiqarish hostingining o‘rnini bosmaydi.

## Kod tuzilmasi

```text
src/
  App.tsx                    Navigatsiya, talaba/o‘qituvchi rejimi
  main.tsx                   React, HashRouter va saqlash konteksti
  styles.css                 Responsiv umumiy dizayn
  components/
    LabScene.tsx             Protseduraviy 3D sahna va kamera
    LabSceneSVG.tsx          WebGLsiz brauzerlar uchun Three.js 3D renderer
    CircuitDiagram.tsx       Besh interaktiv elektr sxemasi
    TheoryDiagram.tsx        O‘quv vektor sxemalari
    LineForm.tsx             Kirish maydonlari va tekshirish
    ParameterChart.tsx       Parametr ta’siri grafigi
    CalculationSteps.tsx     Formula va sonli yechim bosqichlari
    CalculationAssessment.tsx 5 baholanuvchi hisoblash topshirig‘i
    QuestionCard.tsx         Mini-test va yakuniy test kartasi
    UI.tsx                   Formula, xabar, metrika va progress
  data/
    curriculum.ts            12 mavzu, 30 variant, 24 masala, 10 test
    equipment.ts             13 qurilma ma’lumotlari
  lib/
    physics.ts               Birliklar, hisoblash, kompleks ABCD
    physics.test.ts          Fizik invariant va birlik testlari
    store.tsx                Talaba holati, variant xeshi, baholash
    store.test.ts            Baholash va variant sinovlari
    report.ts                JSON/CSV eksport va tekshirilgan import
    report.test.ts           Natijalarni qurilmalar o‘rtasida ko‘chirish sinovlari
  pages/                     Sakkiz alohida sahifa
.github/workflows/deploy.yml GitHub Pages avtomatik joylashtirish
```

## Tekshirish va texnik manbalar

`npm test` birliklar, R/X/G/B, 1% javob toleransi, nol qiymatli limitlar, π/T ABCD, AD−BC = 1, taqsimlangan model, variantlarning fizik mantiqliligi, baholash va ismga variant biriktirishni tekshiradi. `npm run build` barcha TypeScript modullarini ham tekshiradi. Bajarilgan brauzer tekshiruvlari `QA.md` faylida qayd etilgan.

- [NPTEL — Transmission Line Models](https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_1.html)
- [NPTEL — Nominal π](https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_4.html)
- [NPTEL — Nominal T](https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_5.html)
- [NPTEL — Long line model](https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_6.html)
- [Vite — Static deployment va GitHub Pages](https://vite.dev/guide/static-deploy)
- [Three.js — OrbitControls](https://threejs.org/docs/pages/OrbitControls)

Variantlardagi sonlar o‘quv uchun tuzilgan, haqiqiy tarmoqdan olingan tajriba ma’lumotlari sifatida taqdim etilmaydi.

