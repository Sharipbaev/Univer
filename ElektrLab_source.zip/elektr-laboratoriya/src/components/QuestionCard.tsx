import { useState } from 'react';
import { Check, HelpCircle } from 'lucide-react';
import { Notice } from './UI';
import type { ChoiceAnswer } from '../lib/store';
export type Question = { prompt: string; options: string[]; correct: number; explanation: string };
export default function QuestionCard({ question, saved, onCheck, teacher = false, number }: { question: Question; saved?: ChoiceAnswer; onCheck: (answer: ChoiceAnswer) => void; teacher?: boolean; number?: number }) {
  const [selected, setSelected] = useState<number | null>(saved?.selected ?? null);
  const [checked, setChecked] = useState(!!saved);
  const [error, setError] = useState(false);
  return <div className="question-card"><div className="question-title"><span className="question-number">{number ?? <HelpCircle size={18}/>}</span><h3>{question.prompt}</h3></div><div className="question-options" role="radiogroup" aria-label={question.prompt}>{question.options.map((option, i) => <button key={i} role="radio" aria-checked={selected === i} className={`choice ${selected === i ? 'chosen' : ''} ${(checked || teacher) && question.correct === i ? 'correct' : ''} ${checked && selected === i && selected !== question.correct ? 'incorrect' : ''}`} onClick={() => { setSelected(i); setChecked(false); setError(false); }}><span>{String.fromCharCode(65 + i)}</span>{option}{(checked || teacher) && question.correct === i && <Check size={17}/>}</button>)}</div>{error && <p className="field-error">Avval bitta javobni tanlang.</p>}<button className="btn secondary" onClick={() => { if (selected === null) { setError(true); return; } setChecked(true); if (!teacher) onCheck({ selected, correct: selected === question.correct }); }}>Javobni tekshirish</button>{(checked || teacher) && <Notice kind={teacher || selected === question.correct ? 'success' : 'warning'}><strong>{teacher ? 'O‘qituvchi uchun izoh. ' : selected === question.correct ? 'To‘g‘ri! ' : 'Qayta o‘ylab ko‘ring. '}</strong>{question.explanation}</Notice>}</div>;
}
