import { useId, useState } from 'react';
import type { KeyboardEvent, ReactNode } from 'react';

export type CircuitKind = 'r' | 'short' | 'pi' | 't' | 'long';

export interface CircuitDiagramProps {
  kind: CircuitKind;
  R: number;
  X: number;
  G: number;
  B: number;
  selected?: string | null;
  onSelect?: (id: string) => void;
  compact?: boolean;
}

const INK = '#36546e';
const ACCENT = '#087f75';
const BLUE = '#3975d8';
const titles: Record<CircuitKind, string> = {
  r: 'Aktiv qarshilikli model',
  short: 'Qisqa liniyaning R–X modeli',
  pi: 'π-simon almashtiruv sxemasi',
  t: 'T-simon almashtiruv sxemasi',
  long: 'Taqsimlangan parametrli uzun liniya',
};
const names: Record<string, string> = {
  R: 'Aktiv qarshilik',
  X: 'Induktiv qarshilik',
  G: 'Aktiv o‘tkazuvchanlik',
  B: 'Sig‘im o‘tkazuvchanligi',
};

function valueText(value: number, unit: string) {
  if (!Number.isFinite(value)) return '—';
  if (unit === 'S' && Math.abs(value) < 0.001 && value !== 0) {
    return `${Number((value * 1e6).toPrecision(4))} µS`;
  }
  return `${Number(value.toPrecision(4))} ${unit}`;
}

function Wire({ x1, y1, x2, y2 }: { x1: number; y1: number; x2: number; y2: number }) {
  return <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={INK} strokeWidth={2} />;
}

function Node({ x, y }: { x: number; y: number }) {
  return <circle cx={x} cy={y} r={4} fill={INK} />;
}

function Ground({ x, y }: { x: number; y: number }) {
  return <g stroke={INK} strokeWidth={2}>
    <line x1={x} y1={y} x2={x} y2={y + 9} />
    <line x1={x - 12} y1={y + 9} x2={x + 12} y2={y + 9} />
    <line x1={x - 8} y1={y + 15} x2={x + 8} y2={y + 15} />
    <line x1={x - 4} y1={y + 21} x2={x + 4} y2={y + 21} />
  </g>;
}

/**
 * One-phase line-to-neutral equivalents. R/X are series values per phase;
 * G/B are phase-to-neutral shunt admittances. π splits Y, T splits Z.
 */
export default function CircuitDiagram({ kind, R, X, G, B, selected, onSelect, compact = false }: CircuitDiagramProps) {
  const [localSelected, setLocalSelected] = useState<string | null>(null);
  const active = selected === undefined ? localSelected : selected;
  const titleId = useId();
  const descId = useId();
  const seriesY = 112;
  const returnY = 284;

  function activate(id: string) {
    setLocalSelected(id);
    onSelect?.(id);
  }

  function keyboard(event: KeyboardEvent<SVGGElement>, id: string) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      activate(id);
    }
  }

  function element(id: string, label: string, value: number, x: number, y: number, symbol: ReactNode, vertical = false, small = false) {
    const isActive = active === id;
    const unit = id === 'R' || id === 'X' ? 'Ω' : 'S';
    const width = small ? 68 : vertical ? 94 : 112;
    return <g
      key={`${id}-${x}-${y}`}
      className="circuit-element"
      transform={`translate(${x},${y})`}
      role="button"
      tabIndex={0}
      aria-label={`${names[id]}: ${label} = ${valueText(value, unit)}. Izohni ochish.`}
      aria-pressed={isActive}
      onClick={() => activate(id)}
      onKeyDown={(event) => keyboard(event, id)}
      style={{ cursor: 'pointer', outline: 'none' }}
    >
      <title>{`${names[id]} · ${label} = ${valueText(value, unit)}`}</title>
      <rect
        className="circuit-hit"
        x={-width / 2}
        y={vertical ? -46 : -54}
        width={width}
        height={vertical ? 118 : 105}
        rx={10}
        fill={isActive ? '#ddf6ec' : '#ffffff'}
        fillOpacity={isActive ? 0.25 : 0.02}
        stroke={isActive ? ACCENT : 'transparent'}
        strokeWidth={1.5}
      />
      <g stroke={isActive ? ACCENT : BLUE} strokeWidth={2.4} fill="#ffffff">{symbol}</g>
      {vertical ? <>
        <text x={-19} y={-3} textAnchor="end" fill={isActive ? ACCENT : INK} fontWeight={700} fontSize={small ? 10.5 : 12}>{label}</text>
        <text x={-19} y={14} textAnchor="end" fill="#64778b" fontSize={small ? 8.5 : 10}>{valueText(value, unit)}</text>
      </> : <>
        <text x={0} y={-29} textAnchor="middle" fill={isActive ? ACCENT : INK} fontWeight={700} fontSize={small ? 12 : 14}>{label}</text>
        <text x={0} y={35} textAnchor="middle" fill="#64778b" fontSize={small ? 10 : 12}>{valueText(value, unit)}</text>
      </>}
    </g>;
  }

  function resistor(x: number, value: number, label = 'R', small = false) {
    return element('R', label, value, x, seriesY, <>
      <line x1={-34} y1={0} x2={-23} y2={0} />
      <rect x={-23} y={-10} width={46} height={20} rx={1} />
      <line x1={23} y1={0} x2={34} y2={0} />
    </>, false, small);
  }

  function inductor(x: number, value: number, label = 'jX', small = false) {
    return element('X', label, value, x, seriesY, <>
      <line x1={-34} y1={0} x2={-24} y2={0} />
      <path d="M -24 0 C -24 -20,-12 -20,-12 0 C -12 -20,0 -20,0 0 C 0 -20,12 -20,12 0 C 12 -20,24 -20,24 0" fill="none" />
      <line x1={24} y1={0} x2={34} y2={0} />
    </>, false, small);
  }

  function shunt(center: number, divisor: number, labelSuffix: string, small = false) {
    const dx = small ? 34 : 48;
    const left = center - dx;
    const right = center + dx;
    const symbolY = 190;
    const gLabel = divisor === 1 ? 'G' : `G/${labelSuffix}`;
    const bLabel = divisor === 1 ? 'jB' : `jB/${labelSuffix}`;
    return <g key={`shunt-${center}`}>
      <Wire x1={center} y1={seriesY} x2={center} y2={145} />
      <Wire x1={left} y1={145} x2={right} y2={145} />
      <Wire x1={left} y1={145} x2={left} y2={symbolY - 25} />
      <Wire x1={right} y1={145} x2={right} y2={symbolY - 25} />
      <Wire x1={left} y1={symbolY + 25} x2={left} y2={returnY} />
      <Wire x1={right} y1={symbolY + 25} x2={right} y2={returnY} />
      <Node x={center} y={seriesY} />
      <Node x={left} y={returnY} /><Node x={right} y={returnY} />
      {element('G', gLabel, G / divisor, left, symbolY, <>
        <line x1={0} y1={-25} x2={0} y2={-17} />
        <rect x={-9} y={-17} width={18} height={34} rx={1} />
        <line x1={0} y1={17} x2={0} y2={25} />
      </>, true, small)}
      {element('B', bLabel, B / divisor, right, symbolY, <>
        <line x1={0} y1={-25} x2={0} y2={-6} />
        <line x1={-14} y1={-6} x2={14} y2={-6} />
        <line x1={-14} y1={6} x2={14} y2={6} />
        <line x1={0} y1={6} x2={0} y2={25} />
      </>, true, small)}
    </g>;
  }

  const isLong = kind === 'long';
  let branches: ReactNode;
  if (kind === 'r') {
    branches = <>
      <Wire x1={66} y1={seriesY} x2={366} y2={seriesY} />
      <Wire x1={434} y1={seriesY} x2={734} y2={seriesY} />
      {resistor(400, R)}
      <text x={400} y={211} textAnchor="middle" fontSize={13} fill="#64778b">X, G va B bu soddalashtirishda hisobga olinmaydi.</text>
    </>;
  } else if (kind === 'short') {
    branches = <>
      <Wire x1={66} y1={seriesY} x2={286} y2={seriesY} />
      <Wire x1={354} y1={seriesY} x2={446} y2={seriesY} />
      <Wire x1={514} y1={seriesY} x2={734} y2={seriesY} />
      {resistor(320, R)}{inductor(480, X)}
      <text x={400} y={211} textAnchor="middle" fontSize={13} fill="#64778b">Z = R + jX · ko‘ndalang o‘tkazuvchanlik e’tiborga olinmaydi.</text>
    </>;
  } else if (kind === 'pi') {
    branches = <>
      <Wire x1={66} y1={seriesY} x2={300} y2={seriesY} />
      <Wire x1={368} y1={seriesY} x2={432} y2={seriesY} />
      <Wire x1={500} y1={seriesY} x2={734} y2={seriesY} />
      {shunt(168, 2, '2')}{shunt(632, 2, '2')}
      {resistor(334, R)}{inductor(466, X)}
      <text x={400} y={224} textAnchor="middle" fontSize={13} fill="#64778b">Y = G + jB</text>
      <text x={400} y={244} textAnchor="middle" fontSize={12} fill="#64778b">har bir chetda Y/2</text>
    </>;
  } else if (kind === 't') {
    branches = <>
      <Wire x1={66} y1={seriesY} x2={146} y2={seriesY} />
      <Wire x1={214} y1={seriesY} x2={266} y2={seriesY} />
      <Wire x1={334} y1={seriesY} x2={466} y2={seriesY} />
      <Wire x1={534} y1={seriesY} x2={586} y2={seriesY} />
      <Wire x1={654} y1={seriesY} x2={734} y2={seriesY} />
      {resistor(180, R / 2, 'R/2')}{inductor(300, X / 2, 'jX/2')}
      {resistor(500, R / 2, 'R/2')}{inductor(620, X / 2, 'jX/2')}
      {shunt(400, 1, '')}
    </>;
  } else {
    const cells = [178, 394, 610];
    branches = <>
      <Wire x1={66} y1={seriesY} x2={110} y2={seriesY} />
      {cells.map((center, index) => <g key={center}>
        <rect x={center - 75} y={56} width={210} height={239} rx={12} fill="none" stroke="#dce6ee" strokeDasharray="4 5" />
        <Wire x1={center - 68} y1={seriesY} x2={center - 62} y2={seriesY} />
        <Wire x1={center + 6} y1={seriesY} x2={center + 10} y2={seriesY} />
        <Wire x1={center + 78} y1={seriesY} x2={index === 2 ? 734 : center + 154} y2={seriesY} />
        {resistor(center - 28, R / 3, 'R/3', true)}
        {inductor(center + 44, X / 3, 'jX/3', true)}
        {shunt(center + 80, 3, '3', true)}
        <text x={center + 30} y={315} textAnchor="middle" fill="#64778b" fontSize={11}>{index + 1}-bo‘lak · Δl = l/3</text>
      </g>)}
    </>;
  }

  return <figure className="circuit-diagram" style={{ margin: 0, width: '100%' }}>
    <svg
      viewBox={`0 0 800 ${isLong ? 364 : 344}`}
      width="100%"
      style={{ display: 'block', overflow: 'visible', fontFamily: 'inherit' }}
      role="group"
      aria-labelledby={`${titleId} ${descId}`}
    >
      <title id={titleId}>{titles[kind]}</title>
      <desc id={descId}>Bir fazaning neytralga nisbatan almashtiruv sxemasi. Parametr belgilarini bosib izohni oching. {kind === 'pi' ? 'R va X ketma-ket, G/2 va B/2 har ikki uchda parallel ulangan.' : kind === 't' ? 'R/2 va X/2 ikkala ketma-ket yelkada, G va B o‘rtada parallel ulangan.' : ''}</desc>
      <style>{`.circuit-diagram .circuit-element:hover .circuit-hit { fill: #d8f1e9; fill-opacity: .25; stroke: #79bfb7; } .circuit-diagram .circuit-element:focus .circuit-hit { stroke: #087f75; stroke-width: 2.5; fill: #d8f1e9; fill-opacity: .25; }`}</style>
      <rect x={0} y={0} width={800} height={isLong ? 364 : 344} rx={18} fill="#f7fafc" />
      {!compact && <>
        <text x={26} y={30} fill={INK} fontSize={14} fontWeight={650}>{titles[kind]}</text>
        <text x={774} y={30} textAnchor="end" fill="#64778b" fontSize={11}>Bir faza · 50 Hz</text>
      </>}
      <Wire x1={66} y1={returnY} x2={734} y2={returnY} />
      {branches}
      <Node x={66} y={seriesY} /><Node x={734} y={seriesY} />
      <Node x={66} y={returnY} /><Node x={734} y={returnY} />
      <text x={32} y={197} textAnchor="middle" fill={BLUE} fontSize={13} fontWeight={650}>U₁φ</text>
      <text x={768} y={197} textAnchor="middle" fill={BLUE} fontSize={13} fontWeight={650}>U₂φ</text>
      <path d="M 52 129 L 52 269 L 48 261 M 52 269 L 56 261" stroke={BLUE} strokeWidth={1.3} fill="none" />
      <path d="M 748 129 L 748 269 L 744 261 M 748 269 L 752 261" stroke={BLUE} strokeWidth={1.3} fill="none" />
      <path d="M 76 95 H 106 l -7 -4 m 7 4 l -7 4" stroke={BLUE} strokeWidth={1.6} fill="none" />
      <path d="M 694 95 H 724 l -7 -4 m 7 4 l -7 4" stroke={BLUE} strokeWidth={1.6} fill="none" />
      <text x={90} y={84} textAnchor="middle" fill={BLUE} fontSize={12}>I₁</text>
      <text x={708} y={84} textAnchor="middle" fill={BLUE} fontSize={12}>I₂</text>
      <Ground x={76} y={returnY} />
      <text x={107} y={312} fill="#64778b" fontSize={11}>N · neytral</text>
      {!isLong && <text x={774} y={324} textAnchor="end" fill="#64778b" fontSize={11}>Uφ = U / √3</text>}
      {isLong && <text x={400} y={347} textAnchor="middle" fill="#64778b" fontSize={11}>3 bo‘lak ko‘rgazma uchun chizilgan; aniq uzun liniya hisobi uzluksiz taqsimlangan modelga asoslanadi.</text>}
    </svg>
    {!compact && <figcaption style={{ marginTop: 10, fontSize: 12, lineHeight: 1.6, color: '#667b8c' }}>
      R, X, G yoki B belgisini bosing. {kind === 'pi' ? 'Har bir chetdagi G/2 va jB/2 bir-biriga parallel: jami ko‘ndalang o‘tkazuvchanlik Y = G + jB.' : kind === 't' ? 'Har bir ketma-ket yelka Z/2 = R/2 + jX/2; markaziy ko‘ndalang tarmoq Y = G + jB.' : kind === 'long' ? 'R/3, X/3, G/3 va B/3 — teng uzunlikdagi uchta ko‘rgazmali bo‘lakning parametrlari. Bo‘laklar soni cheksiz orttirilganda taqsimlangan model olinadi.' : 'R va X bir fazaning to‘liq uzunlikdagi parametrlari. U₁φ va U₂φ faza kuchlanishlaridir.'}
    </figcaption>}
  </figure>;
}
