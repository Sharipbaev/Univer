import { calculateLine, type LineInput } from '../lib/physics';
import { Formula, fmt } from './UI';
export default function CalculationSteps({input}:{input:LineInput}){
  const r=calculateLine(input);const n=(v:number)=>Number(v.toPrecision(7));
  const steps=[
    {title:'Liniyaning to‘liq parametrlari',tex:String.raw`R=r_0l=${n(input.r0)}\cdot${n(input.l)}=${n(r.R)}\;\Omega`,extra:String.raw`X=x_0l=${n(input.x0)}\cdot${n(input.l)}=${n(r.X)}\;\Omega`,detail:`G = ${input.g0} × ${input.l} = ${r.G.toPrecision(5)} S; B = ${input.b0} × ${input.l} = ${r.B.toPrecision(5)} S.`},
    {title:'Reaktiv va to‘la quvvat',tex:input.powerMode==='pf'?String.raw`Q=${input.reactiveKind==='capacitive'?'-':''}P\tan(\arccos(\cos\varphi))=${n(r.Q)}\;\mathrm{MVAr}`:String.raw`\cos\varphi=\frac{P}{\sqrt{P^2+Q^2}}=${n(r.powerFactor)}`,extra:String.raw`S=\sqrt{${n(input.P)}^2+(${n(r.Q)})^2}=${n(r.S)}\;\mathrm{MVA}`,detail:'Induktiv yuklama uchun Q > 0, sig‘imli yuklama uchun Q < 0.'},
    {title:'Uch fazali liniya toki',tex:String.raw`I=\frac{\sqrt{P^2+Q^2}}{\sqrt{3}U}=\frac{${n(r.S)}}{\sqrt{3}\cdot${n(input.U)}}=${n(r.I)}\;\mathrm{kA}`,detail:`Natija amperda: I = ${fmt(r.I*1000,3)} A. MW/kV = kA ekanini esda tuting.`},
    {title:'Kuchlanish tushuvi',tex:String.raw`\Delta U\approx\frac{PR+QX}{U}=\frac{${n(input.P)}\cdot${n(r.R)}+(${n(r.Q)})\cdot${n(r.X)}}{${n(input.U)}}=${n(r.deltaU)}\;\mathrm{kV}`,detail:`Nisbiy o‘zgarish: ΔU/U × 100 = ${fmt(r.deltaUPercent,3)}%. Bu shunt toklarini va ko‘ndalang kuchlanish tarkibini tashlab ketuvchi yaqinlashuv.`},
    {title:'Uch fazali aktiv quvvat yo‘qotishi',tex:String.raw`\Delta P=3I^2R=3\cdot(${n(r.I)})^2\cdot${n(r.R)}=${n(r.deltaP)}\;\mathrm{MW}`,detail:`I kA va R Ω da bo‘lgani uchun ΔP MW da. Natija ${fmt(r.deltaP*1000,3)} kW. Shunt yo‘qotishlari bu formulaga kirmaydi.`}
  ];
  return <section className="panel calculation-steps"><div className="section-title"><h2>Yechim bosqichlari</h2><span className="pill">Birliklar tekshirildi</span></div>{steps.map((step,i)=><div className="solution-step" key={step.title}><span className="step-badge">{i+1}</span><div><h3>{step.title}</h3><Formula tex={step.tex}/>{step.extra&&<Formula tex={step.extra}/>}<p>{step.detail}</p></div></div>)}</section>;
}
