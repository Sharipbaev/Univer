import { useMemo, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { calculateLine, DEFAULT_INPUT, validateInput, type LineInput } from '../lib/physics';
import { fmt } from './UI';
type NumericKey = 'l'|'r0'|'x0'|'g0'|'b0'|'U'|'P'|'Q'|'cosPhi';
const initialRaw = (value: LineInput) => Object.fromEntries(['l','r0','x0','g0','b0','U','P','Q','cosPhi'].map(key=>[key,String(value[key as NumericKey])])) as Record<NumericKey,string>;
export function useLineInputs(initial = DEFAULT_INPUT) {
  const [raw, setRaw] = useState(initialRaw(initial));
  const [powerMode, setPowerMode] = useState<LineInput['powerMode']>(initial.powerMode);
  const [reactiveKind, setReactiveKind] = useState<LineInput['reactiveKind']>(initial.reactiveKind);
  const input = useMemo(() => ({...Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,v.trim()===''?NaN:Number(v.replace(',','.'))])),powerMode,reactiveKind}) as LineInput, [raw,powerMode,reactiveKind]);
  const errors = validateInput(input);
  const result = Object.keys(errors).length === 0 ? calculateLine(input) : null;
  function setValue(key: NumericKey, value:string) {setRaw(s=>({...s,[key]:value}));}
  function setInput(value:LineInput){setRaw(initialRaw(value));setPowerMode(value.powerMode);setReactiveKind(value.reactiveKind);}
  return { raw,input,errors,result,setValue,powerMode,setPowerMode,reactiveKind,setReactiveKind,setInput };
}
export type LineFormState = ReturnType<typeof useLineInputs>;
const fields: {key: NumericKey;label:string;unit:string;note?:string}[] = [
  {key:'l',label:'Liniya uzunligi l',unit:'km'}, {key:'U',label:'Qabul kuchlanishi U',unit:'kV',note:'Liniyalararo effektiv qiymat'},
  {key:'r0',label:'Aktiv qarshilik r₀',unit:'Ω/km'}, {key:'x0',label:'Induktiv qarshilik x₀',unit:'Ω/km'},
  {key:'g0',label:'Aktiv o‘tkazuvchanlik g₀',unit:'S/km'}, {key:'b0',label:'Sig‘im o‘tkazuvchanligi b₀',unit:'S/km'},
  {key:'P',label:'Aktiv quvvat P',unit:'MW'}, {key:'Q',label:'Reaktiv quvvat Q',unit:'MVAr'}, {key:'cosPhi',label:'Quvvat koeffitsiyenti cosφ',unit:''}
];
export default function LineForm({form,compact=false}:{form:LineFormState;compact?:boolean}) {
  return <div className={`line-form ${compact?'compact':''}`}><div className="form-head"><h3>Boshlang‘ich parametrlar</h3><button className="icon-btn" title="Boshlang‘ich qiymatlarga qaytarish" aria-label="Parametrlarni tiklash" onClick={()=>form.setInput(DEFAULT_INPUT)}><RotateCcw size={17}/></button></div><label>Yuklamani berish usuli</label><div className="segmented"><button className={form.powerMode==='pf'?'selected':''} onClick={()=>form.setPowerMode('pf')}>P va cosφ</button><button className={form.powerMode==='pq'?'selected':''} onClick={()=>form.setPowerMode('pq')}>P va Q</button></div><div className="field-grid">{fields.map(field=>{const derived=field.key==='Q'&&form.powerMode==='pf'||field.key==='cosPhi'&&form.powerMode==='pq';let value=form.raw[field.key];if(derived)value=form.result?String(field.key==='Q'?Math.round(form.result.Q*1e6)/1e6:Math.round(form.result.powerFactor*1e6)/1e6):'';return <div className={`form-field ${derived?'derived':''}`} key={field.key}><label htmlFor={`line-${field.key}`}>{field.label}{derived&&<span> hisoblanadi</span>}</label><div className="unit-input"><input id={`line-${field.key}`} type="number" step="any" value={value} disabled={derived} onChange={e=>form.setValue(field.key,e.target.value)} aria-invalid={!!form.errors[field.key]} aria-describedby={form.errors[field.key]?`error-${field.key}`:undefined}/><span>{field.unit}</span></div>{form.errors[field.key]&&<p className="field-error" id={`error-${field.key}`}>{form.errors[field.key]}</p>}{field.note&&<small>{field.note}</small>}{field.key==='b0'&&Number.isFinite(form.input.b0)&&<small>{fmt(form.input.b0*1e6,3)} μS/km</small>}</div>;})}</div>{form.powerMode==='pf'&&<div className="form-field"><label htmlFor="reactive-kind">Yuklama turi</label><select id="reactive-kind" value={form.reactiveKind} onChange={e=>form.setReactiveKind(e.target.value as LineInput['reactiveKind'])}><option value="inductive">Induktiv — Q musbat</option><option value="capacitive">Sig‘imli — Q manfiy</option></select></div>}<p className="fine-print">P va Q — uch fazaning jami quvvati. R, X, G, B — bir fazaning ekvivalent parametrlari.</p></div>;
}
