import { Component, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import type { ComponentRef, ReactNode } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import type { ThreeEvent } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import LabSceneSVG from './LabSceneSVG';
import './LabScene.css';

export interface LabSceneProps {
  compact?: boolean;
  energized: boolean;
  loadPercent: number;
  height: number;
  selected: string | null;
  onSelect?: (id: string) => void;
  /** An equipment ID, optionally followed by :counter to repeat a focus action. */
  focusTarget?: string | null;
  resetKey?: number;
  showLabels?: boolean;
}

type Vec3 = [number, number, number];
const phaseZ = [-2.8, 0, 2.8];
const towerX = [-14, 0, 14];
const phaseColors = ['#e9b451', '#43b4c3', '#b991da'];
const groundLevel = 0;
// One world unit represents 2.5 m. The main-span minimum is exactly height × 0.4.
const metersToWorld = 0.4;
const spanSag = 1.2;

function Fallback({ onRetry }: { onRetry?: () => void }) {
  return <div className="scene-fallback" role="status">
    <svg viewBox="0 0 70 70" fill="none" aria-hidden="true"><path d="M22 62 31 9h8l9 53M14 22h42M18 34h34M22 47h26M27 62l17-15-20-13 18-12M43 62 26 47l20-13-18-12M7 27l7-5 6 5M50 27l6-5 7 5" strokeWidth="1.8" strokeLinejoin="round"/></svg>
    <strong>3D sahna uchun WebGL kerak</strong>
    <p>Brauzerning apparat tezlashtirishini yoqing yoki WebGL qo‘llaydigan brauzerda oching. Qurilmalar ro‘yxati, nazariya va hisoblash bo‘limlari ishlashda davom etadi.</p>
    {onRetry && <button type="button" onClick={onRetry}>3D sahnani qayta ochish</button>}
  </div>;
}

class SceneBoundary extends Component<{ children: ReactNode; onRetry: () => void; fallback?: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? this.props.fallback ?? <Fallback onRetry={this.props.onRetry} /> : this.props.children; }
}

function supportsWebGL() {
  if (typeof document === 'undefined') return true;
  try {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('webgl2');
    const available = !!context;
    context?.getExtension('WEBGL_lose_context')?.loseContext();
    return available;
  } catch { return false; }
}

function beamGeometry(a: Vec3, b: Vec3, radius = 0.055, sides = 5) {
  const start = new THREE.Vector3(...a);
  const end = new THREE.Vector3(...b);
  const delta = end.clone().sub(start);
  const geometry = new THREE.CylinderGeometry(radius, radius, delta.length(), sides);
  const rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize());
  geometry.applyQuaternion(rotation);
  geometry.translate(...start.add(end).multiplyScalar(0.5).toArray() as Vec3);
  return geometry;
}

function Beam({ a, b, radius = 0.055, color = '#6c7e87' }: { a: Vec3; b: Vec3; radius?: number; color?: string }) {
  const geometry = useMemo(() => beamGeometry(a, b, radius), [a[0], a[1], a[2], b[0], b[1], b[2], radius]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <mesh geometry={geometry} castShadow><meshStandardMaterial color={color} roughness={0.55} metalness={0.45} /></mesh>;
}

function Selectable({ id, onSelect, children }: { id: string; onSelect?: (id: string) => void; children: ReactNode }) {
  const select = (event: ThreeEvent<MouseEvent>) => {
    // Rotating the scene with a finger/mouse must not also select an object.
    if (event.delta > 5) return;
    event.stopPropagation(); onSelect?.(id);
  };
  return <group onClick={onSelect ? select : undefined}
    onPointerOver={onSelect ? (event) => { event.stopPropagation(); document.body.style.cursor = 'pointer'; } : undefined}
    onPointerOut={onSelect ? () => { document.body.style.cursor = ''; } : undefined}>
    {children}
  </group>;
}

function Insulator({ position, length = 0.95, selected = false }: { position: Vec3; length?: number; selected?: boolean }) {
  const profile = useMemo(() => {
    const points: THREE.Vector2[] = [new THREE.Vector2(0.055, 0)];
    const discs = 7;
    for (let i = 0; i < discs; i++) {
      const h = i * length / discs;
      points.push(new THREE.Vector2(0.08, h), new THREE.Vector2(0.23, h + length / discs * 0.2), new THREE.Vector2(0.25, h + length / discs * 0.48), new THREE.Vector2(0.1, h + length / discs * 0.7));
    }
    points.push(new THREE.Vector2(0.055, length));
    return points;
  }, [length]);
  return <group position={position}>
    <mesh castShadow><latheGeometry args={[profile, 10]} /><meshStandardMaterial color={selected ? '#ffc55b' : '#bdced1'} metalness={0.18} roughness={0.25} /></mesh>
    <mesh position={[0, length / 2, 0]}><cylinderGeometry args={[0.045, 0.045, length + 0.17, 6]} /><meshStandardMaterial color="#5b6b74" metalness={0.65} roughness={0.45}/></mesh>
  </group>;
}

function Tower({ x, phaseY, selected, onSelect }: { x: number; phaseY: number; selected: string | null; onSelect?: (id: string) => void }) {
  const geometry = useMemo(() => {
    const pieces: THREE.BufferGeometry[] = [];
    const top = phaseY + 2.8;
    const yLevels = [0.2, top * 0.17, top * 0.34, top * 0.51, top * 0.68, top * 0.85, top];
    const widthAt = (y: number) => 1.2 - 0.96 * y / top;
    const corner = (i: number, y: number): Vec3 => { const w = widthAt(y); return [[-w,y,-w],[w,y,-w],[w,y,w],[-w,y,w]][i] as Vec3; };
    for (let j = 0; j < yLevels.length - 1; j++) {
      for (let k = 0; k < 4; k++) {
        const n = (k + 1) % 4;
        pieces.push(beamGeometry(corner(k,yLevels[j]),corner(k,yLevels[j+1]),0.075));
        pieces.push(beamGeometry(corner(k,yLevels[j]),corner(n,yLevels[j]),0.048));
        pieces.push(beamGeometry(corner(k,yLevels[j]),corner(n,yLevels[j+1]),0.035));
        pieces.push(beamGeometry(corner(n,yLevels[j]),corner(k,yLevels[j+1]),0.035));
      }
    }
    const armY = phaseY + 1.02;
    pieces.push(beamGeometry([0,armY,-3.3],[0,armY,3.3],0.085));
    pieces.push(beamGeometry([0,armY-1.05,-0.45],[0,armY,-3.3],0.06));
    pieces.push(beamGeometry([0,armY-1.05,0.45],[0,armY,3.3],0.06));
    pieces.push(beamGeometry([-0.32,armY,-3.3],[0.32,armY,-3.3],0.055));
    pieces.push(beamGeometry([-0.32,armY,3.3],[0.32,armY,3.3],0.055));
    pieces.push(beamGeometry([0,top-0.2,0],[0,top+0.35,0],0.065));
    const merged = mergeGeometries(pieces)!;
    pieces.forEach(p => p.dispose());
    return merged;
  }, [phaseY]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <group position={[x,0,0]}>
    <Selectable id="tower" onSelect={onSelect}>
      <mesh geometry={geometry} castShadow receiveShadow><meshStandardMaterial color={selected === 'tower' ? '#d6a63f' : '#70828b'} roughness={0.55} metalness={0.58} /></mesh>
      {[-1,1].flatMap(a => [-1,1].map(b => <mesh key={`${a}${b}`} position={[a*1.2,0.16,b*1.2]} receiveShadow castShadow><boxGeometry args={[0.55,0.32,0.55]}/><meshStandardMaterial color="#bcc7c9" roughness={0.95}/></mesh>))}
    </Selectable>
    <Selectable id="insulator" onSelect={onSelect}>
      {phaseZ.map(z => <Insulator key={z} position={[0,phaseY,z]} length={0.95} selected={selected === 'insulator'}/>) }
    </Selectable>
  </group>;
}

function wireCurve(start: Vec3, end: Vec3, sag: number) {
  return new THREE.CatmullRomCurve3(Array.from({length: 25}, (_,i) => {
    const t = i / 24;
    return new THREE.Vector3(start[0]+(end[0]-start[0])*t, start[1]+(end[1]-start[1])*t-4*sag*t*(1-t), start[2]+(end[2]-start[2])*t);
  }));
}

function Wire({ curve, color, thick = 0.045 }: { curve: THREE.CatmullRomCurve3; color: string; thick?: number }) {
  const geometry = useMemo(() => new THREE.TubeGeometry(curve, 40, thick, 5, false), [curve, thick]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <mesh geometry={geometry}><meshStandardMaterial color={color} metalness={0.6} roughness={0.5}/></mesh>;
}

function EnergyFlow({ curves, energized, loadPercent }: { curves: THREE.CatmullRomCurve3[]; energized: boolean; loadPercent: number }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(),[]);
  const countPerWire = 4;
  useFrame(({clock, invalidate}) => {
    if (!ref.current || !energized) return;
    invalidate();
    curves.forEach((curve, ci) => {
      for(let j=0; j<countPerWire; j++) {
        const t = (clock.elapsedTime * (0.055+Math.max(0,loadPercent)*0.0005) + j/countPerWire + ci*0.03)%1;
        dummy.position.copy(curve.getPointAt(t));
        dummy.scale.setScalar(0.09 + Math.max(0,loadPercent)*0.0005);
        dummy.updateMatrix();
        ref.current!.setMatrixAt(ci*countPerWire+j, dummy.matrix);
      }
    });
    ref.current.instanceMatrix.needsUpdate=true;
  });
  useEffect(() => {
    if (!ref.current) return;
    curves.forEach((_, ci) => { for(let j=0;j<countPerWire;j++) ref.current!.setColorAt(ci*countPerWire+j,new THREE.Color(phaseColors[ci%3])); });
    if(ref.current.instanceColor) ref.current.instanceColor.needsUpdate=true;
  },[curves]);
  return <instancedMesh ref={ref} args={[undefined,undefined,curves.length*countPerWire]} visible={energized} frustumCulled={false}>
    <sphereGeometry args={[1,7,5]}/><meshBasicMaterial toneMapped={false}/>
  </instancedMesh>;
}

function Source({ selected, onSelect, energized }: { selected: string | null; onSelect?: (id:string)=>void; energized: boolean }) {
  const turbine = useRef<THREE.Group>(null);
  useFrame((_,delta)=>{if(turbine.current && energized)turbine.current.rotation.z += Math.min(delta,0.1)*1.3;});
  return <group position={[-28,0,0]}>
    <Selectable id="source" onSelect={onSelect}>
      <mesh position={[0,0.14,0]} receiveShadow><boxGeometry args={[8,0.28,7]}/><meshStandardMaterial color="#d8dedb" roughness={0.95}/></mesh>
      <mesh position={[-0.4,1.7,-0.8]} castShadow receiveShadow><boxGeometry args={[6.8,3.2,4.4]}/><meshStandardMaterial color={selected==='source'?'#d9b45b':'#e3e5dd'} roughness={0.8}/></mesh>
      <mesh position={[-0.4,3.4,-0.8]} castShadow><boxGeometry args={[7.2,0.24,4.8]}/><meshStandardMaterial color="#59727c" metalness={0.35} roughness={0.7}/></mesh>
      {[-2.7,-1.35,0,1.35,2.7].map(x=><mesh key={x} position={[x-0.4,2.1,1.42]}><boxGeometry args={[1.05,1.3,0.035]}/><meshStandardMaterial color={energized?'#9bced3':'#90aab4'} emissive={energized?'#356770':'#000000'} emissiveIntensity={0.25} metalness={0.5} roughness={0.25}/></mesh>)}
      <mesh position={[-2.3,0.9,1.45]}><boxGeometry args={[0.7,1.6,0.06]}/><meshStandardMaterial color="#596d75"/></mesh>
      {[0,1,2].map(i=><group key={i} position={[3.3,0.7,-1.8+i*1.8]}>
        <mesh rotation={[Math.PI/2,0,0]} castShadow><cylinderGeometry args={[0.5,0.5,1.1,14]}/><meshStandardMaterial color="#668489" roughness={0.6} metalness={0.5}/></mesh>
        <mesh position={[0,-0.43,0]}><boxGeometry args={[1.1,0.25,1.4]}/><meshStandardMaterial color="#a9b8b8"/></mesh>
        <mesh rotation={[Math.PI/2,0,0]} position={[0,0,0.57]}><torusGeometry args={[0.36,0.05,5,16]}/><meshStandardMaterial color="#cad4d2"/></mesh>
      </group>)}
      <group ref={turbine} position={[3.3,0.7,2.36]}>{[0,1].map(i=><mesh key={i} rotation={[0,0,i*Math.PI/2]}><boxGeometry args={[0.07,0.6,0.05]}/><meshStandardMaterial color="#bdd1d0"/></mesh>)}</group>
      {[-2.6,1.7].map(x=><mesh key={x} position={[x,3.7,-0.8]} castShadow><cylinderGeometry args={[0.22,0.25,0.55,10]}/><meshStandardMaterial color="#91a5aa" metalness={0.5} roughness={0.5}/></mesh>)}
    </Selectable>
  </group>;
}

function Transformer({ x, z=0, id, selected, onSelect, scale=1 }: { x:number;z?:number;id:string;selected:string|null;onSelect?:(id:string)=>void;scale?:number }) {
  const radiatorGeometry=useMemo(()=> {
    const pieces=[-1,1].flatMap(side=>Array.from({length:8},(_,i)=>new THREE.BoxGeometry(0.7,1.75,0.075).translate(side*1.8,1.4,-1.05+i*0.3)));
    const merged=mergeGeometries(pieces)!;
    pieces.forEach(piece=>piece.dispose());
    return merged;
  },[]);
  useEffect(()=>()=>radiatorGeometry.dispose(),[radiatorGeometry]);
  return <group position={[x,0,z]} scale={scale}>
    <Selectable id={id} onSelect={onSelect}>
      <mesh position={[0,0.16,0]} receiveShadow><boxGeometry args={[4.9,0.32,4.6]}/><meshStandardMaterial color="#c9d0cc" roughness={0.9}/></mesh>
      <mesh position={[0,1.4,0]} castShadow receiveShadow><boxGeometry args={[2.7,2.1,2.25]}/><meshStandardMaterial color={selected===id?'#d8aa4d':'#839b9b'} metalness={0.4} roughness={0.55}/></mesh>
      <mesh position={[0,2.48,0]} castShadow><boxGeometry args={[2.93,0.18,2.5]}/><meshStandardMaterial color="#526e73" metalness={0.45} roughness={0.6}/></mesh>
      <mesh geometry={radiatorGeometry} castShadow><meshStandardMaterial color={selected===id?'#bb913c':'#6c888c'} roughness={0.6} metalness={0.45}/></mesh>
      <mesh position={[0,2.95,-0.65]} rotation={[0,0,Math.PI/2]} castShadow><cylinderGeometry args={[0.38,0.38,2.8,16]}/><meshStandardMaterial color="#91a6a4" roughness={0.45} metalness={0.55}/></mesh>
      {[-0.8,0,0.8].map((xPos,i)=><group key={xPos}><Insulator position={[xPos,2.56,0.65]} length={0.8} selected={selected===id}/><mesh position={[xPos,3.43,0.65]}><sphereGeometry args={[0.13,8,6]}/><meshStandardMaterial color={phaseColors[i]} metalness={0.5} roughness={0.4}/></mesh></group>)}
      <Beam a={[-1.05,2.7,-0.7]} b={[-1.05,2.1,-1.2]} radius={0.085}/>
      <mesh position={[0,1.8,1.15]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[0.17,0.17,0.07,12]}/><meshStandardMaterial color="#efead7"/></mesh>
      <mesh position={[0,0.5,1.16]}><boxGeometry args={[0.65,0.32,0.06]}/><meshStandardMaterial color="#d4b04e"/></mesh>
      {[-0.9,0.9].flatMap(a=>[-0.8,0.8].map(b=><mesh key={`${a}${b}`} position={[a,0.37,b]} rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[0.2,0.2,0.15,10]}/><meshStandardMaterial color="#485f68" metalness={0.5} roughness={0.6}/></mesh>))}
    </Selectable>
  </group>;
}

function Substation({ selected,onSelect }: { selected:string|null;onSelect?:(id:string)=>void }) {
  const frame = useMemo(()=> {
    const parts: THREE.BufferGeometry[]=[];
    for(const x of [19,25])for(const z of [-4,4]) parts.push(beamGeometry([x,0,z],[x,2,z],0.05));
    for(const z of [-4,4])for(const y of [0.55,1.4,1.95])parts.push(beamGeometry([18,y,z],[27,y,z],0.03));
    for(const x of [18,27])for(const y of [0.55,1.4,1.95])parts.push(beamGeometry([x,y,-4],[x,y,4],0.03));
    for(const z of [-4,4])for(let x=18;x<=27;x+=0.65)parts.push(beamGeometry([x,0.15,z],[x,1.95,z],0.018,3));
    for(const x of [18,27])for(let z=-4;z<=4;z+=0.65)parts.push(beamGeometry([x,0.15,z],[x,1.95,z],0.018,3));
    const combined=mergeGeometries(parts)!; parts.forEach(p=>p.dispose()); return combined;
  },[]);
  useEffect(() => () => frame.dispose(), [frame]);
  return <group>
    <Selectable id="substation" onSelect={onSelect}>
      <mesh position={[22.5,0.1,0]} receiveShadow><boxGeometry args={[10.7,0.2,9]}/><meshStandardMaterial color={selected==='substation'?'#d7c79e':'#d1d6d3'} roughness={1}/></mesh>
      <mesh geometry={frame}><meshStandardMaterial color={selected==='substation'?'#bc8e38':'#9caeaf'} metalness={0.45} roughness={0.6}/></mesh>
      {[-2.7,0,2.7].map(z=><group key={z} position={[19.2,0,z]}>
        <mesh position={[0,0.8,0]} castShadow><cylinderGeometry args={[0.11,0.13,1.6,6]}/><meshStandardMaterial color="#8b9b9f" metalness={0.6} roughness={0.5}/></mesh>
        <Insulator position={[0,1.6,0]} length={1.05} selected={selected==='substation'}/>
        <Beam a={[-0.7,2.7,0]} b={[0.8,2.7,0]} radius={0.06} color="#756c52"/>
        <Beam a={[0.6,2.7,0]} b={[1.3,3.25,0]} radius={0.065} color="#b0a274"/>
      </group>)}
      <Beam a={[17.6,0,-3.2]} b={[17.6,6.1,-3.2]} radius={0.08}/><Beam a={[17.6,0,3.2]} b={[17.6,6.1,3.2]} radius={0.08}/><Beam a={[17.6,6.1,-3.2]} b={[17.6,6.1,3.2]} radius={0.09}/>
    </Selectable>
    <Transformer x={24} id="stepdown" selected={selected} onSelect={onSelect} scale={0.85}/>
  </group>;
}

function Load({ selected,onSelect,energized,loadPercent }: { selected:string|null;onSelect?:(id:string)=>void;energized:boolean;loadPercent:number }) {
  const windowColor=energized?'#e6c46d':'#91a6ad';
  return <group position={[33,0,0]}>
    <Selectable id="load" onSelect={onSelect}>
      <mesh position={[0,0.1,0]} receiveShadow><boxGeometry args={[8,0.2,8]}/><meshStandardMaterial color="#d0dad6" roughness={0.9}/></mesh>
      {[{x:-1.8,z:-1.4,w:2.3,d:2.4,h:3.2},{x:1.3,z:-1.7,w:2.1,d:2.1,h:4.6},{x:0.4,z:1.3,w:4.6,d:2.5,h:1.9}].map((b,i)=><group key={i} position={[b.x,0,b.z]}>
        <mesh position={[0,b.h/2+0.2,0]} castShadow receiveShadow><boxGeometry args={[b.w,b.h,b.d]}/><meshStandardMaterial color={selected==='load'?'#d4b970':i===1?'#c6d3ce':'#e5e4d9'} roughness={0.85}/></mesh>
        <mesh position={[0,b.h+0.25,0]} castShadow><boxGeometry args={[b.w+0.15,0.15,b.d+0.15]}/><meshStandardMaterial color="#6b8586" roughness={0.75}/></mesh>
        {Array.from({length:Math.max(1,Math.floor(b.h))},(_,row)=>[-0.55,0.55].map((offset,j)=><mesh key={`${row}${j}`} position={[offset,0.85+row*0.9,b.d/2+0.012]}><boxGeometry args={[0.55,0.45,0.025]}/><meshStandardMaterial color={windowColor} emissive={energized?'#bf9742':'#000000'} emissiveIntensity={energized?0.15+loadPercent/250:0} metalness={0.15} roughness={0.5}/></mesh>))}
        {i===2&&[0,1,2,3].map(j=><mesh key={j} position={[-1.5+j,b.h+0.4,0]} rotation={[-0.2,0,0]}><boxGeometry args={[0.8,0.05,1.6]}/><meshStandardMaterial color="#294b65" metalness={0.35} roughness={0.4}/></mesh>)}
      </group>)}
    </Selectable>
  </group>;
}

function Meter({ x,id,letter,selected,onSelect }: { x:number;id:string;letter:string;selected:string|null;onSelect?:(id:string)=>void }) {
  const texture=useMemo(()=> {
    const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;
    const ctx=canvas.getContext('2d')!;
    ctx.fillStyle='#e9f2ef';ctx.fillRect(0,0,128,128);
    ctx.strokeStyle='#8aa4a7';ctx.lineWidth=2;ctx.beginPath();ctx.arc(64,66,43,Math.PI*1.08,Math.PI*1.92);ctx.stroke();
    ctx.strokeStyle='#285866';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(64,66);ctx.lineTo(91,33);ctx.stroke();
    ctx.fillStyle='#1d4855';ctx.textAlign='center';ctx.font='bold 36px sans-serif';ctx.fillText(letter,64,108);
    const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;return tex;
  },[letter]);
  useEffect(() => () => texture.dispose(), [texture]);
  return <group position={[x,0,5.3]}>
    <Selectable id={id} onSelect={onSelect}>
      <mesh position={[0,0.2,0]} receiveShadow><boxGeometry args={[1.25,0.3,0.9]}/><meshStandardMaterial color="#bfcac7"/></mesh>
      <Beam a={[0,0.3,0]} b={[0,1.3,0]} radius={0.085}/>
      <mesh position={[0,1.65,0]} castShadow><boxGeometry args={[1.1,1.15,0.45]}/><meshStandardMaterial color={selected===id?'#dcb05a':'#476b75'} roughness={0.5} metalness={0.25}/></mesh>
      <mesh position={[0,1.65,0.235]}><planeGeometry args={[0.88,0.91]}/><meshBasicMaterial map={texture}/></mesh>
    </Selectable>
  </group>;
}

function SceneGround() {
  const roadMarkings=useMemo(()=> {
    const pieces=Array.from({length:27},(_,i)=>new THREE.BoxGeometry(1.4,0.013,0.06).translate(-37+i*2.8,0.028,8.3));
    const merged=mergeGeometries(pieces)!;
    pieces.forEach(piece=>piece.dispose());
    return merged;
  },[]);
  useEffect(()=>()=>roadMarkings.dispose(),[roadMarkings]);
  return <group>
    <mesh position={[1,-0.22,0]} receiveShadow><boxGeometry args={[79,0.42,24]}/><meshStandardMaterial color="#d7e3dc" roughness={1}/></mesh>
    <mesh position={[1,-0.46,0]}><boxGeometry args={[79.4,0.18,24.4]}/><meshStandardMaterial color="#bccfcb" roughness={1}/></mesh>
    <mesh position={[1,0.009,8.3]} receiveShadow><boxGeometry args={[78,0.025,2.6]}/><meshStandardMaterial color="#bbc7c7" roughness={1}/></mesh>
    <mesh geometry={roadMarkings}><meshBasicMaterial color="#eaf0eb"/></mesh>
    {[-33,-19,-6,8,22,35].map((x,i)=><group key={x} position={[x,0,-8.2-(i%2)]}>
      <mesh position={[0,0.6,0]} castShadow><cylinderGeometry args={[0.1,0.15,1.2,5]}/><meshStandardMaterial color="#9c9279"/></mesh>
      <mesh position={[0,1.45,0]} castShadow><icosahedronGeometry args={[1,0]}/><meshStandardMaterial color={i%2?'#8caaa0':'#a4bdae'} roughness={1}/></mesh>
    </group>)}
    <gridHelper args={[80,40,'#bed0c7','#c9d9d1']} position={[1,0.005,-1]} scale={[1,1,0.3]}/>
  </group>;
}

function CameraRig({ focusTarget,resetKey=0,phaseY,compact }: { focusTarget?:string|null;resetKey?:number;phaseY:number;compact:boolean }) {
  const {camera,size,invalidate}=useThree();
  const controls=useRef<ComponentRef<typeof OrbitControls>>(null);
  const targetPosition=useRef(new THREE.Vector3(0,3,0));
  const cameraPosition=useRef(new THREE.Vector3(41,26,46));
  const moving=useRef(false);
  const previousAction=useRef('');
  const focusId=focusTarget?.split(':')[0];
  const targets:Record<string,Vec3>={source:[-28,2,0],stepup:[-21,2,0],line:[0,phaseY-0.3,0],tower:[0,phaseY/2,0],insulator:[0,phaseY+0.5,2.8],wires:[7,phaseY-spanSag,0],height:[-7,(phaseY-spanSag)/2,4],substation:[22,1.8,0],stepdown:[24,1.8,0],load:[33,2,0],voltmeter:[19,1.5,5.3],ammeter:[22,1.5,5.3],wattmeter:[25,1.5,5.3]};
  useEffect(()=> {
    const action=`${focusTarget ?? ''}|${resetKey}|${size.width}|${size.height}`;
    // A height change updates a focused device, but preserves a manually orbited overview.
    if(previousAction.current===action&&!focusId)return;
    previousAction.current=action;
    const focus=focusId&&targets[focusId];
    if(focus){
      targetPosition.current.set(...focus);
      const d=focusId==='line'?24:focusId==='tower'?15:focusId==='insulator'?5:focusId==='wires'?12:focusId==='load'||focusId==='source'||focusId==='substation'?12:8;
      cameraPosition.current.copy(targetPosition.current).add(new THREE.Vector3(d*0.75,d*0.62,d));
    } else {
      targetPosition.current.set(1,3,0);
      const small=size.width/size.height<1.2;
      cameraPosition.current.set(small?49:41,small?34:26,small?63:46);
    }
    moving.current=true;
    invalidate();
  },[focusTarget,resetKey,size.width,size.height,phaseY,invalidate]);
  useEffect(()=>{if(controls.current&&!focusTarget)controls.current.target.set(1,3,0);},[]);
  useFrame((_,delta)=> {
    if(!moving.current||!controls.current)return;
    invalidate();
    const alpha=1-Math.exp(-delta*5);
    camera.position.lerp(cameraPosition.current,alpha);
    controls.current.target.lerp(targetPosition.current,alpha);
    controls.current.update();
    if(camera.position.distanceTo(cameraPosition.current)<0.02)moving.current=false;
  });
  return <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={0.08} minDistance={3} maxDistance={115} maxPolarAngle={Math.PI/2-0.025} minPolarAngle={0.12} enablePan={!compact} onStart={()=>{moving.current=false;}} />;
}

function World(props:LabSceneProps) {
  const {energized,loadPercent,selected,onSelect,focusTarget,resetKey,showLabels=true,compact=false}=props;
  const viewportWidth=useThree(state=>state.size.width);
  const heightMeters=Number.isFinite(props.height)?Math.max(3,Math.min(40,props.height)):12;
  const clearance=heightMeters*metersToWorld;
  const phaseY=clearance+spanSag;
  const curves=useMemo(()=>towerX.slice(0,-1).flatMap((x,i)=>phaseZ.map(z=>wireCurve([x,phaseY,z],[towerX[i+1],phaseY,z],spanSag))),[phaseY]);
  const shieldCurves=useMemo(()=>towerX.slice(0,-1).map((x,i)=>wireCurve([x,phaseY+3.1,0],[towerX[i+1],phaseY+3.1,0],0.65)),[phaseY]);
  const feederCurves=useMemo(()=>phaseZ.flatMap((z,i)=>[
    wireCurve([-21+(-0.8+i*0.8),3.45,0.65],[-14,phaseY,z],0.6),
    wireCurve([14,phaseY,z],[17.6,5.2,z],0.22),
    wireCurve([17.6,5.2,z],[19.2,2.7,z],0.13),
  ]),[phaseY]);
  const label=(id:string,name:string,pos:Vec3)=><Html key={id} position={pos} center distanceFactor={compact?55:48} zIndexRange={[20,0]}>{onSelect?<button type="button" className={`scene-label ${selected===id?'is-selected':''}`} aria-label={`${name} haqida ma’lumot`} aria-pressed={selected===id} onClick={()=>onSelect(id)}>{name}</button>:<span className="scene-label">{name}</span>}</Html>;
  return <>
    <color attach="background" args={['#e9eff2']}/>
    <fog attach="fog" args={['#e9eff2',105,170]}/>
    <ambientLight intensity={1.35}/><hemisphereLight args={['#eaf6ff','#a5b7a7',1.7]}/>
    <directionalLight position={[-15,32,20]} intensity={2.8} castShadow shadow-mapSize={viewportWidth<700?[1024,1024]:[2048,2048]} shadow-camera-left={-48} shadow-camera-right={48} shadow-camera-top={33} shadow-camera-bottom={-33} shadow-normalBias={0.035} shadow-bias={-0.0002}/>
    <directionalLight position={[25,10,-25]} intensity={0.9} color="#cbe1f4"/>
    <SceneGround/>
    <Source selected={selected} onSelect={onSelect} energized={energized}/>
    <Transformer x={-21} id="stepup" selected={selected} onSelect={onSelect}/>
    {towerX.map(x=><Tower key={x} x={x} phaseY={phaseY} selected={selected} onSelect={onSelect}/>)}
    <Selectable id="line" onSelect={onSelect}>{curves.slice(0,3).map((curve,i)=><Wire key={i} curve={curve} color={selected==='line'||selected==='wires'?'#d8a443':energized?phaseColors[i%3]:'#62737b'} thick={selected==='line'?0.075:0.048}/>)}</Selectable>
    <Selectable id="wires" onSelect={onSelect}>{curves.slice(3).map((curve,i)=><Wire key={i} curve={curve} color={selected==='line'||selected==='wires'?'#d8a443':energized?phaseColors[i%3]:'#62737b'} thick={selected==='wires'?0.075:0.048}/>)}</Selectable>
    <Selectable id="line" onSelect={onSelect}>{shieldCurves.map((curve,i)=><Wire key={i} curve={curve} color="#89969c" thick={0.035}/>)}{feederCurves.map((curve,i)=><Wire key={i} curve={curve} color={selected==='line'?'#d8a443':'#71838b'} thick={0.038}/>)}</Selectable>
    <EnergyFlow curves={curves} energized={energized} loadPercent={loadPercent}/>
    <Substation selected={selected} onSelect={onSelect}/>
    <Load selected={selected} onSelect={onSelect} energized={energized} loadPercent={loadPercent}/>
    {[{x:19,id:'voltmeter',letter:'V'},{x:22,id:'ammeter',letter:'A'},{x:25,id:'wattmeter',letter:'W'}].map(m=><Meter key={m.id} {...m} selected={selected} onSelect={onSelect}/>)}
    <Selectable id="height" onSelect={onSelect}>
      <Beam a={[-7,groundLevel+0.1,4.3]} b={[-7,clearance,4.3]} radius={selected==='height'?0.055:0.035} color="#b68a36"/>
      <Beam a={[-7.55,0.1,4.3]} b={[-6.45,0.1,4.3]} radius={0.035} color="#b68a36"/>
      <Beam a={[-7.55,clearance,4.3]} b={[-6.45,clearance,4.3]} radius={0.035} color="#b68a36"/>
      <Beam a={[-7,clearance,2.8]} b={[-7,clearance,4.3]} radius={0.018} color="#bfa56a"/>
      {[0.35,clearance-0.22].map((y,i)=><mesh key={i} position={[-7,y,4.3]} rotation={i===0?[Math.PI,0,0]:[0,0,0]}><coneGeometry args={[0.13,0.35,6]}/><meshStandardMaterial color="#b68a36"/></mesh>)}
    </Selectable>
    {showLabels&&<>
      {label('source','Elektr stansiyasi',[-28,5.1,-0.4])}
      {label('line','Uch fazali liniya',[0,phaseY+4.4,0])}
      {label('substation','Podstansiya',[23,5.5,-0.6])}
      {!compact&&label('load','Iste’molchi',[33,6.5,-0.5])}
      <Html position={[-7.6,clearance/2,4.4]} center distanceFactor={48} zIndexRange={[20,0]}>{onSelect?<button type="button" className="scene-height" aria-label="Simning yerga balandligi haqida ma’lumot" aria-pressed={selected==='height'} onClick={()=>onSelect('height')}>{heightMeters.toLocaleString('uz-UZ',{maximumFractionDigits:1})} m</button>:<span className="scene-height">{heightMeters.toLocaleString('uz-UZ',{maximumFractionDigits:1})} m</span>}</Html>
    </>}
    <CameraRig focusTarget={focusTarget} resetKey={resetKey} phaseY={phaseY} compact={compact}/>
  </>;
}

export default function LabScene(props:LabSceneProps) {
  const [supported,setSupported]=useState(supportsWebGL);
  const [attempt,setAttempt]=useState(0);
  const container=useRef<HTMLDivElement>(null);
  const [visible,setVisible]=useState(true);
  useEffect(()=>()=>{document.body.style.cursor='';},[]);
  useEffect(()=> {
    let inView=true;
    const update=()=>setVisible(inView&&!document.hidden);
    const observer=typeof IntersectionObserver!=='undefined'?new IntersectionObserver(entries=>{inView=entries[0]?.isIntersecting??true;update();},{threshold:0.01}):null;
    if(container.current)observer?.observe(container.current);
    document.addEventListener('visibilitychange',update);
    update();
    return()=>{observer?.disconnect();document.removeEventListener('visibilitychange',update);};
  },[]);
  const retry=()=>{setSupported(supportsWebGL());setAttempt(x=>x+1);};
  return <div ref={container} className={`lab-scene ${props.compact?'is-compact':''}`} role="region" aria-label="Elektr uzatish liniyasining interaktiv uch o‘lchamli maketi">
    {!supported?<LabSceneSVG {...props}/>:<SceneBoundary key={attempt} onRetry={retry} fallback={<LabSceneSVG {...props}/>}>
      <Canvas shadows frameloop={visible?'demand':'never'} dpr={[1,1.5]} camera={{position:[41,26,46],fov:43,near:0.1,far:220}} gl={{antialias:true,alpha:false,powerPreference:'high-performance'}} fallback={<Fallback onRetry={retry}/>}>
        <Suspense fallback={null}><World {...props}/></Suspense>
      </Canvas>
    </SceneBoundary>}
  </div>;
}
