import { useMemo, useState } from 'react';
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine } from 'recharts';
import { calculateLine, validateInput, type LineInput } from '../lib/physics';
import { fmt } from './UI';
const axes = {l:{title:'Liniya uzunligi',unit:'km'},P:{title:'Aktiv quvvat',unit:'MW'},U:{title:'Kuchlanish',unit:'kV'},cosPhi:{title:'Quvvat koeffitsiyenti',unit:''}};
const metrics = { deltaU:{title:'Kuchlanish tushuvi ΔU',unit:'kV'},deltaP:{title:'Aktiv yo‘qotish ΔP',unit:'MW'},I:{title:'Liniya toki I',unit:'kA'} };
export default function ParameterChart({input}:{input:LineInput}) {
  const [axis,setAxis]=useState<keyof typeof axes>('l');const [metric,setMetric]=useState<keyof typeof metrics>('deltaU');
  const result=calculateLine(input);
  const data=useMemo(()=>Array.from({length:25},(_,i)=>{
    const max=axis==='P'?5000:1000;
    const start=axis==='cosPhi'?0.1:Math.max(axis==='P'?0:0.001,input[axis]*0.25);
    const end=axis==='cosPhi'?1:Math.min(max,input[axis]>0?input[axis]*1.75:30);
    const x=start+(end-start)*i/24;
    const next={...input,[axis]:x};
    if(axis==='P'){next.powerMode='pq';next.Q=input.P>0?result.Q*x/input.P:result.Q;}
    if(axis==='cosPhi'){next.powerMode='pf';next.cosPhi=x;next.reactiveKind=result.Q<0?'capacitive':'inductive';}
    try {if(Object.keys(validateInput(next)).length)throw new Error('Model chegarasi');return {x:Number(x.toPrecision(7)),...calculateLine(next)};}
    catch {return {x:Number(x.toPrecision(7)),I:null,deltaU:null,deltaP:null};}
  }),[input,axis]);
  return <section className="panel chart-panel"><div className="section-title"><div><span className="eyebrow">PARAMETRIK TAHLIL</span><h3>Bir parametr o‘zgarsa nima bo‘ladi?</h3></div></div><div className="chart-selects"><label>O‘zgaruvchi<select value={axis} onChange={e=>setAxis(e.target.value as keyof typeof axes)}>{Object.entries(axes).map(([k,v])=><option key={k} value={k}>{v.title}{v.unit?` (${v.unit})`:''}</option>)}</select></label><label>Natija<select value={metric} onChange={e=>setMetric(e.target.value as keyof typeof metrics)}>{Object.entries(metrics).map(([k,v])=><option key={k} value={k}>{v.title} ({v.unit})</option>)}</select></label></div><div className="chart-area" role="img" aria-label={`${axes[axis].title} ga bog‘liq ${metrics[metric].title} grafigi`}><ResponsiveContainer width="100%" height="100%"><LineChart data={data} margin={{top:18,right:25,left:8,bottom:24}}><CartesianGrid strokeDasharray="4 5" vertical={false} stroke="#e4e9ed"/><XAxis dataKey="x" type="number" domain={['dataMin','dataMax']} tickFormatter={v=>fmt(v,2)} tick={{fontSize:11,fill:'#73818b'}} label={{value:`${axes[axis].title}, ${axes[axis].unit}`,position:'insideBottom',offset:-17,fill:'#657782',fontSize:11}}/><YAxis tickFormatter={v=>fmt(v,3)} tick={{fontSize:11,fill:'#73818b'}} width={60} label={{value:metrics[metric].unit,angle:-90,position:'insideLeft',fill:'#657782',fontSize:11}}/><Tooltip formatter={(value)=>[`${fmt(Number(value),5)} ${metrics[metric].unit}`,metrics[metric].title]} labelFormatter={v=>`${axes[axis].title}: ${fmt(Number(v),3)} ${axes[axis].unit}`} contentStyle={{borderRadius:12,border:'1px solid #dce6e7',fontSize:12}}/><ReferenceLine x={axis==='cosPhi'?result.powerFactor:input[axis]} stroke="#93aaaf" strokeDasharray="4 4" label={{value:'Joriy',fontSize:10,fill:'#6c838a'}}/><Line type="monotone" dataKey={metric} stroke="#167d73" strokeWidth={3} dot={false} activeDot={{r:5,fill:'#c4ed79',stroke:'#167d73',strokeWidth:2}}/></LineChart></ResponsiveContainer></div><p className="fine-print">{axis==='P'?(input.P>0?'Quvvat o‘zgarganda cosφ doimiy; Q ham mos ravishda o‘zgaradi.':'Boshlang‘ich P = 0: aktiv quvvat o‘zgaradi, Q doimiy saqlanadi.'):axis==='cosPhi'?'cosφ o‘zgarganda P doimiy; Q qayta hisoblanadi.':'Boshqa kiritilgan parametrlar doimiy saqlanadi.'} Nuqta ustiga kursor olib borib aniq qiymatni ko‘ring.{data.some(d=>d.I===null)&&' Modelning ruxsat etilgan chegarasidan tashqaridagi nuqtalar chizilmaydi.'}</p></section>;
}
