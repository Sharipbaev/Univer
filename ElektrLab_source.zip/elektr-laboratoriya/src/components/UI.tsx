import { useMemo, type ReactNode } from 'react';
import katex from 'katex';
import { ArrowRight, CheckCircle2, CircleAlert, Info, LoaderCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
export function Formula({ tex, block = true }: { tex: string; block?: boolean }) {
  const html = useMemo(() => katex.renderToString(tex, { throwOnError: false, displayMode: block, trust: false, output: 'htmlAndMathml' }), [tex, block]);
  return <span className={block ? 'formula-block' : 'formula-inline'} dangerouslySetInnerHTML={{ __html: html }} />;
}
export const fmt = (n: number, digits = 3): string => Number.isFinite(n) ? n.toLocaleString('uz-UZ', { maximumFractionDigits: digits, minimumFractionDigits: 0 }) : '—';
export function PageHeading({ step, title, description, action }: { step: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-heading"><div><span className="eyebrow">{step}</span><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}
export function Notice({ children, kind = 'info' }: { children: ReactNode; kind?: 'info' | 'success' | 'warning' | 'error' }) {
  const Icon = kind === 'success' ? CheckCircle2 : kind === 'error' ? CircleAlert : Info;
  return <div className={`notice ${kind}`} role={kind === 'error' ? 'alert' : 'status'}><Icon size={18}/><div>{children}</div></div>;
}
export function Metric({ label, value, unit, hint, accent = false }: { label: string; value: string | number; unit?: string; hint?: string; accent?: boolean }) {
  return <div className={`metric ${accent ? 'accent' : ''}`}><span>{label}</span><strong>{value}<small>{unit}</small></strong>{hint && <p>{hint}</p>}</div>;
}
export function NextLink({ to, children }: { to: string; children: ReactNode }) { return <Link className="btn primary" to={to}>{children}<ArrowRight size={17}/></Link>; }
export function Loading({ text = 'Bo‘lim yuklanmoqda…' }: { text?: string }) { return <div className="loading"><LoaderCircle className="spin" size={28}/><span>{text}</span></div>; }
export function Progress({ value, label }: { value: number; label: string }) { return <div className="progress-wrapper"><div><span>{label}</span><strong>{Math.round(value)}%</strong></div><div className="progress-track" role="progressbar" aria-label={label} aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${Math.min(100, Math.max(0, value))}%` }}/></div></div>; }

