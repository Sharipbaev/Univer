import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { SVGRenderer } from 'three/examples/jsm/renderers/SVGRenderer.js';
import type { LabSceneProps } from './LabScene';

type Vec3 = [number, number, number];
type ColoredMaterial = THREE.MeshLambertMaterial | THREE.MeshBasicMaterial | THREE.LineBasicMaterial;
type MaterialRecord = { material: ColoredMaterial; base: THREE.Color; id?: string; active?: string; role?: 'wire' | 'window' | 'lamp' };
type LabelRecord = { text: string; position: THREE.Vector3; id?: string; meter?: boolean; element?: HTMLElement };
type CpuWorld = {
  root: THREE.Group;
  materials: MaterialRecord[];
  labels: LabelRecord[];
  curves: THREE.CatmullRomCurve3[];
  particles: THREE.Mesh[];
  rotor: THREE.Group;
  height: number;
  bounds: THREE.Box3;
  targets: Record<string, { point: Vec3; distance: number }>;
};

const PHASE_Z = [-2.8, 0, 2.8];
const TOWER_X = [-14, 0, 14];
const PHASE_COLORS = ['#d4a143', '#2a9aa9', '#9c78bc'];
const SAG = 1.2;
const HIGHLIGHT = '#cf9d35';

/** The SVG renderer projects these actual 3D vertices through a perspective camera. */
function buildWorld(height: number): CpuWorld {
  const root = new THREE.Group();
  const materials: MaterialRecord[] = [];
  const labels: LabelRecord[] = [];
  const curves: THREE.CatmullRomCurve3[] = [];
  const particles: THREE.Mesh[] = [];
  const heightMeters = Number.isFinite(height) ? Math.max(3, Math.min(40, height)) : 18;
  const clearance = heightMeters * 0.4;
  const phaseY = clearance + SAG;

  const material = (color: string, id?: string, role?: MaterialRecord['role'], active?: string, basic = false) => {
    const mat = basic ? new THREE.MeshBasicMaterial({ color }) : new THREE.MeshLambertMaterial({ color, flatShading: true });
    materials.push({ material: mat, base: new THREE.Color(color), id, role, active });
    return mat;
  };
  const group = (id?: string, position: Vec3 = [0, 0, 0], parent = root) => {
    const g = new THREE.Group();
    if (id) g.userData.equipmentId = id;
    g.position.set(...position);
    parent.add(g);
    return g;
  };
  const box = (parent: THREE.Group, position: Vec3, size: Vec3, color: string, id?: string, role?: MaterialRecord['role'], active?: string) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material(color, id, role, active));
    mesh.position.set(...position);
    parent.add(mesh);
    return mesh;
  };
  const cylinder = (parent: THREE.Group, position: Vec3, top: number, bottom: number, length: number, color: string, id?: string, basic = false) => {
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(top, bottom, length, 6), material(color, id, undefined, undefined, basic));
    mesh.position.set(...position);
    parent.add(mesh);
    return mesh;
  };
  const lines = (parent: THREE.Group, segments: Vec3[], color: string, id?: string, width = 1.3) => {
    const geometry = new THREE.BufferGeometry().setFromPoints(segments.map(p => new THREE.Vector3(...p)));
    const mat = new THREE.LineBasicMaterial({ color, linewidth: width });
    materials.push({ material: mat, base: new THREE.Color(color), id });
    const line = new THREE.LineSegments(geometry, mat);
    parent.add(line);
    return line;
  };
  const insulator = (parent: THREE.Group, position: Vec3, length = 0.9, id = 'insulator') => {
    // Four low-poly porcelain discs retain a visible, layered 3D profile.
    cylinder(parent, [position[0], position[1] + length / 2, position[2]], 0.045, 0.045, length + 0.12, '#728a90', id, true);
    for (let i = 0; i < 4; i++) {
      cylinder(parent, [position[0], position[1] + 0.1 + i * length / 4, position[2]], 0.11, 0.25, 0.105, '#b8d1d0', id, true);
    }
  };
  const wire = (parent: THREE.Group, start: Vec3, end: Vec3, sag: number, id: string, phase: number, animate = false, width = 1.7) => {
    const points = Array.from({ length: 25 }, (_, i) => {
      const t = i / 24;
      return new THREE.Vector3(start[0] + (end[0] - start[0]) * t, start[1] + (end[1] - start[1]) * t - 4 * sag * t * (1 - t), start[2] + (end[2] - start[2]) * t);
    });
    const curve = new THREE.CatmullRomCurve3(points);
    const mat = new THREE.LineBasicMaterial({ color: '#5b737d', linewidth: width });
    materials.push({ material: mat, base: new THREE.Color('#5b737d'), id, role: 'wire', active: PHASE_COLORS[phase % 3] });
    const cable = new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), mat);
    cable.userData.equipmentId = id;
    parent.add(cable);
    if (animate) curves.push(curve);
    return curve;
  };

  // Ground and access road are spatial meshes, not a background illustration.
  // SVG uses painter sorting rather than a depth buffer. Large ground polygons must be
  // drawn before the equipment even when their average depth is closer to the camera.
  box(root, [1, -0.23, 0], [78, 0.44, 23], '#d7e4dd').renderOrder = -1000;
  box(root, [1, -0.5, 0], [78.4, 0.16, 23.4], '#b4ccc4').renderOrder = -1001;
  box(root, [1, 0.015, 8.2], [77.5, 0.025, 2.4], '#b9c9c9').renderOrder = -998;
  const road: Vec3[] = [];
  for (let i = 0; i < 25; i++) road.push([-36 + i * 3, 0.045, 8.2], [-34.5 + i * 3, 0.045, 8.2]);
  lines(root, road, '#edf1e9', undefined, 1.5).renderOrder = -997;
  const grid: Vec3[] = [];
  for (let x = -36; x <= 39; x += 6) grid.push([x, 0.013, -10], [x, 0.013, 6.5]);
  for (let z = -10; z <= 6.5; z += 4) grid.push([-36, 0.013, z], [39, 0.013, z]);
  lines(root, grid, '#c6d8cf', undefined, 0.65).renderOrder = -999;

  // Source building with distinct generator drums, roof vents and an animated rotor.
  const source = group('source', [-28, 0, 0]);
  box(source, [0, 0.13, 0], [8, 0.26, 7], '#d0d8cf', 'source').renderOrder = -990;
  box(source, [-0.4, 1.7, -0.65], [6.6, 3.1, 4.2], '#e4e5db', 'source');
  box(source, [-0.4, 3.35, -0.65], [7, 0.2, 4.6], '#617e86', 'source');
  for (let i = 0; i < 5; i++) box(source, [-2.9 + i * 1.3, 2.1, 1.47], [0.9, 1.1, 0.03], '#7898a4', 'source', 'window', '#a3d7d5');
  box(source, [-2.4, 0.85, 1.49], [0.6, 1.45, 0.03], '#5a7581', 'source');
  for (const x of [-2.3, 1.5]) cylinder(source, [x, 3.7, -0.7], 0.2, 0.24, 0.55, '#8ba6aa', 'source');
  for (let i = 0; i < 3; i++) {
    const generator = cylinder(source, [3.1, 0.9, -1.8 + i * 1.7], 0.48, 0.48, 1.1, '#6b9396', 'source');
    generator.rotation.x = Math.PI / 2;
    box(source, [3.1, 0.4, -1.8 + i * 1.7], [1.1, 0.3, 1.4], '#adc2bd', 'source');
  }
  const rotor = group('source', [3.1, 0.9, 2.22], source);
  box(rotor, [0, 0, 0], [0.07, 0.6, 0.04], '#d5dfd7', 'source');
  box(rotor, [0, 0, 0], [0.6, 0.07, 0.04], '#d5dfd7', 'source');

  const transformer = (x: number, id: string, scale = 1) => {
    const tx = group(id, [x, 0, 0]);
    tx.scale.setScalar(scale);
    box(tx, [0, 0.15, 0], [4.8, 0.3, 4.3], '#c5d1c9', id).renderOrder = -989;
    box(tx, [0, 1.35, 0], [2.7, 2.1, 2.25], '#83a19f', id);
    box(tx, [0, 2.45, 0], [2.9, 0.16, 2.45], '#577d83', id);
    // Radiators have depth and a visible fin pattern on both sides.
    for (const side of [-1, 1]) {
      box(tx, [side * 1.75, 1.35, 0], [0.6, 1.8, 2.35], '#6f9395', id);
      const fins: Vec3[] = [];
      for (let i = 0; i < 8; i++) {
        const z = -1.06 + i * 0.3;
        fins.push([side * 2.06, 0.5, z], [side * 2.06, 2.22, z]);
        fins.push([side * 1.45, 2.26, z], [side * 2.06, 2.26, z]);
      }
      lines(tx, fins, '#395e69', id, 1.0);
    }
    const reservoir = cylinder(tx, [0, 2.95, -0.6], 0.35, 0.35, 2.8, '#95b1aa', id);
    reservoir.rotation.z = Math.PI / 2;
    for (let i = 0; i < 3; i++) insulator(tx, [-0.8 + i * 0.8, 2.55, 0.65], 0.8, id);
    box(tx, [0, 0.72, 1.14], [0.7, 0.32, 0.04], '#e0bd62', id);
    return tx;
  };
  transformer(-21, 'stepup');
  const sourceConnections = group('stepup');
  for (let i = 0; i < 3; i++) wire(sourceConnections, [-24.6, 1.7, -0.6 + i * 0.6], [-22.35, 1.7, -0.6 + i * 0.6], 0.08, 'stepup', i, false, 1.3);

  // Every pylon is a tapered 3D truss. LineSegments reduce CPU/SVG cost.
  for (const x of TOWER_X) {
    const tower = group('tower', [x, 0, 0]);
    const top = phaseY + 2.8;
    const corner = (index: number, y: number): Vec3 => {
      const w = 1.2 - 0.95 * y / top;
      return [[-w, y, -w], [w, y, -w], [w, y, w], [-w, y, w]][index] as Vec3;
    };
    const members: Vec3[] = [];
    for (let level = 0; level < 6; level++) {
      const y0 = 0.2 + (top - 0.2) * level / 6;
      const y1 = 0.2 + (top - 0.2) * (level + 1) / 6;
      for (let k = 0; k < 4; k++) {
        const n = (k + 1) % 4;
        members.push(corner(k, y0), corner(k, y1));
        members.push(corner(k, y0), corner(n, y0));
        members.push(corner(k, y0), corner(n, y1));
        members.push(corner(n, y0), corner(k, y1));
      }
    }
    members.push([0, phaseY + 1.0, -3.35], [0, phaseY + 1.0, 3.35]);
    members.push([0, phaseY - 0.15, -0.45], [0, phaseY + 1.0, -3.35]);
    members.push([0, phaseY - 0.15, 0.45], [0, phaseY + 1.0, 3.35]);
    members.push([0, top - 0.2, 0], [0, top + 0.3, 0]);
    lines(tower, members, '#587681', 'tower', 1.5);
    for (const a of [-1, 1]) for (const b of [-1, 1]) box(tower, [a * 1.2, 0.17, b * 1.2], [0.55, 0.34, 0.55], '#b4c5c0', 'tower').renderOrder = -980;
    const discs = group('insulator', [x, 0, 0]);
    for (const z of PHASE_Z) insulator(discs, [0, phaseY, z]);
  }
  const mainLine = group('line');
  const phaseWires = group('wires');
  for (let span = 0; span < 2; span++) {
    for (let phase = 0; phase < 3; phase++) {
      wire(span === 0 ? mainLine : phaseWires, [TOWER_X[span], phaseY, PHASE_Z[phase]], [TOWER_X[span + 1], phaseY, PHASE_Z[phase]], SAG, span === 0 ? 'line' : 'wires', phase, true);
    }
    wire(mainLine, [TOWER_X[span], phaseY + 3.05, 0], [TOWER_X[span + 1], phaseY + 3.05, 0], 0.65, 'line', 1, false, 0.9);
  }
  for (let phase = 0; phase < 3; phase++) {
    const z = PHASE_Z[phase];
    wire(mainLine, [-21.8 + phase * 0.8, 3.4, 0.65], [-14, phaseY, z], 0.6, 'line', phase, false, 1.25);
    wire(mainLine, [14, phaseY, z], [17.6, 5.2, z], 0.2, 'line', phase, false, 1.25);
    wire(mainLine, [17.6, 5.2, z], [19.2, 2.7, z], 0.12, 'line', phase, false, 1.25);
  }

  const substation = group('substation');
  box(substation, [22.5, 0.1, 0], [10.5, 0.2, 8.5], '#cbd5cc', 'substation').renderOrder = -992;
  const fence: Vec3[] = [];
  for (const z of [-4, 4]) {
    for (let x = 18; x <= 27; x += 1) fence.push([x, 0.1, z], [x, 1.8, z]);
    for (const y of [0.5, 1.5, 1.8]) fence.push([18, y, z], [27, y, z]);
  }
  for (const x of [18, 27]) {
    for (let z = -4; z <= 4; z += 1) fence.push([x, 0.1, z], [x, 1.8, z]);
    for (const y of [0.5, 1.5, 1.8]) fence.push([x, y, -4], [x, y, 4]);
  }
  lines(substation, fence, '#8da8a5', 'substation', 0.9);
  lines(substation, [[17.6, 0, -3.2], [17.6, 6.1, -3.2], [17.6, 0, 3.2], [17.6, 6.1, 3.2], [17.6, 6.1, -3.2], [17.6, 6.1, 3.2]], '#69818a', 'substation', 2.2);
  for (const z of PHASE_Z) {
    cylinder(substation, [19.2, 0.8, z], 0.12, 0.15, 1.6, '#96afaa', 'substation');
    insulator(substation, [19.2, 1.6, z], 1.05, 'substation');
    lines(substation, [[18.6, 2.7, z], [20, 2.7, z], [19.8, 2.7, z], [20.5, 3.25, z]], '#98835b', 'substation', 2.2);
  }
  transformer(24, 'stepdown', 0.85);
  const outgoing = group('stepdown');
  for (let phase = 0; phase < 3; phase++) wire(outgoing, [25.15, 1.5, 0.4 + phase * 0.4], [30.6, 1.5, 0.4 + phase * 0.4], 0.16, 'stepdown', phase, false, 1.1);

  const load = group('load', [33, 0, 0]);
  box(load, [0, 0.1, 0], [8, 0.2, 7.7], '#ceddd3', 'load').renderOrder = -990;
  const buildings = [{ x: -1.8, z: -1.5, w: 2.3, d: 2.4, h: 3.1 }, { x: 1.3, z: -1.7, w: 2.1, d: 2.1, h: 4.6 }, { x: 0.4, z: 1.25, w: 4.6, d: 2.5, h: 1.9 }];
  buildings.forEach((building, index) => {
    const { x, z, w, d, h } = building;
    box(load, [x, h / 2 + 0.2, z], [w, h, d], index === 1 ? '#c5d7ce' : '#e2e5d7', 'load');
    box(load, [x, h + 0.27, z], [w + 0.15, 0.15, d + 0.15], '#77948e', 'load');
    for (let row = 0; row < Math.floor(h); row++) for (const offset of [-0.55, 0.55]) box(load, [x + offset, 0.9 + row * 0.9, z + d / 2 + 0.02], [0.5, 0.44, 0.025], '#8ba7af', 'load', 'window', '#ecc66c');
    if (index === 2) for (let panel = 0; panel < 4; panel++) {
      const solarPanel = box(load, [x - 1.5 + panel, h + 0.43, z], [0.75, 0.05, 1.6], '#3a6478', 'load');
      solarPanel.rotation.x = -0.15;
    }
  });

  for (const [x, id, letter] of [[19, 'voltmeter', 'V'], [22, 'ammeter', 'A'], [25, 'wattmeter', 'W']] as [number, string, string][]) {
    const meter = group(id, [x, 0, 5.3]);
    box(meter, [0, 0.2, 0], [1.3, 0.25, 0.9], '#b8cbc5', id);
    cylinder(meter, [0, 0.8, 0], 0.08, 0.08, 1.2, '#708f96', id);
    box(meter, [0, 1.65, 0], [1.2, 1.2, 0.45], '#3c6c7b', id);
    box(meter, [0, 1.65, 0.24], [0.94, 0.95, 0.03], '#e1efdf', id);
    labels.push({ text: letter, id, meter: true, position: new THREE.Vector3(x, 1.65, 5.57) });
  }
  const measure = group('height');
  lines(measure, [[-7, 0.08, 4.3], [-7, clearance, 4.3], [-7.5, 0.08, 4.3], [-6.5, 0.08, 4.3], [-7.5, clearance, 4.3], [-6.5, clearance, 4.3], [-7, clearance, 2.8], [-7, clearance, 4.3]], '#b48a35', 'height', 1.5);
  labels.push({ text: `${heightMeters.toLocaleString('uz-UZ', { maximumFractionDigits: 1 })} m`, id: 'height', position: new THREE.Vector3(-7.7, clearance / 2, 4.4) });
  labels.push({ text: 'Elektr stansiyasi', id: 'source', position: new THREE.Vector3(-28, 5.1, -0.4) });
  labels.push({ text: 'Uch fazali liniya', id: 'line', position: new THREE.Vector3(0, phaseY + 4.3, 0) });
  labels.push({ text: 'Podstansiya', id: 'substation', position: new THREE.Vector3(23, 5.4, -0.4) });
  labels.push({ text: 'Iste’molchi', id: 'load', position: new THREE.Vector3(33, 6.4, -0.3) });

  for (const [x, z] of [[-33, -8], [-18, -9], [-6, -8.3], [8, -9], [23, -8], [35, -8.2]]) {
    cylinder(root, [x, 0.6, z], 0.09, 0.13, 1.2, '#ad9e80');
    const tree = new THREE.Mesh(new THREE.IcosahedronGeometry(0.95, 0), material('#98b5a5'));
    tree.position.set(x, 1.55, z);
    root.add(tree);
  }
  const particleGeometry = new THREE.OctahedronGeometry(0.17, 0);
  curves.forEach((_, curveIndex) => {
    for (let j = 0; j < 3; j++) {
      const particle = new THREE.Mesh(particleGeometry, new THREE.MeshBasicMaterial({ color: PHASE_COLORS[curveIndex % 3] }));
      particle.visible = false;
      root.add(particle);
      particles.push(particle);
    }
  });
  root.updateMatrixWorld(true);
  const bounds = new THREE.Box3().setFromObject(root);
  return {
    root, materials, labels, curves, particles, rotor, height: heightMeters, bounds,
    targets: {
      source: { point: [-28, 1.8, 0], distance: 13 }, stepup: { point: [-21, 2, 0], distance: 9 },
      line: { point: [0, phaseY, 0], distance: 26 }, tower: { point: [0, phaseY / 2, 0], distance: 15 },
      insulator: { point: [0, phaseY + 0.45, 2.8], distance: 5 }, wires: { point: [7, clearance, 0], distance: 13 },
      height: { point: [-7, clearance / 2, 4], distance: 10 }, substation: { point: [22, 2, 0], distance: 14 },
      stepdown: { point: [24, 1.8, 0], distance: 8 }, load: { point: [33, 2, 0], distance: 13 },
      voltmeter: { point: [19, 1.5, 5.3], distance: 5 }, ammeter: { point: [22, 1.5, 5.3], distance: 5 },
      wattmeter: { point: [25, 1.5, 5.3], distance: 5 },
    },
  };
}

function disposeWorld(world: CpuWorld) {
  const geometries = new Set<THREE.BufferGeometry>();
  const materials = new Set<THREE.Material>();
  world.root.traverse(object => {
    if (object instanceof THREE.Mesh || object instanceof THREE.Line) {
      if (object.geometry) geometries.add(object.geometry);
      const allMaterials = Array.isArray(object.material) ? object.material : [object.material];
      allMaterials.forEach(mat => materials.add(mat));
    }
  });
  geometries.forEach(geometry => geometry.dispose());
  materials.forEach(material => material.dispose());
  world.labels.forEach(label => label.element?.remove());
  world.root.removeFromParent();
}

type Runtime = {
  rebuild: (height: number) => void;
  update: () => void;
  focus: (target?: string | null) => void;
};

/** GPU-independent, interactive 3D fallback using Three.js's CPU SVG projection. */
export default function LabSceneSVG(props: LabSceneProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const labelsRef = useRef<HTMLDivElement>(null);
  const current = useRef(props);
  const runtime = useRef<Runtime | null>(null);
  current.current = props;

  useEffect(() => {
    const host = hostRef.current;
    const labelHost = labelsRef.current;
    if (!host || !labelHost) return;
    const labelLayer = labelHost;
    let disposed = false;
    let visible = true;
    let width = host.clientWidth || 800;
    let height = host.clientHeight || 480;
    let frame = 0;
    let lastRender = 0;
    let lastAnimation = 0;
    let dirty = true;
    let moving = false;
    let activePointers = 0;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#e9eff2');
    // SVGRenderer accumulates ambient color directly, so use a muted color instead of white.
    scene.add(new THREE.AmbientLight('#b7c6ce', 1));
    const light = new THREE.DirectionalLight('#ffffff', 0.66);
    light.position.set(-20, 30, 35);
    scene.add(light);
    const fill = new THREE.DirectionalLight('#b7d2e0', 0.14);
    fill.position.set(20, 10, -25);
    scene.add(fill);
    const camera = new THREE.PerspectiveCamera(43, width / height, 0.1, 250);
    const renderer = new SVGRenderer();
    renderer.setPrecision(2);
    renderer.setQuality('high');
    renderer.setSize(width, height);
    renderer.setClearColor(new THREE.Color('#e9eff2'), 1);
    const svg = renderer.domElement as SVGSVGElement;
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Elektr liniyasining hajmli maketi. Sichqoncha yoki barmoq bilan aylantiring. Plus va minus masshtabni, strelkalar ko‘rish burchagini o‘zgartiradi. C umumiy ko‘rinishni tiklaydi.');
    svg.setAttribute('tabindex', '0');
    svg.classList.add('cpu-scene-svg');
    host.prepend(svg);
    // OrbitControls uses the Element pointer/size APIs also implemented by SVGSVGElement.
    const controls = new OrbitControls(camera, svg as unknown as HTMLElement);
    controls.enableDamping = false;
    controls.enablePan = !current.current.compact;
    controls.minDistance = 3;
    controls.maxDistance = 150;
    controls.minPolarAngle = 0.12;
    controls.maxPolarAngle = Math.PI / 2 - 0.035;
    controls.rotateSpeed = 0.8;
    controls.zoomSpeed = 0.8;
    let world = buildWorld(current.current.height);
    scene.add(world.root);
    const targetPosition = new THREE.Vector3();
    const cameraPosition = new THREE.Vector3();
    const projected = new THREE.Vector3();
    const raycaster = new THREE.Raycaster();
    raycaster.params.Line = { threshold: 0.18 };
    const pointer = new THREE.Vector2();
    let down: { x: number; y: number; id: number } | null = null;

    function requestDraw() {
      dirty = true;
      if (!disposed && visible && !document.hidden && frame === 0) frame = requestAnimationFrame(draw);
    }
    function syncAppearance() {
      const state = current.current;
      world.materials.forEach(record => {
        const sameWire = (state.selected === 'line' || state.selected === 'wires') && (record.id === 'line' || record.id === 'wires');
        const selected = !!record.id && (record.id === state.selected || sameWire);
        record.material.color.copy(selected ? new THREE.Color(HIGHLIGHT) : state.energized && record.active ? new THREE.Color(record.active) : record.base);
      });
      world.particles.forEach(particle => { particle.visible = state.energized; });
      world.labels.forEach(label => {
        if (!label.element) return;
        label.element.classList.toggle('is-selected', state.selected === label.id);
        if (label.element.tagName === 'BUTTON') label.element.setAttribute('aria-pressed', String(state.selected === label.id));
      });
      requestDraw();
    }
    function installLabels() {
      labelLayer.replaceChildren();
      for (const label of world.labels) {
        const element = document.createElement(current.current.onSelect ? 'button' : 'span');
        if (element instanceof HTMLButtonElement) {
          element.type = 'button';
          element.setAttribute('aria-label', label.meter ? `${label.id === 'voltmeter' ? 'Voltmetr' : label.id === 'ammeter' ? 'Ampermetr' : 'Vattmetr'} haqida ma’lumot` : `${label.text} haqida ma’lumot`);
          element.addEventListener('click', event => { event.stopPropagation(); if (label.id) current.current.onSelect?.(label.id); });
        }
        element.textContent = label.text;
        element.className = `cpu-scene-label ${label.meter ? 'is-meter' : label.id === 'height' ? 'is-height' : ''}`;
        label.element = element;
        labelLayer.append(element);
      }
    }
    function updateLabels() {
      for (const label of world.labels) {
        if (!label.element) continue;
        projected.copy(label.position).project(camera);
        const showName = (current.current.showLabels ?? true) && !(current.current.compact && label.id === 'load');
        const frontFacing = !label.meter || camera.position.z > label.position.z;
        const show = frontFacing && (label.meter || showName) && projected.z >= -1 && projected.z <= 1 && Math.abs(projected.x) < 0.97 && Math.abs(projected.y) < 0.94;
        label.element.hidden = !show;
        if (!show) continue;
        const scale = label.meter ? Math.min(1.45, Math.max(0.7, 60 / camera.position.distanceTo(label.position))) : 1;
        label.element.style.transform = `translate(${(projected.x + 1) * width / 2}px,${(1 - projected.y) * height / 2}px) translate(-50%,-50%) scale(${scale})`;
      }
    }
    function overview(immediate = false) {
      const center = world.bounds.getCenter(new THREE.Vector3());
      center.y = Math.max(2.5, Math.min(4, world.height * 0.18));
      const direction = new THREE.Vector3(0.65, 0.43, 0.9).normalize();
      const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), direction).normalize();
      const up = new THREE.Vector3().crossVectors(direction, right).normalize();
      const tangent = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
      let distance = 20;
      const fitPoint = (point: THREE.Vector3) => {
        const p = point.clone().sub(center);
        const depth = p.dot(direction);
        distance = Math.max(distance, depth + Math.abs(p.dot(right)) / (tangent * camera.aspect), depth + Math.abs(p.dot(up)) / tangent);
      };
      // Fit real equipment bounds, not an empty giant box whose top corners imply
      // imaginary tall buildings at both ends of the line.
      world.root.updateMatrixWorld(true);
      world.root.traverse(object => {
        if (!(object instanceof THREE.Mesh || object instanceof THREE.Line) || !object.visible) return;
        object.geometry.computeBoundingBox();
        const bound = object.geometry.boundingBox;
        if (!bound) return;
        for (const x of [bound.min.x, bound.max.x]) for (const y of [bound.min.y, bound.max.y]) for (const z of [bound.min.z, bound.max.z]) fitPoint(new THREE.Vector3(x, y, z).applyMatrix4(object.matrixWorld));
      });
      world.labels.forEach(label => fitPoint(label.position));
      targetPosition.copy(center);
      cameraPosition.copy(center).addScaledVector(direction, Math.min(145, distance * 1.07));
      if (immediate) {
        camera.position.copy(cameraPosition);
        controls.target.copy(targetPosition);
        camera.lookAt(targetPosition);
        controls.update();
      } else moving = true;
      requestDraw();
    }
    function focus(target?: string | null) {
      const id = target?.split(':')[0];
      const destination = id && world.targets[id];
      if (!destination) { overview(); return; }
      targetPosition.set(...destination.point);
      const d = destination.distance;
      cameraPosition.copy(targetPosition).add(new THREE.Vector3(d * 0.67, d * 0.55, d));
      moving = true;
      requestDraw();
    }
    function draw(time: number) {
      frame = 0;
      if (disposed || !visible || document.hidden) return;
      const state = current.current;
      const interval = moving || activePointers ? 35 : 70;
      if (time - lastRender >= interval && (dirty || moving || state.energized)) {
        const delta = Math.min(0.1, Math.max(0.001, (time - lastAnimation) / 1000));
        lastAnimation = time;
        if (moving) {
          const alpha = 1 - Math.exp(-delta * 6);
          camera.position.lerp(cameraPosition, alpha);
          controls.target.lerp(targetPosition, alpha);
          controls.update();
          if (camera.position.distanceTo(cameraPosition) < 0.025) moving = false;
        }
        if (state.energized) {
          const load = Number.isFinite(state.loadPercent) ? Math.max(0, Math.min(200, state.loadPercent)) : 100;
          world.curves.forEach((curve, i) => {
            for (let j = 0; j < 3; j++) {
              const particle = world.particles[i * 3 + j];
              const progress = (time * (0.000045 + load * 0.00000045) + j / 3 + i * 0.035) % 1;
              particle.position.copy(curve.getPoint(progress));
              particle.scale.setScalar(0.85 + load / 240);
            }
          });
          world.rotor.rotation.z += delta * 1.3;
        }
        scene.updateMatrixWorld(true);
        renderer.render(scene, camera);
        updateLabels();
        dirty = false;
        lastRender = time;
      }
      // controls.update may already have requested the next frame through its change event.
      if ((moving || current.current.energized || dirty) && frame === 0) frame = requestAnimationFrame(draw);
    }
    function equipmentId(object: THREE.Object3D | null): string | null {
      while (object) {
        if (typeof object.userData.equipmentId === 'string') return object.userData.equipmentId;
        object = object.parent;
      }
      return null;
    }
    function hit(event: PointerEvent) {
      const rect = svg.getBoundingClientRect();
      pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
      raycaster.setFromCamera(pointer, camera);
      for (const intersection of raycaster.intersectObject(world.root, true)) {
        const id = equipmentId(intersection.object);
        if (id) return id;
      }
      return null;
    }
    function pointerDown(event: PointerEvent) {
      activePointers++;
      if (activePointers > 1) down = null;
      else down = { x: event.clientX, y: event.clientY, id: event.pointerId };
    }
    function pointerUp(event: PointerEvent) {
      activePointers = Math.max(0, activePointers - 1);
      if (down && event.pointerId === down.id && Math.hypot(event.clientX - down.x, event.clientY - down.y) < 6) {
        const id = hit(event);
        if (id) current.current.onSelect?.(id);
      }
      down = null;
    }
    function pointerCancel() { down = null; activePointers = 0; }
    function pointerMove(event: PointerEvent) {
      if (activePointers || event.pointerType === 'touch') return;
      svg.style.cursor = current.current.onSelect && hit(event) ? 'pointer' : 'grab';
    }
    function keyDown(event: KeyboardEvent) {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', '+', '=', '-', 'c', 'C'].includes(event.key)) return;
      event.preventDefault();
      moving = false;
      if (event.key.toLowerCase() === 'c') { overview(); return; }
      const offset = camera.position.clone().sub(controls.target);
      if (['+', '=', '-'].includes(event.key)) offset.multiplyScalar(event.key === '-' ? 1.12 : 0.89);
      else {
        const spherical = new THREE.Spherical().setFromVector3(offset);
        if (event.key === 'ArrowLeft') spherical.theta -= 0.12;
        if (event.key === 'ArrowRight') spherical.theta += 0.12;
        if (event.key === 'ArrowUp') spherical.phi -= 0.1;
        if (event.key === 'ArrowDown') spherical.phi += 0.1;
        spherical.phi = THREE.MathUtils.clamp(spherical.phi, controls.minPolarAngle, controls.maxPolarAngle);
        offset.setFromSpherical(spherical);
      }
      offset.setLength(THREE.MathUtils.clamp(offset.length(), controls.minDistance, controls.maxDistance));
      camera.position.copy(controls.target).add(offset);
      controls.update();
      requestDraw();
    }
    const onControlStart = () => { moving = false; };
    controls.addEventListener('change', requestDraw);
    controls.addEventListener('start', onControlStart);
    svg.addEventListener('pointerdown', pointerDown);
    svg.addEventListener('pointerup', pointerUp);
    svg.addEventListener('pointercancel', pointerCancel);
    svg.addEventListener('pointermove', pointerMove);
    svg.addEventListener('keydown', keyDown);
    function resize() {
      const newWidth = host!.clientWidth || 800;
      const newHeight = host!.clientHeight || 480;
      if (newWidth === width && newHeight === height) return;
      width = newWidth; height = newHeight;
      renderer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      if (current.current.focusTarget) focus(current.current.focusTarget); else overview();
      requestDraw();
    }
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(host);
    const visibilityObserver = typeof IntersectionObserver !== 'undefined' ? new IntersectionObserver(entries => {
      visible = entries[0]?.isIntersecting ?? true;
      if (visible) requestDraw();
    }, { threshold: 0.01 }) : null;
    visibilityObserver?.observe(host);
    const documentVisibility = () => { if (!document.hidden) requestDraw(); };
    document.addEventListener('visibilitychange', documentVisibility);
    installLabels();
    syncAppearance();
    overview(true);
    runtime.current = {
      update: syncAppearance,
      focus,
      rebuild: nextHeight => {
        if (Math.abs(nextHeight - world.height) < 1e-9) return;
        disposeWorld(world);
        world = buildWorld(nextHeight);
        scene.add(world.root);
        installLabels();
        syncAppearance();
        if (current.current.focusTarget) focus(current.current.focusTarget);
        requestDraw();
      },
    };
    return () => {
      disposed = true;
      runtime.current = null;
      cancelAnimationFrame(frame);
      controls.removeEventListener('change', requestDraw);
      controls.removeEventListener('start', onControlStart);
      controls.dispose();
      resizeObserver.disconnect();
      visibilityObserver?.disconnect();
      document.removeEventListener('visibilitychange', documentVisibility);
      svg.removeEventListener('pointerdown', pointerDown);
      svg.removeEventListener('pointerup', pointerUp);
      svg.removeEventListener('pointercancel', pointerCancel);
      svg.removeEventListener('pointermove', pointerMove);
      svg.removeEventListener('keydown', keyDown);
      disposeWorld(world);
      renderer.clear();
      svg.remove();
      labelHost.replaceChildren();
      scene.clear();
    };
  }, []);

  useEffect(() => { runtime.current?.rebuild(props.height); }, [props.height]);
  useEffect(() => { runtime.current?.update(); }, [props.selected, props.energized, props.loadPercent, props.showLabels]);
  useEffect(() => { runtime.current?.focus(props.focusTarget); }, [props.focusTarget, props.resetKey]);

  return <div ref={hostRef} className="cpu-scene" data-renderer="three-svg">
    <div ref={labelsRef} className="cpu-scene-labels" />
    <div className="cpu-scene-badge" title="Haqiqiy 3D maket brauzer protsessorida hisoblanadi. Aylantirish, masshtab va obyekt tanlash ishlaydi; WebGL talab qilinmaydi.">
      <span aria-hidden="true" />Mos 3D rejimi
    </div>
  </div>;
}
