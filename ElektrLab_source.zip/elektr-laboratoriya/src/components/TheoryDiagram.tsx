import { useId } from 'react';
import type { ReactNode } from 'react';
import CircuitDiagram from './CircuitDiagram';

export interface TheoryDiagramProps { type: string }

const ink = '#405c74';
const blue = '#3975d8';
const green = '#087f75';
const gold = '#dca23d';

function Label({ x, y, children, color = ink, size = 13 }: { x: number; y: number; children: ReactNode; color?: string; size?: number }) {
  return <text x={x} y={y} textAnchor="middle" fill={color} fontSize={size}>{children}</text>;
}

function Pylon({ x, scale = 1 }: { x: number; scale?: number }) {
  return <g transform={`translate(${x},35) scale(${scale})`} stroke={ink} fill="none" strokeWidth={2} strokeLinejoin="round">
    <path d="M -34 212 L -12 55 L -6 20 L 6 20 L 12 55 L 34 212 M -12 55 H 12 M -17 90 H 17 M -23 130 H 23 M -28 170 H 28 M -34 212 H 34" />
    <path d="M -12 55 L 17 90 L -23 130 L 28 170 L -34 212 M 12 55 L -17 90 L 23 130 L -28 170 L 34 212 M -6 20 L 12 55 M 6 20 L -12 55" strokeWidth={1.5} />
    <path d="M -55 57 L 55 57 L 12 45 M -55 57 L -12 45 M -43 94 L 43 94 L 17 82 M -43 94 L -17 82" />
    {[-49, 0, 49].map((dx, i) => <g key={dx} transform={`translate(${dx},${i === 1 ? 94 : 57})`} stroke={green}>
      <path d="M 0 0 V 24" />
      {[5, 11, 17, 23].map(dy => <ellipse key={dy} cx={0} cy={dy} rx={5} ry={1.5} />)}
    </g>)}
    <path d="M 0 20 V 0" />
  </g>;
}

function DiagramFrame({ title, description, children, height = 270 }: { title: string; description: string; children: ReactNode; height?: number }) {
  const titleId = useId();
  const descriptionId = useId();
  return <svg width="100%" viewBox={`0 0 760 ${height}`} role="img" aria-labelledby={`${titleId} ${descriptionId}`} style={{ display: 'block', fontFamily: 'inherit' }}>
    <title id={titleId}>{title}</title>
    <desc id={descriptionId}>{description}</desc>
    <rect width={760} height={height} fill="#f7fafc" rx={16} />
    {children}
  </svg>;
}

export default function TheoryDiagram({ type }: TheoryDiagramProps) {
  if (type === 'cable') {
    return <DiagramFrame title="Kabelning ko‘ndalang kesimi" description="Ichkaridan tashqariga: tok o‘tkazuvchi o‘zak, ichki yarim o‘tkazuvchi ekran, asosiy izolyatsiya, tashqi yarim o‘tkazuvchi ekran, metall ekran va tashqi himoya qobig‘i." height={306}>
      <g transform="translate(206 150)">
        <circle r={104} fill="#324c61" />
        <circle r={92} fill="#94a8b3" />
        <circle r={81} fill="#364651" />
        <circle r={72} fill="#dcebf3" />
        <circle r={43} fill="#364651" />
        <circle r={34} fill="#c88a32" />
        {[[0, 0], [-15, -9], [0, -18], [15, -9], [-15, 9], [0, 18], [15, 9]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={7.5} fill="#ecc06e" stroke="#aa7026" strokeWidth={1} />)}
      </g>
      {[
        { y: 52, sx: 259, sy: 61, label: 'Tashqi himoya qobig‘i', color: '#324c61' },
        { y: 90, sx: 280, sy: 103, label: 'Metall ekran', color: '#94a8b3' },
        { y: 128, sx: 282, sy: 131, label: 'Tashqi yarim o‘tkazuvchi ekran', color: '#364651' },
        { y: 166, sx: 264, sy: 166, label: 'Asosiy izolyatsiya', color: '#b7d4e4' },
        { y: 204, sx: 244, sy: 168, label: 'Ichki yarim o‘tkazuvchi ekran', color: '#364651' },
        { y: 242, sx: 224, sy: 172, label: 'Tok o‘tkazuvchi o‘zak', color: '#c88a32' },
      ].map(({ y, sx, sy, label, color }) => <g key={label}>
        <path d={`M ${sx} ${sy} L 344 ${y - 4} H 391`} fill="none" stroke="#90a6b8" strokeWidth={1.2} />
        <circle cx={sx} cy={sy} r={3} fill={color} stroke="#ffffff" />
        <circle cx={407} cy={y - 4} r={5} fill={color} />
        <text x={423} y={y} fill={ink} fontSize={13}>{label}</text>
      </g>)}
      <Label x={380} y={285} size={12}>Bir o‘zakli ekranlangan yuqori kuchlanish kabeli · qatlamlar shartli o‘lchamda</Label>
    </DiagramFrame>;
  }
  if (type === 'overhead' || type === 'elements') {
    return <DiagramFrame title="Havo liniyasi tuzilishi" description="Panjarali tayanchlar, uch fazali simlar, osma izolyatorlar, chaqmoqdan himoya trosi va simning yerga eng kichik masofasi." height={310}>
      <path d="M 35 247 H 725" stroke="#c7d8c9" strokeWidth={12} />
      <Pylon x={165} /><Pylon x={595} />
      <path d="M 165 35 Q 380 58 595 35" stroke="#8ca1b3" strokeWidth={1.7} fill="none" />
      <path d="M 116 116 Q 331 178 546 116" stroke={blue} strokeWidth={2.5} fill="none" />
      <path d="M 165 153 Q 380 213 595 153" stroke={green} strokeWidth={2.5} fill="none" />
      <path d="M 214 116 Q 429 178 644 116" stroke={gold} strokeWidth={2.5} fill="none" />
      <path d="M 380 183 V 241 m -5 -6 l 5 6 l 5 -6 m -10 -46 l 5 -6 l 5 6" stroke={ink} strokeWidth={1.3} fill="none" />
      <text x={393} y={215} fill={ink} fontSize={12}>hₘᵢₙ</text>
      <Label x={380} y={26} size={12}>Chaqmoqdan himoya trosi</Label>
      <Label x={165} y={277} size={12}>Po‘lat panjarali tayanch</Label>
      <Label x={595} y={277} size={12}>Osma izolyatorlar</Label>
      <path d="M 596 260 L 643 151" fill="none" stroke="#93a9b7" strokeWidth={1} />
      <Label x={380} y={104} size={13}>Uch faza: A, B, C</Label>
      <Label x={380} y={299} size={11}>Sim salqiligi harorat, tortilish kuchi va oraliq uzunligiga bog‘liq.</Label>
    </DiagramFrame>;
  }
  if (type === 'overview') {
    return <DiagramFrame title="Elektr energiyasini uzatish yo‘li" description="Stansiyadan kuchaytiruvchi transformator orqali yuqori kuchlanish liniyasiga, keyin podstansiya va pasaytiruvchi transformator orqali iste’molchiga energiya uzatiladi." height={260}>
      <g stroke={blue} strokeWidth={2} fill="none">
        <path d="M 114 114 H 153 M 216 114 H 284 M 475 114 H 530 M 593 114 H 645" />
        <path d="M 138 110 l 7 4 l -7 4 M 261 110 l 7 4 l -7 4 M 509 110 l 7 4 l -7 4 M 626 110 l 7 4 l -7 4" />
      </g>
      <g stroke={ink} strokeWidth={2} fill="#ffffff">
        <circle cx={80} cy={114} r={33} />
        <path d="M 58 114 Q 69 92 80 114 Q 91 136 102 114" fill="none" stroke={green} />
        <circle cx={177} cy={114} r={23} /><circle cx={193} cy={114} r={23} />
        <circle cx={553} cy={114} r={23} /><circle cx={569} cy={114} r={23} />
      </g>
      <Pylon x={322} scale={0.66} /><Pylon x={437} scale={0.66} />
      <path d="M 290 89 Q 347 109 405 89 M 322 113 Q 380 133 437 113 M 354 89 Q 411 109 469 89" fill="none" stroke={blue} strokeWidth={1.5} />
      <g fill="#ffffff" stroke={ink} strokeWidth={2}>
        <path d="M 648 143 V 101 L 667 88 L 686 101 V 143 Z" />
        <path d="M 687 143 V 77 H 713 V 143 Z" />
        <path d="M 653 120 H 680 M 700 86 V 92 M 700 104 V 111 M 660 143 V 130 H 670 V 143" />
      </g>
      <Label x={80} y={184} size={12}>Elektr stansiyasi</Label>
      <Label x={185} y={184} size={12}>Kuchaytiruvchi</Label><Label x={185} y={201} size={12}>transformator</Label>
      <Label x={380} y={184} size={12}>Yuqori kuchlanishli</Label><Label x={380} y={201} size={12}>uzatish liniyasi</Label>
      <Label x={561} y={184} size={12}>Pasaytiruvchi</Label><Label x={561} y={201} size={12}>transformator</Label>
      <Label x={685} y={184} size={12}>Iste’molchi</Label>
      <Label x={380} y={239} color={green} size={13}>Bir xil quvvatda kuchlanish oshsa, tok va I²R yo‘qotishlari kamayadi.</Label>
    </DiagramFrame>;
  }
  if (type === 'loss') {
    return <DiagramFrame title="Liniyadagi aktiv quvvat balansi" description="Manbadan olinadigan aktiv quvvat yuklama aktiv quvvati va liniya yo‘qotishlari yig‘indisidan iborat." height={246}>
      <rect x={57} y={75} width={144} height={80} rx={12} fill="#e5eefc" stroke="#b9cdef" />
      <rect x={313} y={75} width={134} height={80} rx={12} fill="#ffffff" stroke="#c8d7e2" />
      <rect x={559} y={75} width={144} height={80} rx={12} fill="#e2f4ed" stroke="#a6d9c5" />
      <Label x={129} y={107}>Manba quvvati</Label><Label x={129} y={132} color={blue}>P₁</Label>
      <Label x={380} y={107}>Liniya</Label><Label x={380} y={132}>R, X</Label>
      <Label x={631} y={107}>Yuklama quvvati</Label><Label x={631} y={132} color={green}>P₂</Label>
      <path d="M 201 115 H 301 l -9 -5 m 9 5 l -9 5 M 447 115 H 547 l -9 -5 m 9 5 l -9 5" stroke={blue} strokeWidth={3} fill="none" />
      <path d="M 380 156 V 187 l -5 -8 m 5 8 l 5 -8" stroke={gold} strokeWidth={3} fill="none" />
      <Label x={380} y={210} color="#9e7124">Issiqlik yo‘qotishi: ΔP = 3I²R</Label>
      <Label x={380} y={39} color={ink}>P₁ = P₂ + ΔP · bu ko‘rinishda shuntdagi aktiv yo‘qotishlar e’tiborga olinmagan</Label>
    </DiagramFrame>;
  }
  if (type === 'models') {
    return <DiagramFrame title="Liniya modellarini tanlash" description="Qisqa liniyada faqat ketma-ket impedans, o‘rta liniyada jamlangan shunt o‘tkazuvchanlik, uzun liniyada uzluksiz taqsimlangan parametrlar hisobga olinadi." height={237}>
      {[
        { x: 18, title: 'Qisqa liniya', formula: 'Z = R + jX', detail: 'Y odatda e’tiborga olinmaydi', note: 'Ko‘pincha l < 80 km' },
        { x: 266, title: 'O‘rta liniya', formula: 'π yoki T', detail: 'Z va Y jamlangan parametrlar', note: 'Ko‘pincha 80–250 km' },
        { x: 514, title: 'Uzun liniya', formula: 'z₀ va y₀', detail: 'Parametrlar uzunlik bo‘ylab tarqalgan', note: 'Ko‘pincha l > 250 km' },
      ].map(card => <g key={card.x}>
        <rect x={card.x} y={25} width={228} height={153} rx={14} fill="#ffffff" stroke="#d7e4ec" />
        <Label x={card.x + 114} y={54} size={14} color={ink}>{card.title}</Label>
        <Label x={card.x + 114} y={90} size={22} color={green}>{card.formula}</Label>
        <Label x={card.x + 114} y={125} size={10.5}>{card.detail}</Label>
        <Label x={card.x + 114} y={151} size={11.5}>{card.note}</Label>
      </g>)}
      <Label x={380} y={209} size={12}>Chegaralar taxminiy: tanlov chastota, kuchlanish, kabel sig‘imi va talab etilgan aniqlikka ham bog‘liq.</Label>
    </DiagramFrame>;
  }
  if (type === 'x') {
    return <DiagramFrame title="Sim atrofidagi magnit maydon" description="O‘zgaruvchan tok sim atrofida magnit maydon hosil qiladi. Induktivlik sababli reaktiv qarshilik X teng omega L bo‘ladi." height={245}>
      <g transform="translate(230 122)">
        {[37, 59, 81].map(r => <circle key={r} r={r} fill="none" stroke={green} strokeWidth={1.6} opacity={1 - r / 130} strokeDasharray="6 4" />)}
        <circle r={17} fill="#e5b764" stroke="#a4722c" strokeWidth={2} />
        <circle r={5} fill={ink} />
        <path d="M -59 -6 l 0 12 l 7 -8 M 80 -6 l 0 12 l -7 -8" fill="none" stroke={green} strokeWidth={2} />
      </g>
      <Label x={230} y={229} size={12}>Tok yo‘nalishi: kuzatuvchi tomon</Label>
      <text x={397} y={80} fill={green} fontSize={24}>X = ωL = 2πfL</text>
      <text x={397} y={120} fill={ink} fontSize={13}>L — induktivlik, H</text>
      <text x={397} y={147} fill={ink} fontSize={13}>f — chastota, Hz · X — qarshilik, Ω</text>
      <text x={397} y={183} fill={ink} fontSize={12}>Magnit oqim o‘zgarishi induktiv kuchlanish hosil qiladi.</text>
    </DiagramFrame>;
  }
  if (type === 'b' || type === 'g') {
    const capacitance = type === 'b';
    return <DiagramFrame title={capacitance ? 'Sim–yer sig‘imi' : 'Izolyatsiyadagi aktiv o‘tkazuvchanlik'} description={capacitance ? 'Faza simi va yer orasidagi elektr maydon ekvivalent sig‘im orqali ifodalanadi.' : 'Izolyatsiya orqali sizish va dielektrik yo‘qotishlar ko‘ndalang aktiv o‘tkazuvchanlik G bilan modellashtiriladi.'} height={252}>
      <line x1={85} y1={59} x2={366} y2={59} stroke={blue} strokeWidth={5} />
      <line x1={225} y1={59} x2={225} y2={109} stroke={ink} strokeWidth={2} />
      {capacitance ? <g stroke={green} strokeWidth={3}>
        <line x1={197} y1={109} x2={253} y2={109} />
        <line x1={197} y1={128} x2={253} y2={128} />
      </g> : <rect x={212} y={109} width={26} height={37} fill="#ffffff" stroke={green} strokeWidth={2.5} />}
      <line x1={225} y1={capacitance ? 128 : 146} x2={225} y2={198} stroke={ink} strokeWidth={2} />
      <path d="M 85 198 H 366 M 207 204 H 243 M 213 211 H 237 M 219 218 H 231" stroke={ink} strokeWidth={2} />
      <Label x={225} y={40} color={blue}>Faza simi</Label>
      <Label x={323} y={221} size={12}>Yer / neytral</Label>
      <text x={427} y={83} fill={green} fontSize={24}>{capacitance ? 'B = ωC = 2πfC' : 'G = 1 / Rᵢ𝓏'}</text>
      <text x={427} y={123} fill={ink} fontSize={13}>{capacitance ? 'Iᶜ = B · Uφ' : 'Iˢᶦᶻ = G · Uφ'}</text>
      <text x={427} y={153} fill={ink} fontSize={13}>{capacitance ? 'B — sig‘im o‘tkazuvchanligi, S' : 'G — aktiv o‘tkazuvchanlik, S'}</text>
      <text x={427} y={183} fill={ink} fontSize={12}>{capacitance ? 'Sig‘im toki kuchlanishdan 90° ilgarilaydi.' : 'Aktiv yo‘qotish: ΔPᵍ = 3G · Uφ²'}</text>
    </DiagramFrame>;
  }
  return <CircuitDiagram
    kind={type === 'r' ? 'r' : type === 'short' ? 'short' : type === 't' ? 't' : type === 'long' ? 'long' : 'pi'}
    R={6}
    X={12}
    G={0}
    B={0.00009}
    compact
  />;
}
