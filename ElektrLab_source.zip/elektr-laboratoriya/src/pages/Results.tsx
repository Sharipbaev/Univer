import { useRef, useState, type ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Award, BookOpen, CheckCircle2, Download, FileDown, Printer, RotateCcw, Trophy, Upload } from 'lucide-react';
import { examQuestions, problems, theorySections } from '../data/curriculum';
import { freshState, scoreState, useStudent } from '../lib/store';
import { exportCsv, exportJson, parseReport } from '../lib/report';
import { fmt, Metric, Notice, PageHeading, Progress } from '../components/UI';
import QuestionCard from '../components/QuestionCard';
import CalculationAssessment from '../components/CalculationAssessment';

const calculationKeys = ['R', 'X', 'I', 'deltaU', 'deltaP'];

export default function ResultsPage() {
  const { state, update, teacher } = useStudent();
  const [questionIndex, setQuestionIndex] = useState(() => {
    const next = examQuestions.findIndex(question => !state.exam[question.id]);
    return next === -1 ? 0 : next;
  });
  const [message, setMessage] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);
  const [importing, setImporting] = useState(false);
  const [revision, setRevision] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const scores = scoreState(state);
  const question = examQuestions[questionIndex];
  const theoretical = theorySections.map(section => state.theory[section.id]);
  const finalAnswers = examQuestions.map(item => state.exam[item.id]);
  const calculationAnswers = calculationKeys.map(key => state.calculations[key]);
  const graded = [...theoretical, ...finalAnswers, ...calculationAnswers];
  const correct = graded.filter(answer => answer?.correct).length;
  const wrong = graded.filter(answer => answer && !answer.correct).length;
  const remaining = graded.filter(answer => !answer).length;
  const finalAnswered = finalAnswers.filter(Boolean).length;
  const practiceCorrect = problems.filter(problem => state.practice[problem.id]?.correct).length;
  const labComplete = new Set(state.labTasks.filter(id => ['inspect', 'energize', 'load', 'height'].includes(id))).size;
  const complete = remaining === 0 && labComplete === 4;

  async function importFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;
    setMessage(null);
    if (file.size > 256_000) { setMessage({ kind: 'error', text: '256 KB dan kichik ElektrLab JSON hisobotini tanlang.' }); return; }
    setImporting(true);
    try {
      const imported = parseReport(await file.text());
      const identification = imported.name || 'Ismi kiritilmagan talaba';
      if (!window.confirm(`${identification}, ${imported.variantId ? `${imported.variantId}-variant` : 'variant olinmagan'}. Ushbu hisobot bilan shu brauzerdagi joriy natijalarni almashtirasizmi? Avval joriy natijani JSON faylga saqlashingiz mumkin.`)) return;
      update(() => imported);
      setRevision(value => value + 1);
      const next = examQuestions.findIndex(item => !imported.exam[item.id]);
      setQuestionIndex(next === -1 ? 0 : next);
      setMessage({ kind: 'success', text: 'Hisobot yuklandi. Test va hisoblash javoblari qayta tekshirildi; ball avtomatik hisoblandi.' });
    } catch (error) {
      setMessage({ kind: 'error', text: error instanceof Error ? error.message : 'Hisobotni yuklashda xato yuz berdi.' });
    } finally { setImporting(false); }
  }

  function resetProgress() {
    if (!window.confirm('Shu talabaning javoblari, laboratoriya vazifalari va o‘tilgan bo‘limlarini tozalaysizmi? Ism va variant saqlanadi. Kerak bo‘lsa avval JSON hisobotni yuklab oling.')) return;
    update(previous => ({ ...freshState(), name: previous.name, variantId: previous.variantId, visited: ['/natijalar'] }));
    setQuestionIndex(0);
    setRevision(value => value + 1);
    setMessage({ kind: 'success', text: 'Mashg‘ulot natijalari tozalandi. Ism va variant saqlandi.' });
  }

  return <div className="results-page">
    <style>{`
      .results-page .result-actions { display: flex; flex-wrap: wrap; gap: 9px; }
      .results-page .score-overview { display: grid; grid-template-columns: minmax(220px,.8fr) minmax(0,1.4fr); gap: 30px; align-items: center; }
      .results-page .score-identity { display: flex; align-items: center; gap: 19px; }
      .results-page .score-medal { width: 76px; height: 76px; border-radius: 23px; background: #e5f5ec; color: #118568; display: grid; place-items: center; flex-shrink: 0; }
      .results-page .score-identity h2 { margin: 0 0 5px; font-size: 21px; overflow-wrap: anywhere; }
      .results-page .score-identity p { margin: 0; color: #778797; font-size: 13px; }
      .results-page .score-number { margin: 23px 0 0; font-size: 52px; font-weight: 750; letter-spacing: -2px; line-height: 1.1; color: #153b38; }
      .results-page .score-number small { margin-left: 8px; font-size: 19px; font-weight: 500; color: #7a8c99; letter-spacing: 0; }
      .results-page .score-categories { display: grid; gap: 15px; }
      .results-page .score-category { display: grid; grid-template-columns: 150px 1fr 60px; gap: 12px; align-items: center; font-size: 13px; }
      .results-page .category-track { height: 8px; border-radius: 12px; overflow: hidden; background: #edf2f5; }
      .results-page .category-track span { display: block; height: 100%; border-radius: inherit; background: #198778; }
      .results-page .score-category strong { text-align: right; color: #33516b; font-size: 13px; }
      .results-page .results-counts { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 15px; margin: 22px 0; }
      .results-page .exam-shell { display: grid; grid-template-columns: minmax(0,1fr) 235px; gap: 24px; align-items: start; }
      .results-page .exam-numbers { display: grid; grid-template-columns: repeat(5,1fr); gap: 7px; margin: 15px 0; }
      .results-page .exam-number { border: 1px solid #dce6ec; border-radius: 9px; min-height: 36px; cursor: pointer; background: white; color: #53687a; font-weight: 650; }
      .results-page .exam-number.correct { background: #e6f5ed; border-color: #adcfbd; color: #167953; }
      .results-page .exam-number.wrong { background: #fff0e9; border-color: #f0c8b7; color: #ab5530; }
      .results-page .exam-number.current { outline: 2px solid #367bce; outline-offset: 2px; }
      .results-page .exam-nav { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-top: 20px; }
      .results-page .recommendations { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 13px; }
      .results-page .recommendation { display: flex; align-items: center; justify-content: space-between; gap: 14px; padding: 16px; border: 1px solid #e1e9ef; border-radius: 12px; color: #35516a; text-decoration: none; background: #fff; text-align: left; cursor: pointer; font: inherit; }
      .results-page .recommendation strong { display: block; font-size: 13px; margin-bottom: 4px; }
      .results-page .recommendation small { display: block; color: #778797; font-size: 12px; line-height: 1.5; }
      .results-page .results-tools { display: grid; grid-template-columns: minmax(0,1fr) auto; gap: 20px; align-items: end; margin-top: 24px; }
      .results-page .answer-reference { display: grid; gap: 13px; margin-top: 20px; }
      .results-page .answer-reference article { padding: 15px; background: #f7fafb; border-radius: 10px; }
      .results-page .answer-reference h4 { margin: 0 0 8px; }
      .results-page .answer-reference p { margin: 6px 0 0; font-size: 13px; }
      .results-page section.panel { margin-bottom: 24px; }
      .results-page .exam-status { border-radius: 12px; background: #f5f8fb; padding: 17px; }
      .results-page .exam-status h3 { font-size: 14px; margin-top: 0; }
      @media (max-width: 850px) {
        .results-page .score-overview,.results-page .exam-shell,.results-page .results-tools { grid-template-columns: 1fr; }
        .results-page .exam-status { order: -1; }
        .results-page .exam-numbers { grid-template-columns: repeat(10,1fr); }
        .results-page .results-counts { grid-template-columns: repeat(2,minmax(0,1fr)); }
      }
      @media (max-width: 540px) {
        .results-page .recommendations { grid-template-columns: 1fr; }
        .results-page .score-category { grid-template-columns: 125px 1fr 55px; gap: 8px; }
        .results-page .exam-numbers { grid-template-columns: repeat(5,1fr); }
      }
      @media print {
        .results-page .no-print,.results-page #final-exam,.results-page .calculation-exam { display: none !important; }
        .results-page .score-overview { grid-template-columns: 1fr 1.4fr; }
        .results-page .panel { break-inside: avoid; }
      }
    `}</style>
    <PageHeading step="08 / TEST VA NATIJALAR" title="Bilimingizni natijaga aylantiring" description="10 ta yakuniy test va 5 ta hisoblash topshirig‘i. Har bir javobni tekshiring va shaxsiy hisobotni saqlang." action={<button className="btn secondary no-print" onClick={() => window.print()}><Printer size={17}/> Hisobotni chop etish</button>}/>

    <section className="panel">
      <div className="score-overview">
        <div>
          <div className="score-identity"><span className="score-medal"><Trophy size={34}/></span><div><span className="eyebrow">{complete ? 'YAKUNIY NATIJA' : 'JORIY NATIJA'}</span><h2>{state.name || 'Ism-familiya kiritilmagan'}</h2><p>{state.variantId ? `${state.variantId}-individual variant` : 'Individual variant hali olinmagan'}</p></div></div>
          <div className="score-number">{fmt(scores.total, 1)}<small>/ 100 ball</small></div>
          <p className="fine-print">{complete ? 'Barcha baholanadigan topshiriqlar bajarilgan.' : 'Natija tekshirilgan javoblaringiz asosida yangilanadi.'}</p>
        </div>
        <div className="score-categories">
          {[
            { label: 'Nazariy mini-testlar', value: scores.theory, max: 20, color: '#5680cf' },
            { label: 'Virtual laboratoriya', value: scores.lab, max: 20, color: '#198778' },
            { label: 'Hisoblash topshiriqlari', value: scores.calculations, max: 40, color: '#d29a44' },
            { label: 'Yakuniy test', value: scores.exam, max: 20, color: '#7a6bb7' },
          ].map(item => <div className="score-category" key={item.label}><span>{item.label}</span><div className="category-track" role="progressbar" aria-label={item.label} aria-valuenow={item.value} aria-valuemin={0} aria-valuemax={item.max}><span style={{ width: `${item.value / item.max * 100}%`, background: item.color }}/></div><strong>{fmt(item.value, 1)} / {item.max}</strong></div>)}
        </div>
      </div>
      <div className="results-counts"><Metric label="To‘g‘ri javoblar" value={correct} unit="ta" accent/><Metric label="Noto‘g‘ri javoblar" value={wrong} unit="ta"/><Metric label="Hali javobsiz" value={remaining} unit="ta"/><Metric label="Laboratoriya vazifalari" value={`${labComplete} / 4`} hint="Har biri 5 ball"/></div>
      <p className="fine-print">Javoblar statistikasi: 12 ta nazariy mini-test, 5 ta individual hisoblash va 10 ta yakuniy test. Mustaqil mashqlardan {practiceCorrect} / {problems.length} tasi to‘g‘ri; mashqlar bahoga qo‘shilmaydi.</p>
      {!state.name && <Notice>Hisobotda ismingiz chiqishi uchun <Link to="/">bosh sahifada ism-familiyangizni saqlang</Link>.</Notice>}
    </section>

    <section className="panel no-print" id="final-exam">
      <div className="section-title"><div><span className="eyebrow">YAKUNIY NAZARIY TEST · 20 BALL</span><h2>O‘rganganlaringizni tekshiring</h2></div><span className="pill">Har bir javob — 2 ball</span></div>
      <div className="exam-shell">
        <div>
          <QuestionCard key={`exam-${question.id}-${state.exam[question.id]?.selected ?? 'new'}-${teacher}-${revision}`} question={question} saved={state.exam[question.id]} teacher={teacher} number={questionIndex + 1} onCheck={answer => { if (!teacher) update(previous => ({ ...previous, exam: { ...previous.exam, [question.id]: answer } })); }}/>
          <div className="exam-nav"><button className="btn secondary" disabled={questionIndex === 0} onClick={() => setQuestionIndex(index => Math.max(0, index - 1))}><ArrowLeft size={16}/> Oldingi savol</button><span className="fine-print">{questionIndex + 1} / {examQuestions.length}</span><button className="btn primary" disabled={questionIndex === examQuestions.length - 1} onClick={() => setQuestionIndex(index => Math.min(examQuestions.length - 1, index + 1))}>Keyingi savol <ArrowRight size={16}/></button></div>
        </div>
        <aside className="exam-status"><h3>Test jarayoni</h3><Progress value={finalAnswered / examQuestions.length * 100} label={`${finalAnswered} / ${examQuestions.length} javob tekshirildi`}/><nav className="exam-numbers" aria-label="Test savollari">{examQuestions.map((item, index) => <button key={item.id} aria-label={`${index + 1}-savol${state.exam[item.id] ? state.exam[item.id].correct ? ', to‘g‘ri' : ', noto‘g‘ri' : ', javobsiz'}`} aria-current={index === questionIndex ? 'step' : undefined} className={`exam-number ${index === questionIndex ? 'current' : ''} ${state.exam[item.id] ? state.exam[item.id].correct ? 'correct' : 'wrong' : ''}`} onClick={() => setQuestionIndex(index)}>{index + 1}</button>)}</nav><p className="fine-print">Yashil — to‘g‘ri. Sariq — qayta ishlash kerak. Bo‘sh katak — javob tekshirilmagan.</p><p className="fine-print">Javobni qayta tekshirishingiz mumkin. Oxirgi tekshirilgan javob bahoga olinadi.</p></aside>
      </div>
      {teacher && <details style={{ marginTop: 24 }}><summary>Barcha 10 ta savolning javobi va izohini ochish</summary><div className="answer-reference">{examQuestions.map(item => <article key={item.id}><h4>{item.id}. {item.prompt}</h4><strong className="success-text">{String.fromCharCode(65 + item.correct)}. {item.options[item.correct]}</strong><p>{item.explanation}</p></article>)}</div></details>}
    </section>

    <section className="panel calculation-exam no-print"><div className="section-title"><div><span className="eyebrow">HISOBLASH TOPSHIRIQLARI · 40 BALL</span><h2>R, X, I, ΔU va ΔP ni hisoblang</h2></div><span className="pill">Har biri — 8 ball</span></div><p className="fine-print">Bu topshiriqlar individual variant sahifasi bilan bir xil saqlanadi: bir topshiriq ikki marta baholanmaydi.</p><CalculationAssessment key={`assessment-${revision}`}/></section>

    <section className="panel">
      <div className="section-title"><div><span className="eyebrow">KEYINGI QADAM</span><h2>{scores.total === 100 ? 'Barcha maqsadlarga erishdingiz' : 'Siz uchun tavsiyalar'}</h2></div><Award size={25}/></div>
      {scores.total === 100 ? <Notice kind="success">Nazariya, tajriba va hisoblash bo‘yicha barcha topshiriqlar to‘g‘ri bajarildi. Endi sxemalar sahifasida π, T va uzun liniya modellari natijalarini solishtiring.</Notice> : <div className="recommendations">
        {scores.theory < 20 && <Link className="recommendation" to="/nazariya"><span><strong>Nazariy asoslarni mustahkamlang</strong><small>{theoretical.filter(answer => answer?.correct).length} / 12 mini-test to‘g‘ri. Formulalar va birliklarni qayta ko‘ring.</small></span><BookOpen size={20}/></Link>}
        {scores.lab < 20 && <Link className="recommendation" to="/laboratoriya"><span><strong>Laboratoriya vazifalarini yakunlang</strong><small>{4 - labComplete} ta vazifa qoldi. Qurilmalarni tekshiring va parametrlarni o‘zgartiring.</small></span><ArrowRight size={20}/></Link>}
        {scores.calculations < 40 && <Link className="recommendation" to="/variant"><span><strong>Hisoblashni bosqichma-bosqich bajaring</strong><small>Tokni kA, kuchlanish tushuvini kV, quvvat yo‘qotishini MW da kiriting.</small></span><ArrowRight size={20}/></Link>}
        {scores.exam < 20 && <button className="recommendation" onClick={() => { const index = examQuestions.findIndex(item => !state.exam[item.id]?.correct); setQuestionIndex(Math.max(0, index)); document.getElementById('final-exam')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}><span><strong>Yakuniy test izohlarini o‘qing</strong><small>{finalAnswers.filter(answer => answer?.correct).length} / 10 javob to‘g‘ri. Qolgan savollarga qayting.</small></span><CheckCircle2 size={20}/></button>}
      </div>}
    </section>

    <section className="panel">
      <div className="section-title"><div><span className="eyebrow">SHAXSIY HISOBOT</span><h2>Natijangizni saqlang</h2></div><FileDown size={24}/></div>
      <p>Natijalar shu brauzerning localStorage xotirasida saqlanadi. Ular boshqa kompyuter yoki telefonga avtomatik uzatilmaydi. Davom ettirish uchun JSON hisobotni yuklab, boshqa qurilmada shu sahifadan qayta oching.</p>
      <div className="results-tools no-print"><div className="result-actions"><button className="btn primary" onClick={() => { exportJson(state); setMessage({ kind: 'success', text: 'JSON hisobotni yuklab olish boshlandi. Uni boshqa qurilmada import qilib davom ettirishingiz mumkin.' }); }}><Download size={16}/> JSON hisobot</button><button className="btn secondary" onClick={() => { exportCsv(state); setMessage({ kind: 'success', text: 'CSV jadvalni yuklab olish boshlandi. Uni elektron jadval dasturida ochishingiz mumkin.' }); }}><FileDown size={16}/> CSV jadval</button><button className="btn secondary" onClick={() => inputRef.current?.click()} disabled={importing}><Upload size={16}/> {importing ? 'O‘qilmoqda…' : 'JSON yuklash'}</button><input ref={inputRef} type="file" accept=".json,application/json" onChange={importFile} hidden aria-label="ElektrLab JSON hisobotini tanlang"/></div><button className="btn text" onClick={resetProgress}><RotateCcw size={15}/> Natijalarni tozalash</button></div>
      {message && <div style={{ marginTop: 16 }}><Notice kind={message.kind}>{message.text}</Notice></div>}
      <p className="fine-print" style={{ marginTop: 20 }}>Bu statik o‘quv platformasidagi ballarni brauzer egasi o‘zgartira oladi. Hisobot va o‘qituvchi PIN-kodi rasmiy imtihon uchun himoyalangan autentifikatsiya o‘rnini bosa olmaydi; markaziy tekshiruv uchun server tizimi kerak.</p>
    </section>
  </div>;
}
