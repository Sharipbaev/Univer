import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import { StudentProvider } from './lib/store';
import App from './App';
import 'katex/dist/katex.min.css';
import './styles.css';

createRoot(document.getElementById('root')!).render(<StrictMode><HashRouter><StudentProvider><App/></StudentProvider></HashRouter></StrictMode>);

