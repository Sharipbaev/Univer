import { lazy, Suspense, useEffect, useState } from 'react';
import { NavLink, Route, Routes, useLocation, useNavigate, Link } from 'react-router-dom';
import { Activity, ArrowLeft, BookOpen, Box, Calculator, Check, ChevronRight, ClipboardList, GraduationCap, Home, Menu, Network, ShieldCheck, Trophy, UserRound, X, Zap } from 'lucide-react';
import { useStudent, scoreState } from './lib/store';
import { Loading, Notice, Progress } from './components/UI';
const HomePage = lazy(() => import('./pages/Home'));
const TheoryPage = lazy(() => import('./pages/Theory'));
const LaboratoryPage = lazy(() => import('./pages/Laboratory'));
const CircuitsPage = lazy(() => import('./pages/Circuits'));
const CalculatorPage = lazy(() => import('./pages/Calculator'));
const ProblemsPage = lazy(() => import('./pages/Problems'));
const VariantPage = lazy(() => import('./pages/Variant'));
const ResultsPage = lazy(() => import('./pages/Results'));
const nav = [
  { to: '/', label: 'Bosh sahifa', icon: Home },
  { to: '/nazariya', label: 'Nazariy materiallar', icon: BookOpen },
  { to: '/laboratoriya', label: '3D laboratoriya', icon: Box },
  { to: '/sxemalar', label: 'Almashtiruv sxemalari', icon: Network },
  { to: '/kalkulyator', label: 'Hisoblash markazi', icon: Calculator },
  { to: '/masalalar', label: 'Mustaqil masalalar', icon: ClipboardList },
  { to: '/variant', label: 'Individual variant', icon: UserRound },
  { to: '/natijalar', label: 'Test va natijalar', icon: Trophy }
];
function TeacherModal({ close }: { close: () => void }) {
  const { setTeacher } = useStudent();
  const [pin, setPin] = useState(''); const [error, setError] = useState('');
  return <div className="modal-backdrop" onClick={close}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="teacher-title" onClick={e => e.stopPropagation()}><button className="icon-btn modal-close" onClick={close} aria-label="Yopish"><X/></button><div className="icon-tile"><ShieldCheck/></div><h2 id="teacher-title">O‘qituvchi rejimi</h2><p>Yechimlar bazasi va baholash mezonlarini oching. Bu rejim darsni namoyish qilish uchun mo‘ljallangan.</p><form onSubmit={e => { e.preventDefault(); if (pin === (import.meta.env.VITE_TEACHER_PIN || '2468')) { setTeacher(true); close(); } else setError('PIN noto‘g‘ri. O‘qituvchi yo‘riqnomasini tekshiring.'); }}><label htmlFor="teacher-pin">O‘qituvchi PIN-kodi</label><input autoFocus id="teacher-pin" type="password" autoComplete="off" value={pin} onChange={e => { setPin(e.target.value); setError(''); }}/>{error && <p className="field-error">{error}</p>}<button className="btn primary full" type="submit"><ShieldCheck size={17}/> Rejimga kirish</button></form><p className="fine-print">Statik versiyadagi PIN faqat interfeysni ajratadi. Rasmiy nazorat uchun serverdagi autentifikatsiya kerak.</p></section></div>;
}
export default function App() {
  const { state, update, teacher, setTeacher, storageError } = useStudent();
  const [mobileOpen, setMobileOpen] = useState(false); const [teacherModal, setTeacherModal] = useState(false);
  const location = useLocation(); const navigate = useNavigate();
  const page = nav.find(n => n.to === location.pathname) || nav[0];
  const scores = scoreState(state);
  useEffect(() => {
    setMobileOpen(false); window.scrollTo({ top: 0 });
    document.title = `${page.label} · ElektrLab`;
    update(s => s.visited.includes(location.pathname) ? s : { ...s, visited: [...s.visited, location.pathname] });
  }, [location.pathname]);
  return <div className="app-shell">
    {mobileOpen && <button className="sidebar-scrim" onClick={() => setMobileOpen(false)} aria-label="Menyuni yopish"/>}
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <Link className="brand" to="/"><span className="brand-mark"><Zap fill="currentColor" size={24}/></span><span>Elektr<span className="brand-light">Lab</span><small>VIRTUAL TA’LIM MUHITI</small></span></Link>
      <div className="sidebar-course"><span className="tiny-dot"/> ELEKTR ENERGETIKASI<span>Amaliy mashg‘ulot № 1</span></div>
      <span className="nav-caption">O‘QUV BO‘LIMLARI</span>
      <nav aria-label="Asosiy navigatsiya">{nav.map(n => <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><n.icon size={19}/><span>{n.label}</span>{state.visited.includes(n.to) && n.to !== '/' && <Check size={13} className="nav-check"/>}</NavLink>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-progress"><GraduationCap size={21}/><h3>Har bir tajriba — yangi bilim</h3><Progress value={scores.total} label="To‘plangan ball"/><Link to="/natijalar">Natijalarni ko‘rish <ChevronRight size={15}/></Link></div><div className="local-status"><span/> Natijalar shu brauzerda saqlanadi</div></div>
    </aside>
    <div className="main-shell"><header className="topbar"><div className="breadcrumbs"><button className="icon-btn mobile-menu" aria-label="Menyuni ochish" onClick={() => setMobileOpen(true)}><Menu size={21}/></button>{location.pathname !== '/' && <button className="icon-btn" aria-label="Ortga qaytish" onClick={() => window.history.state?.idx > 0 ? navigate(-1) : navigate('/')}><ArrowLeft size={18}/></button>}<Link to="/" className="breadcrumb-root">O‘quv platformasi</Link><ChevronRight size={14}/><span>{page.label}</span></div><div className="top-actions"><button className={`mode-button ${teacher ? 'teacher' : ''}`} onClick={() => teacher ? setTeacher(false) : setTeacherModal(true)}>{teacher ? <ShieldCheck size={16}/> : <GraduationCap size={17}/>}<span>{teacher ? 'O‘qituvchi rejimi' : 'Talaba rejimi'}</span></button><Link to="/variant" className="avatar" aria-label="Talaba profiliga o‘tish">{state.name ? state.name.split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase() : <UserRound size={19}/>}</Link></div></header>
      <main id="main-content" className="main-content">{storageError && <Notice kind="warning">Brauzer xotirasiga yozish imkoni yo‘q. Ishingizni yo‘qotmaslik uchun «Test va natijalar» bo‘limidan hisobotni yuklab oling.</Notice>}{teacher && <div className="teacher-banner"><ShieldCheck size={16}/> O‘qituvchi rejimi faol. Yechimlarni ko‘rish bahoga qo‘shilmaydi.<button onClick={() => setTeacher(false)}>Talaba rejimiga qaytish</button></div>}<Suspense fallback={<Loading/>}><Routes><Route path="/" element={<HomePage/>}/><Route path="/nazariya" element={<TheoryPage/>}/><Route path="/laboratoriya" element={<LaboratoryPage/>}/><Route path="/sxemalar" element={<CircuitsPage/>}/><Route path="/kalkulyator" element={<CalculatorPage/>}/><Route path="/masalalar" element={<ProblemsPage/>}/><Route path="/variant" element={<VariantPage/>}/><Route path="/natijalar" element={<ResultsPage/>}/><Route path="*" element={<div className="panel"><h1>Sahifa topilmadi</h1><Link to="/" className="btn primary">Bosh sahifaga qaytish</Link></div>}/></Routes></Suspense></main>
      <footer className="footer"><span><Zap size={14}/> Elektr tarmoqlari va tizimlari</span><span>O‘rganing. Tajriba qiling. Hisoblang.</span><span><Activity size={14}/> 50 Hz · Uch fazali tizim</span></footer>
    </div>{teacherModal && <TeacherModal close={() => setTeacherModal(false)}/>}
  </div>;
}
