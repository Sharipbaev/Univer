export interface Equipment {
  id: string;
  name: string;
  category: string;
  purpose: string;
  construction: string;
  principle: string;
  impact: string;
  formula: string;
  application: string;
}

export const equipment: Equipment[] = [
  {
    id: 'source', name: 'Elektr stansiyasi', category: 'Energiya manbai',
    purpose: 'Mexanik yoki boshqa birlamchi energiyani uch fazali elektr energiyasiga aylantiradi.',
    construction: 'Generator, birlamchi harakatlantirgich, qo‘zg‘atish tizimi, shinalar va himoya apparatlaridan tuziladi.',
    principle: 'Generatorning aylanuvchi magnit maydoni stator chulg‘amlarida bir-biridan 120° siljigan uchta elektr yurituvchi kuchni hosil qiladi.',
    impact: 'Manbaning kuchlanishi va chastotasi liniyadagi ish rejimini belgilaydi. Ushbu laboratoriyada simmetrik, 50 Hz li barqaror rejim qabul qilingan.',
    formula: 'P=\\sqrt{3}UI\\cos\\varphi',
    application: 'Issiqlik, gidroelektr va boshqa elektr stansiyalarida elektr tarmog‘ini ta’minlash uchun ishlatiladi.',
  },
  {
    id: 'stepup', name: 'Kuchaytiruvchi transformator', category: 'Kuchlanishni o‘zgartirish',
    purpose: 'Generator kuchlanishini uzatish tarmog‘ining yuqori kuchlanish darajasiga ko‘taradi.',
    construction: 'Magnit o‘zak, birlamchi va ikkilamchi chulg‘amlar, moy baki, radiatorlar, kengaytirgich hamda yuqori kuchlanish kirish izolyatorlariga ega.',
    principle: 'O‘zgaruvchan magnit oqimi elektromagnit induksiya orqali ikkilamchi chulg‘amda kuchlanish hosil qiladi. Ideal modelda faza chulg‘amlaridagi kuchlanishlar nisbati o‘ramlar nisbatiga teng. Liniyalararo kuchlanishlar nisbati chulg‘amlarning ulanish guruhiga ham bog‘liq.',
    impact: 'Bir xil uzatilayotgan quvvatda kuchlanishni oshirish tokni, natijada I²R yo‘qotishlarini kamaytiradi. Transformatorning o‘z yo‘qotishlari sodda liniya hisobiga kiritilmagan.',
    formula: '\\frac{U_{2\\mathrm{f}}}{U_{1\\mathrm{f}}}=\\frac{N_2}{N_1},\\qquad I\\propto\\frac{1}{U}',
    application: 'Elektr stansiyasining chiqish podstansiyasida uzoq masofaga energiya uzatish oldidan qo‘llanadi.',
  },
  {
    id: 'line', name: 'Yuqori kuchlanishli liniya', category: 'Elektr energiyasini uzatish',
    purpose: 'Manba bilan qabul qiluvchi podstansiyani bog‘lab, elektr energiyasini masofaga uzatadi.',
    construction: 'Faza simlari, tayanchlar, izolyatorlar, chaqmoqdan himoya trosi va yerga ulash qurilmalaridan tashkil topadi.',
    principle: 'Tok simlarda oqadi; simlarning magnit va elektr maydonlari induktiv hamda sig‘im xususiyatlarini yuzaga keltiradi. Yorug‘lik nuqtalari energiya uzatish yo‘nalishining shartli belgisi: ular tokning lahzaviy yo‘nalishi yoki tarqalish tezligini o‘lchamaydi.',
    impact: 'Uzunlik ortganda R, X, G va B yig‘indi parametrlari o‘sadi. O‘rta va uzun liniyalarda ko‘ndalang sig‘im toklarini hisobga olish muhim.',
    formula: 'Z=(r_0+jx_0)l,\\qquad Y=(g_0+jb_0)l',
    application: 'Elektr stansiyalari, hududiy podstansiyalar va yirik elektr iste’molchilarini birlashtiradi.',
  },
  {
    id: 'tower', name: 'Elektr uzatish tayanchi', category: 'Mexanik konstruksiya',
    purpose: 'Simlarni yer sathidan ko‘tarib turadi va fazalar orasidagi zarur geometrik masofani saqlaydi.',
    construction: 'Po‘lat panjarasimon ustun, ko‘ndalang traversalar, poydevor va izolyatorlarni mahkamlash tugunlaridan iborat.',
    principle: 'Simlar og‘irligi, tortilish kuchi va tashqi mexanik yuklar fazoviy sterjenlar tizimi orqali poydevorga uzatiladi.',
    impact: 'Fazalar joylashuvi induktivlik va sig‘imga ta’sir qiladi. Tayanchning o‘zi normal rejimda faza tokini o‘tkazmaydi; metall konstruksiya yerga ulanadi.',
    formula: 'D_{\\mathrm{eq}}=\\sqrt[3]{D_{12}D_{23}D_{31}}',
    application: 'Havo elektr uzatish liniyalarida oraliq, anker va burchak tayanchlari sifatida qo‘llanadi.',
  },
  {
    id: 'insulator', name: 'Osma izolyatorlar', category: 'Elektr izolyatsiyasi',
    purpose: 'Kuchlanish ostidagi simni yerga ulangan metall tayanchdan elektr jihatdan ajratadi.',
    construction: 'Chinni, shisha yoki kompozit dielektrik elementlar hamda metall biriktirgichlardan tuzilgan zanjir.',
    principle: 'Dielektrik qatlam va yetarli sirt bo‘ylab oqish yo‘li kuchlanishga chidamlilikni ta’minlaydi. Namlik va ifloslanish sirt oqish tokini oshirishi mumkin.',
    impact: 'Izolyatsiya bo‘ylab oqish aktiv o‘tkazuvchanlik G tarkibiga hissa qo‘shadi. Formulada G — bir fazaning jamlangan o‘tkazuvchanligi (S), U — liniyalararo kuchlanish (kV); P_G natijasi MW da olinadi. G ideal izolyatsiyada juda kichik deb olinadi.',
    formula: 'P_G=3U_{\\mathrm{f}}^2G=U^2G',
    application: 'Havo liniyalari, podstansiya shinalari va yuqori kuchlanish apparatlarida ishlatiladi.',
  },
  {
    id: 'wires', name: 'Uch fazali simlar', category: 'Tok o‘tkazuvchi qism',
    purpose: 'A, B va C fazalar bo‘yicha energiyani uzatadi; muvozanatlangan rejimda faza toklarining vektor yig‘indisi nolga teng.',
    construction: 'Amalda alyuminiy, alyuminiy-qotishma yoki po‘lat o‘zakli alyuminiy tolalardan o‘ralgan o‘tkazgichlar qo‘llanadi.',
    principle: 'Simning cheklangan elektr o‘tkazuvchanligi issiqlik yo‘qotishini, uning magnit maydoni esa induktiv qarshilikni hosil qiladi.',
    impact: 'Kesim ortishi aktiv qarshilikni kamaytiradi. R formulasida ρ — solishtirma qarshilik (Ω·mm²/m), l_m — uzunlik (m), A — kesim yuzi (mm²). Induktiv qarshilik formulasida f — chastota (Hz), L_ind — induktivlik (H).',
    formula: 'R=\\rho\\frac{l_m}{A},\\qquad X=2\\pi fL_{\\mathrm{ind}}',
    application: 'Energiya uzatishda o‘tkazgich kesimi qizish, yo‘qotish va mexanik mustahkamlik shartlari bo‘yicha tanlanadi.',
  },
  {
    id: 'height', name: 'Simning yerga balandligi', category: 'Geometrik o‘lchov',
    purpose: 'Sim osilishining eng past nuqtasi bilan yer orasidagi masofani ko‘rsatadi.',
    construction: 'Sahnadagi o‘lchov chizig‘i asosiy oraliq o‘rtasidan yer sathigacha tushirilgan. Balandlik slayderi shu minimal masofani o‘zgartiradi.',
    principle: 'Sim o‘z og‘irligi ostida osiladi. Ushbu vizual maketda osilish parabola bilan yaqinlashtirilgan; u mexanik loyiha hisobi o‘rnini bosmaydi.',
    impact: 'Balandlik elektr maydoni va yerga nisbatan sig‘imga ta’sir qilishi mumkin. Kalkulyatorda b₀ foydalanuvchi kiritadigan mustaqil parametr bo‘lib, slayder uni avtomatik qayta hisoblamaydi.',
    formula: 'h(x)=h_{\\mathrm{tayanch}}-4f_{\\mathrm{osilish}}\\frac{x}{a}\\left(1-\\frac{x}{a}\\right)',
    application: 'Haqiqiy liniyada minimal masofalar kuchlanish, hudud va amaldagi me’yorlar asosida muhandis tomonidan belgilanadi.',
  },
  {
    id: 'substation', name: 'Qabul qiluvchi podstansiya', category: 'Taqsimlash tuguni',
    purpose: 'Uzatish liniyasidan energiyani qabul qiladi, kommutatsiya, himoya, o‘lchash va keyingi taqsimlashni bajaradi.',
    construction: 'Shinalar, uzgichlar, ajratkichlar, transformatorlar, izolyatorlar, o‘lchov transformatorlari va yerga ulash tizimidan iborat.',
    principle: 'Kommutatsiya apparatlari elektr ulanishlarni o‘zgartiradi, rele himoyasi esa nosozlik yuz bergan qismlarni ajratadi.',
    impact: 'Ulanish holati elektr zanjirining yaxlitligini belgilaydi. Sahnadagi yoqish tugmasi o‘quv modelida energiya uzatilishini boshqaradi.',
    formula: '\\sum P_{\\mathrm{kirim}}=\\sum P_{\\mathrm{chiqim}}+\\Delta P',
    application: 'Magistral va taqsimlash tarmoqlarini bog‘lash, yuklamalarni boshqarish hamda elektr ta’minoti ishonchliligini ta’minlashda ishlatiladi.',
  },
  {
    id: 'stepdown', name: 'Pasaytiruvchi transformator', category: 'Kuchlanishni o‘zgartirish',
    purpose: 'Uzatish tarmog‘idagi yuqori kuchlanishni iste’molchilarga mos pastroq darajaga tushiradi.',
    construction: 'Magnit o‘zak, yuqori va past kuchlanish chulg‘amlari, sovitish radiatorlari, moy baki hamda kirish izolyatorlaridan tuziladi.',
    principle: 'Ideal transformatorda quvvat saqlanadi: kuchlanish kamaygan tomonda tok kattalashadi. Formuladagi U_f va I_f har bir chulg‘am fazasiga tegishli; liniyalararo nisbat ulanish guruhiga ham bog‘liq. Amalda mis va magnit o‘zak yo‘qotishlari ham mavjud.',
    impact: 'Yuklamaning tok va kuchlanish darajalarini moslashtiradi. Ushbu laboratoriyadagi liniya toki yuqori kuchlanish tomoniga tegishli.',
    formula: '\\frac{U_{1\\mathrm{f}}}{U_{2\\mathrm{f}}}\\approx\\frac{N_1}{N_2}\\approx\\frac{I_{2\\mathrm{f}}}{I_{1\\mathrm{f}}}',
    application: 'Taqsimlash podstansiyalarida sanoat, kommunal va maishiy iste’molchilarni ta’minlaydi.',
  },
  {
    id: 'load', name: 'Iste’molchi va yuklama', category: 'Energiya iste’moli',
    purpose: 'Elektr energiyasini mexanik ish, issiqlik, yorug‘lik va boshqa foydali energiya turlariga aylantiradi.',
    construction: 'Elektr dvigatellari, yoritish qurilmalari, isitish uskunalari hamda boshqa uch fazali va bir fazali qabul qiluvchilar yig‘indisi.',
    principle: 'Yuklama aktiv quvvat P iste’mol qiladi va rejimiga qarab reaktiv quvvat Q ni oladi yoki tarmoqqa beradi.',
    impact: 'P yoki induktiv Q ortishi tokni va I²R yo‘qotishlarini oshiradi. Quvvat koeffitsiyentini yaxshilash bir xil P da tokni kamaytiradi.',
    formula: 'S=\\sqrt{P^2+Q^2},\\qquad \\cos\\varphi=\\frac{P}{S}',
    application: 'Shahar, sanoat korxonasi yoki boshqa iste’molchilar majmuasining hisobiy yuklamasi sifatida qaraladi.',
  },
  {
    id: 'voltmeter', name: 'Voltmetr', category: 'O‘lchov asbobi',
    purpose: 'Ikki nuqta orasidagi kuchlanishni o‘lchaydi. Laboratoriya panelida liniyalararo kuchlanish kV da ko‘rsatiladi.',
    construction: 'Amaliy yuqori kuchlanish tarmog‘ida kuchlanish transformatori va uning ikkilamchi tomoniga ulangan o‘lchov asbobi ishlatiladi.',
    principle: 'O‘lchanayotgan tarmoq nuqtalariga parallel ulanadi; kuchlanish transformatori orqali xavfsiz o‘lchov diapazoniga moslashtiriladi.',
    impact: 'Ideal voltmetrning kirish qarshiligi juda katta bo‘lib, o‘lchanayotgan rejimga ta’siri e’tiborga olinmaydi.',
    formula: 'U=\\sqrt{3}U_{\\mathrm{f}}',
    application: 'Podstansiyalarda shina kuchlanishi va liniya rejimini nazorat qilish uchun qo‘llanadi.',
  },
  {
    id: 'ammeter', name: 'Ampermetr', category: 'O‘lchov asbobi',
    purpose: 'Liniyada oqayotgan tokning effektiv qiymatini o‘lchaydi. Paneldagi asosiy birlik kA hisoblanadi.',
    construction: 'Yuqori kuchlanish tarmoqlarida tok transformatori va ikkilamchi zanjirga ulangan ampermetrdan iborat.',
    principle: 'Birlamchi tok tok transformatori yordamida o‘lchashga qulay qiymatga keltiriladi. Muvozanatlangan rejimda uchala faza toklarining modullari teng.',
    impact: 'O‘lchangan tok o‘tkazgich qizishi va aktiv quvvat yo‘qotishini baholashga xizmat qiladi.',
    formula: 'I=\\frac{\\sqrt{P^2+Q^2}}{\\sqrt{3}U}',
    application: 'Tok yuklanishi, himoya sozlamalari va normal ish rejimini kuzatishda ishlatiladi.',
  },
  {
    id: 'wattmeter', name: 'Vattmetr', category: 'O‘lchov asbobi',
    purpose: 'Uch fazali yuklamaning aktiv quvvatini o‘lchaydi; laboratoriya panelida natija MW da ko‘rsatiladi.',
    construction: 'Tok va kuchlanish o‘lchov zanjirlari, faza siljishini hisobga oluvchi quvvat o‘lchash moduli va ko‘rsatkichdan iborat.',
    principle: 'Oniy kuchlanish va tok ko‘paytmasining davr bo‘yicha o‘rtacha qiymatini aniqlaydi.',
    impact: 'Aktiv quvvat to‘liq quvvatdan farq qiladi: Q nol bo‘lmaganda S katta, P esa uning foydali energiya uzatish bilan bog‘liq qismidir.',
    formula: 'P=\\sqrt{3}UI\\cos\\varphi',
    application: 'Iste’mol quvvati, energiya balansi va liniya yo‘qotishlarini nazorat qilishda qo‘llanadi.',
  },
];
