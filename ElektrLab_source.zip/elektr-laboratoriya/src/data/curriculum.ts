import { calculateLine, type LineInput, type LineResult } from '../lib/physics';

export interface Question { id?: number; prompt: string; options: string[]; correct: number; explanation: string }
export interface TheorySection {
  id: number; title: string; lead: string; paragraphs: string[]; formula: string;
  variables: { symbol: string; meaning: string; unit: string }[];
  example: string; diagram: string; question: Question;
}

export const theorySections: TheorySection[] = [
  {
    id: 1, title: 'Elektr uzatish liniyasi nima?',
    lead: 'Elektr energiyasining manbadan iste’molchigacha bo‘lgan yo‘li.',
    paragraphs: [
      'Elektr uzatish liniyasi elektr stansiyasi, podstansiya va iste’molchini bog‘laydi. Uch fazali o‘zgaruvchan tok tizimida uchta faza simi birgalikda aktiv va reaktiv quvvatni uzatadi. Ushbu laboratoriyada sinusoidal, muvozanatlangan va barqaror rejim o‘rganiladi; chastota 50 Hz deb qabul qilinadi.',
      'P — foydali ishga va issiqlikka aylanuvchi aktiv quvvat; Q — elektr hamda magnit maydonlarda almashinuvchi reaktiv quvvat. To‘la quvvat S bu ikki tarkibning vektor yig‘indisi modulidir. Kuchlanish oshirilsa, bir xil quvvatni uzatish uchun talab qilinadigan tok kamayadi.',
      'Bu yerda U har doim fazalar orasidagi effektiv kuchlanish, P va Q esa uch fazaning jami quvvatidir. Bir fazaning ekvivalent sxemasida U/√3 ishlatiladi. Fazaviy va liniyalararo kuchlanishni aralashtirish √3 yoki 3 marta xatoga olib keladi.',
    ],
    formula: String.raw`S=\sqrt{P^2+Q^2},\qquad I=\frac{S}{\sqrt{3}\,U},\qquad \cos\varphi=\frac{P}{S}`,
    variables: [{ symbol:'S',meaning:'Uch fazali to‘la quvvat',unit:'MVA' },{ symbol:'P, Q',meaning:'Aktiv va reaktiv quvvat',unit:'MW, MVAr' },{ symbol:'U, I',meaning:'Liniyalararo kuchlanish va liniya toki',unit:'kV, kA' }],
    example: 'P = 30 MW va Q = 40 MVAr bo‘lsa, S = 50 MVA. U = 100 kV da I = 50/(√3 × 100) = 0,2887 kA = 288,7 A; cosφ = 0,6.',
    diagram:'overview',
    question:{prompt:'Kalkulyatordagi U = 110 kV nimani anglatadi?',options:['Bitta fazaning yerga nisbatan kuchlanishi','Ikki faza orasidagi effektiv kuchlanish','Kuchlanishning cho‘qqi qiymati'],correct:1,explanation:'Bu platformada U liniyalararo effektiv kuchlanish. Muvozanatlangan tizimda fazaviy kuchlanish U/√3 ga teng.'},
  },
  {
    id:2,title:'Havo liniyasining tuzilishi',lead:'Tayanch, sim va izolyator birgalikda ishlaydi.',
    paragraphs:[
      'Havo liniyasi simlari tayanchlarga izolyatorlar orqali osiladi. Sim tok o‘tkazadi, tayanch mexanik yukni ushlab turadi, izolyator esa tok o‘tkazuvchi qismni yerlangan metall konstruksiyadan elektr jihatdan ajratadi. Po‘lat panjarali tayanchlar yuqori kuchlanish liniyalarida keng uchraydigan konstruksiyalardan biridir.',
      'Sim o‘z og‘irligi tufayli tayanchlar oralig‘ida osilib turadi. Eng kichik yer gabariti odatda oraliqning pastki nuqtasida kuzatiladi. Shamol, muz, sim harorati va mexanik tortilish osilish miqdorini o‘zgartiradi; 3D maketdagi o‘lchamlar tushuntirish uchun berilgan.',
      'Uch faza simlari orasidagi masofa induktivlik va sig‘imga ta’sir qiladi. Yuqori kuchlanishlarda bitta faza bir necha o‘tkazgichdan tuzilishi mumkin. Chaqmoqdan himoyalovchi tros faza simlaridan yuqorida joylashadi va oddiy ish rejimida yuklama tokini tashimaydi.',
    ],
    formula:String.raw`h_{\min}=h_{\text{osish}}-f,\qquad f\approx\frac{w a^2}{8H}`,
    variables:[{symbol:'h_{\\min}',meaning:'Simning yerga eng kichik balandligi',unit:'m'},{symbol:'f, a',meaning:'Osilish va tayanchlar oralig‘i',unit:'m'},{symbol:'w, H',meaning:'Birlik uzunlikdagi og‘irlik va gorizontal tortish kuchi',unit:'N/m, N'}],
    example:'Sim 22 m balandlikda osilgan va osilishi 4 m bo‘lsa, eng kichik balandlik 18 m. Bu hisob xavfsizlik me’yoriga muvofiqlikni tasdiqlamaydi: haqiqiy loyiha sharoiti alohida tekshiriladi.',
    diagram:'overhead',question:{prompt:'Izolyatorning asosiy vazifasi nima?',options:['Sim va yerlangan tayanch orasida elektr izolyatsiya hosil qilish','Aktiv quvvat ishlab chiqarish','Tok chastotasini oshirish'],correct:0,explanation:'Izolyator simni mexanik ushlab turadi va kuchlanishli simni yerlangan tayanchdan ajratadi.'},
  },
  {
    id:3,title:'Kabel liniyasining tuzilishi',lead:'O‘tkazgichdan tashqi qoplamagacha bo‘lgan qatlamlar.',
    paragraphs:[
      'Kabelning markazida mis yoki alyuminiy o‘tkazgich joylashadi. Uning atrofidagi izolyatsiya ish kuchlanishiga bardosh beradi. Yuqori kuchlanish kabelida yarim o‘tkazuvchi ekranlar elektr maydonni tekislaydi, metall ekran esa belgilangan yerga ulash sxemasi bo‘yicha ishlaydi.',
      'Tashqi qoplama namlik va mexanik ta’sirlardan himoya qiladi. Mexanik zirh barcha kabel turlarida bo‘lavermaydi. Kabelning yotqizish chuqurligi, tuproqning issiqlik qarshiligi va qo‘shni kabellar uning ruxsat etilgan tokiga ta’sir ko‘rsatadi.',
      'Kabelning o‘tkazgichi bilan ekrani orasidagi masofa havo liniyasidagiga qaraganda kichik, dielektrikning nisbiy singdiruvchanligi esa kattaroq. Shu sababli kabel sig‘imi va zaryad toki ko‘pincha sezilarli bo‘ladi. Shunt sig‘imini e’tiborsiz qoldirish qisqaroq kabelda ham katta xato berishi mumkin.',
    ],
    formula:String.raw`C'=\frac{2\pi\varepsilon_0\varepsilon_r}{\ln(b/a)},\qquad b_0=\omega C_0`,
    variables:[{symbol:'a, b',meaning:'O‘tkazgich va izolyatsiya tashqi radiuslari',unit:'m'},{symbol:'C\'',meaning:'Koaksial bir fazali modelning birlik uzunlikdagi sig‘imi',unit:'F/m'},{symbol:'C_0, b_0',meaning:'Bir kilometr sig‘imi va sig‘im o‘tkazuvchanligi',unit:'F/km, S/km'}],
    example:'50 Hz da C₀ = 0,2 μF/km bo‘lsa, b₀ = 2π × 50 × 0,2 × 10⁻⁶ = 6,283 × 10⁻⁵ S/km. Formulada C₀ ni μF emas, F da qo‘yish kerak.',
    diagram:'cable',question:{prompt:'Kabelda sig‘im toki nega muhim bo‘lishi mumkin?',options:['Kabelda qarshilik doimo nol bo‘lgani uchun','Kabel faqat o‘zgarmas tokni uzatgani uchun','O‘tkazgich va ekran orasidagi sig‘im katta bo‘lishi mumkinligi uchun'],correct:2,explanation:'O‘tkazgich, izolyatsiya va metall ekran kondensatorga o‘xshash tizim yaratadi. C katta bo‘lsa, I꜀ = ωCU ham katta bo‘ladi.'},
  },
  {
    id:4,title:'Liniyaning asosiy elementlari',lead:'Har bir qurilmaning elektr va mexanik vazifasini ajrating.',
    paragraphs:[
      'Manba energiya beradi, kuchaytiruvchi transformator uzatish kuchlanishini oshiradi, liniya energiyani masofaga yetkazadi. Qabul qiluvchi podstansiyada pasaytiruvchi transformator kuchlanishni iste’molchi tarmog‘iga moslaydi. Transformatorning ikki chulg‘ami o‘zaro magnit bog‘langan.',
      'Uzuvchi apparat ishchi yoki avariya tokini uzishga mo‘ljallanadi; ajratgich esa o‘z vazifasiga mos sharoitda ko‘rinadigan ajratish hosil qiladi. O‘lchov transformatorlari yuqori kuchlanish va tokni o‘lchash tizimlariga mos miqyosga o‘zgartiradi. Laboratoriyada asboblar ideal ko‘rsatkich sifatida beriladi.',
      'Voltmetr kuchlanishni, ampermetr tokni, vattmetr esa aktiv quvvatni ko‘rsatadi. Uch fazali umumiy quvvatni bitta fazaning quvvati bilan aralashtirmang. Transformator nisbatini o‘zgartirish tok va kuchlanishni birgalikda o‘zgartiradi; bu virtual sahnada nominal transformatsiya orqali ko‘rsatiladi.',
    ],
    formula:String.raw`\frac{U_1}{U_2}\approx\frac{N_1}{N_2},\qquad S_1\approx S_2,\qquad P=\sqrt{3}\,UI\cos\varphi`,
    variables:[{symbol:'U_1, U_2',meaning:'Bir xil ulanishli ideal transformator kuchlanishlari',unit:'kV'},{symbol:'N_1, N_2',meaning:'Chulg‘am o‘ramlari soni',unit:'dona'},{symbol:'P',meaning:'Uch fazali aktiv quvvat',unit:'MW'}],
    example:'Ideal 10/110 kV transformator kuchlanishni 11 marta oshiradi. Bir xil to‘la quvvatda yuqori kuchlanish tomonining toki 11 marta kichik bo‘ladi; real transformatorning yo‘qotishlari alohida hisoblanadi.',
    diagram:'overview',question:{prompt:'Bir xil quvvatda uzatish kuchlanishini ikki marta oshirish tokka qanday ta’sir qiladi?',options:['Tok ikki marta kamayadi','Tok ikki marta oshadi','Tok o‘zgarmaydi'],correct:0,explanation:'I = S/(√3U). S o‘zgarmasa, U ikki marta oshganda I ikki marta kamayadi.'},
  },
  {
    id:5,title:'Aktiv qarshilik R',lead:'Simda elektr energiyasining issiqlikka aylanishi.',
    paragraphs:[
      'Aktiv qarshilik o‘tkazgichdagi Joul issiqligi bilan bog‘liq. Bir jinsli sim uchun qarshilik uzunlikka to‘g‘ri, ko‘ndalang kesim yuzasiga teskari proporsional. Amaliy tarmoq hisobida r₀ katalog yoki o‘lchash natijasidan olinadi va ish haroratiga moslashtiriladi.',
      'Metall o‘tkazgich qizigan sari uning aktiv qarshiligi odatda ortadi. O‘zgaruvchan tokdagi sirt effekti va boshqa omillar AC qarshilikni DC qiymatdan farqlashi mumkin. Ushbu kalkulyatorda r₀ kiritilgan ish rejimining o‘zgarmas qiymati deb olinadi.',
      'R = r₀l bir faza simining to‘liq qarshiligidir. Uch fazali yo‘qotish formulasidagi 3 koeffitsiyenti uchta fazani hisobga oladi; shuning uchun R ni yana 3 ga ko‘paytirish kerak emas.',
    ],
    formula:String.raw`R=r_0l,\qquad R=\rho\frac{l}{A},\qquad R_T\approx R_{20}[1+\alpha(T-20)]`,
    variables:[{symbol:'r_0, R',meaning:'Bir kilometrlik va to‘liq faza qarshiligi',unit:'Ω/km, Ω'},{symbol:'\\rho, A',meaning:'Solishtirma qarshilik va kesim yuzi',unit:'Ω·m, m²'},{symbol:'\\alpha',meaning:'Qarshilikning harorat koeffitsiyenti',unit:'1/°C'}],
    example:'l = 60 km va r₀ = 0,15 Ω/km bo‘lsa, R = 0,15 × 60 = 9 Ω. Bir xil material va haroratda kesim ikki baravar oshsa, DC qarshilik taxminan ikki baravar kamayadi.',
    diagram:'r',question:{prompt:'r₀ = 0,2 Ω/km, l = 50 km. Bir fazaning R qiymati qancha?',options:['0,004 Ω','10 Ω','30 Ω'],correct:1,explanation:'R = r₀l = 0,2 × 50 = 10 Ω. Bu bir fazaning qiymati; uch faza uchun uni bu bosqichda 3 ga ko‘paytirmaymiz.'},
  },
  {
    id:6,title:'Induktiv qarshilik X',lead:'Tok yaratgan magnit maydonning ta’siri.',
    paragraphs:[
      'Faza simidagi o‘zgaruvchan tok uning atrofida o‘zgaruvchan magnit maydon hosil qiladi. Bu maydon tok o‘zgarishiga qarshilik qiladigan induksion elektr yurituvchi kuch bilan bog‘liq. Sinusoidal barqaror rejimda bu ta’sir jX impedansi bilan ifodalanadi.',
      'Ideal induktivlik aktiv energiyani doimiy yutmaydi: energiya magnit maydonda to‘planib, keyin manbaga qaytadi. Shunga qaramay, induktiv reaktiv quvvat tokni va aktiv qarshilikdagi yo‘qotishni oshirishi mumkin. X ni R bilan bir xil fizik kattalik deb tushunmaslik kerak.',
      'Induktivlik simlar joylashuvi, radiusi va faza o‘tkazgichlari tuzilishiga bog‘liq. f oshsa, L o‘zgarmagan holda X ham oshadi. Ushbu platformada x₀ 50 Hz uchun berilgan qiymat sifatida ishlatiladi.',
    ],
    formula:String.raw`X=x_0l,\qquad X=\omega L=2\pi fL,\qquad Z=R+jX`,
    variables:[{symbol:'x_0, X',meaning:'Bir kilometrlik va to‘liq induktiv qarshilik',unit:'Ω/km, Ω'},{symbol:'f, L',meaning:'Chastota va faza induktivligi',unit:'Hz, H'},{symbol:'j',meaning:'Mavhum birlik: j² = −1',unit:'o‘lchovsiz'}],
    example:'x₀ = 0,4 Ω/km va l = 75 km bo‘lsa, X = 30 Ω. f = 50 Hz da bu X uchun L = X/(2πf) ≈ 0,0955 H.',
    diagram:'x',question:{prompt:'Ideal induktivlikning fizik ma’nosi qaysi?',options:['Doimo aktiv quvvatni issiqlikka aylantiradi','Faqat elektr maydonda energiya saqlaydi','Magnit maydonda energiya to‘playdi va qaytaradi'],correct:2,explanation:'Ideal L energiyani magnit maydonda saqlaydi. Aktiv issiqlik yo‘qotishi simning R parametri bilan hisoblanadi.'},
  },
  {
    id:7,title:'Aktiv o‘tkazuvchanlik G',lead:'Izolyatsiya orqali aktiv yo‘qotishlarni modellashtirish.',
    paragraphs:[
      'Liniyaning shunt aktiv o‘tkazuvchanligi izolyatsiya sizib o‘tish toki va ayrim dielektrik yo‘qotishlarni soddalashtirib ifodalaydi. G sim bo‘ylab ketma-ket qo‘yiladigan element emas, faza bilan neytral yoki yer orasidagi parallel tarmoqning haqiqiy qismidir.',
      'Yaxshi izolyatsiyali ko‘plab havo liniyasi hisoblarida g₀ juda kichik deb olinib, G ≈ 0 qabul qilinadi. Bu barcha sharoitlarda yo‘qotish yo‘q degani emas. Tojlanish va ifloslangan izolyator yo‘qotishlari kuchlanish hamda muhitga bog‘liq bo‘lishi mumkin, doimiy G ularni faqat yaqinlashtiradi.',
      'R va G o‘zaro teskari bo‘lgan bitta element emas. 1/R sim bo‘ylab ketma-ket qarshilikning o‘tkazuvchanligini bildiradi; liniya modelidagi G esa boshqa yo‘l — shunt izolyatsiya yo‘lining parametridir.',
    ],
    formula:String.raw`G=g_0l,\qquad Y=G+jB,\qquad P_{\mathrm{sh}}\approx U^2G`,
    variables:[{symbol:'g_0, G',meaning:'Bir kilometrlik va to‘liq shunt aktiv o‘tkazuvchanlik',unit:'S/km, S'},{symbol:'Y',meaning:'Kompleks shunt o‘tkazuvchanlik',unit:'S'},{symbol:'P_{\\mathrm{sh}}',meaning:'Bir xil faza kuchlanishida uch fazali shunt aktiv yo‘qotish',unit:'MW'}],
    example:'g₀ = 2 × 10⁻⁹ S/km va l = 100 km bo‘lsa, G = 2 × 10⁻⁷ S. U = 110 kV da Pₛₕ ≈ 110² × G = 0,00242 MW = 2,42 kW.',
    diagram:'g',question:{prompt:'Liniya sxemasidagi G qayerda joylashadi?',options:['Shunt tarmoqda, faza va neytral/yer orasida','R bilan bir xil element sifatida','Transformator chulg‘ami o‘rnida'],correct:0,explanation:'G shunt yo‘ldagi aktiv o‘tkazuvchanlik. U liniya bo‘ylab R ga teskari qiymat sifatida hisoblanmaydi.'},
  },
  {
    id:8,title:'Sig‘im o‘tkazuvchanligi B',lead:'Elektr maydon, zaryad toki va reaktiv quvvat.',
    paragraphs:[
      'Kuchlanish ostidagi faza simlari o‘zaro va yerga nisbatan elektr maydon hosil qiladi. Bu bog‘lanish sig‘im bilan ifodalanadi. Muvozanatlangan bir fazali modelda B = ωC shunt susceptans bo‘lib, Y = G + jB tarkibiga musbat mavhum qism sifatida kiradi.',
      'Sig‘im toki kuchlanishdan 90° oldinda yuradi. Shuning uchun uzatish liniyasining sig‘imi tarmoqqa sig‘imli reaktiv quvvat beradi. Bu darsda Q꜀ = U²B uning musbat kattaligi; yuklama quvvati ishorasida esa sig‘imli iste’mol Q < 0 bilan belgilanadi.',
      'Yuklama yengil bo‘lganda uzun liniya oxiridagi kuchlanish sig‘im sabab oshishi mumkin. Bu Ferranti hodisasi deb ataladi. R–X qisqa liniya modeli B ni tashlab yuborgani uchun ushbu ta’sirni ifodalay olmaydi.',
    ],
    formula:String.raw`B=b_0l=\omega C,\qquad I_C=\frac{U}{\sqrt{3}}B,\qquad Q_C=U^2B`,
    variables:[{symbol:'B, b_0',meaning:'To‘liq va bir kilometrlik sig‘im o‘tkazuvchanligi',unit:'S, S/km'},{symbol:'I_C',meaning:'Bir fazaning jami ekvivalent zaryad toki',unit:'kA'},{symbol:'Q_C',meaning:'Uch fazali sig‘imli reaktiv quvvat kattaligi',unit:'MVAr'}],
    example:'b₀ = 3 × 10⁻⁶ S/km va l = 100 km: B = 0,0003 S. U = 110 kV da Q꜀ ≈ 3,63 MVAr. Nominal π sxemada har bir uchdagi shunt susceptans B/2 = 0,00015 S.',
    diagram:'b',question:{prompt:'Nominal π sxemada umumiy B qayerlarga taqsimlanadi?',options:['Har ikki uchga B dan, jami 2B','Har ikki uchga B/2 dan','Faqat ketma-ket X elementiga'],correct:1,explanation:'Nominal π sxemaning ikki shunt tarmog‘ida G/2 va B/2 mavjud. Ularning yig‘indisi umumiy G va B ni beradi.'},
  },
  {
    id:9,title:'Almashtiruv sxemalari',lead:'Haqiqiy liniyaning parametrlarini elektr sxemaga o‘tkazing.',
    paragraphs:[
      'Almashtiruv sxemasi faza simining ketma-ket Z = R + jX impedansi va shunt Y = G + jB o‘tkazuvchanligini ifodalaydi. Bu geometriyaning to‘liq tasviri emas: sxema tanlangan rejimdagi tok, kuchlanish va quvvat bog‘lanishlarini saqlash uchun tuziladi.',
      'Nominal π modelda ketma-ket Z o‘rtada, ikkita Y/2 shunt tarmoq esa liniyaning ikki uchida turadi. Nominal T modelda Z/2 chapda va Z/2 o‘ngda, to‘liq Y esa o‘rtada bo‘ladi. T modeldagi har bir ketma-ket bo‘lak R/2 + jX/2 ni o‘z ichiga oladi.',
      'ABCD koeffitsiyentlari qabul tomonidagi fazaviy kompleks kuchlanish va tokdan jo‘natish tomonini topadi. A va D o‘lchovsiz, B_ABCD Ω da, C_ABCD S da o‘lchanadi. B_ABCD koeffitsiyentini liniyaning sig‘im o‘tkazuvchanligi B bilan adashtirmang.',
    ],
    formula:String.raw`\begin{bmatrix}V_s\\I_s\end{bmatrix}=\begin{bmatrix}A&B_{ABCD}\\C_{ABCD}&D\end{bmatrix}\begin{bmatrix}V_r\\I_r\end{bmatrix},\quad A=D=1+\frac{ZY}{2}`,
    variables:[{symbol:'Z, Y',meaning:'To‘liq ketma-ket impedans va shunt o‘tkazuvchanlik',unit:'Ω, S'},{symbol:'V_s, V_r',meaning:'Jo‘natish va qabul tomonidagi fazaviy kuchlanish fazorlari',unit:'kV'},{symbol:'I_s, I_r',meaning:'Mos tomonlardagi liniya toki fazorlari',unit:'kA'}],
    example:'Z = 12 + j40 Ω va Y = j0,0003 S bo‘lsa: π modelning har bir shunti j0,00015 S; T modelning har bir ketma-ket yelkasi 6 + j20 Ω.',
    diagram:'pi',question:{prompt:'Nominal T sxemada to‘g‘ri taqsimot qaysi?',options:['Chapda Z, o‘rtada Y, o‘ngda Z','Har bir uchda Y/2 va o‘rtada Z','Chapda Z/2, o‘rtada Y, o‘ngda Z/2'],correct:2,explanation:'T modelda to‘liq Z ikkiga bo‘linadi, to‘liq Y o‘rtaga qo‘yiladi. π modelda esa Y ikkiga bo‘linadi.'},
  },
  {
    id:10,title:'Qisqa, o‘rta va uzun liniya',lead:'Modelni aniqlik talabiga qarab tanlang.',
    paragraphs:[
      'Darsliklarda 50–60 Hz havo liniyalari uchun ko‘pincha 80 km dan qisqa liniya, 80–250 km o‘rta liniya, 250 km dan uzun liniya toifalari qo‘llanadi. Bu o‘quv yo‘riq bo‘lib, qat’iy umumiy chegara emas. Kabel sig‘imi, kuchlanish, chastota, yuklama va talab etilgan aniqlik model tanlovini o‘zgartiradi.',
      'Qisqa model shunt ta’sirni tashlab, A = D = 1, B_ABCD = Z, C_ABCD = 0 deb oladi. Nominal π yoki T model shunt parametrlarini yig‘ilgan elementlar bilan ifodalaydi. Uzun liniyada esa tok va kuchlanish koordinata bo‘ylab o‘zgaradi, shuning uchun parametrlar taqsimlangan deb qaraladi.',
      'Uzun liniya modeli γ = √(zy) tarqalish koeffitsiyenti va Z꜀ = √(z/y) to‘lqin qarshiligidan foydalanadi. γl o‘lchovsiz bo‘lishi kerak: z va y bir kilometr uchun berilsa, l ham kilometrda olinadi. π va T natijalarini uzun model bilan solishtirish yaqinlashuv xatosini ko‘rsatadi.',
    ],
    formula:String.raw`\gamma=\sqrt{zy},\quad Z_c=\sqrt{z/y},\quad A=D=\cosh(\gamma l),\quad B_{ABCD}=Z_c\sinh(\gamma l),\quad C_{ABCD}=\frac{\sinh(\gamma l)}{Z_c}`,
    variables:[{symbol:'z, y',meaning:'Birlik uzunlikdagi kompleks parametrlar',unit:'Ω/km, S/km'},{symbol:'\\gamma',meaning:'Tarqalish koeffitsiyenti',unit:'1/km'},{symbol:'Z_C',meaning:'To‘lqin qarshiligi',unit:'Ω'}],
    example:'300 km havo liniyasida uzun model yaxshi boshlang‘ich tanlovdir. Ammo 30 km katta sig‘imli kabel uchun ham shunt tarmoqli model zarur bo‘lishi mumkin; faqat uzunlikka qarash yetarli emas.',
    diagram:'models',question:{prompt:'80 va 250 km chegaralarini qanday tushunish kerak?',options:['Havo liniyalari uchun odatiy o‘quv mezoni; haqiqiy tanlov elektr parametrlariga ham bog‘liq','Barcha kabel va havo liniyalari uchun mutlaq qonun','Faqat o‘zgarmas tok tizimlari chegarasi'],correct:0,explanation:'Chegaralar taxminiy tasnif. Elektr uzunlik, sig‘im, chastota va aniqlik talabi hal qiluvchi omillardir.'},
  },
  {
    id:11,title:'Kuchlanish tushuvi va yo‘qotishlar',lead:'Tok, yuklama va liniya uzunligining natijaga ta’siri.',
    paragraphs:[
      'Kuchlanish tushuvining soddalashtirilgan ifodasi ketma-ket impedansdagi bo‘ylama kuchlanish tarkibiga asoslanadi. U = Uᵣ qabul tomonidagi liniyalararo kuchlanish, P va Q esa qabul tomonidagi jami yuklama quvvatlaridir. Shunt toki, ko‘ndalang fazor tarkibi va parametrlarning rejimga bog‘liqligi bu formulada hisobga olinmaydi.',
      'ΔP = 3I²R uchta faza simidagi aktiv issiqlik yo‘qotishidir. Bu transformator, shunt G va boshqa jihozlar yo‘qotishlarini o‘z ichiga olmaydi. π/T/uzun modelda jo‘natish va qabul quvvatlarining farqi shunt hamda o‘zgaruvchi liniya tokini hisobga olgan model yo‘qotishini beradi.',
      'P va cosφ o‘zgarmagan holda U ikki baravar oshsa, I ikki baravar, I²R yo‘qotish to‘rt baravar kamayadi. Q ni kamaytirish ham tokni kamaytiradi. Biroq uzun liniyada sig‘imli zaryad toki mavjudligi sabab barcha ta’sirlar oddiy kvadratik qoidaga to‘liq mos kelmasligi mumkin.',
    ],
    formula:String.raw`\Delta U\approx\frac{PR+QX}{U},\qquad \Delta U\%=100\frac{\Delta U}{U},\qquad \Delta P=3I^2R`,
    variables:[{symbol:'\\Delta U',meaning:'Soddalashtirilgan liniyalararo kuchlanish tushuvi',unit:'kV'},{symbol:'\\Delta P',meaning:'Uch faza simining aktiv yo‘qotishi',unit:'MW'},{symbol:'I, R',meaning:'Liniya toki va bir faza qarshiligi',unit:'kA, Ω'}],
    example:'P = 30 MW, Q = 40 MVAr, U = 100 kV, R = 10 Ω va X = 20 Ω bo‘lsa, I = 0,2887 kA, ΔU ≈ 11 kV, ΔP = 2,5 MW. ΔU/U = 11% bo‘lgani uchun kompleks model bilan tekshirish muhim.',
    diagram:'loss',question:{prompt:'Bir xil R da tok 2 marta ortsa, 3I²R yo‘qotishi qanday o‘zgaradi?',options:['2 marta ortadi','4 marta ortadi','O‘zgarmaydi'],correct:1,explanation:'Yo‘qotish tokning kvadratiga proporsional: (2I)² = 4I².'},
  },
  {
    id:12,title:'Namunaviy hisoblash algoritmi',lead:'Berilganlardan tekshiriladigan javobgacha.',
    paragraphs:[
      'Avval birliklarni tekshiring: l — km; r₀ va x₀ — Ω/km; g₀ va b₀ — S/km; U — kV; P — MW; Q — MVAr. μS qiymati berilgan bo‘lsa, S ga o‘tkazish uchun 10⁻⁶ ga ko‘paytiring. Keyin umumiy R, X, G va B ni hisoblang.',
      'Quvvatni kiritishning ikkita izchil usuli bor: P va Q ma’lum bo‘lsa, cosφ hisoblanadi; P va cosφ ma’lum bo‘lsa, Q = ±P tan(arccos(cosφ)) topiladi. Plus induktiv, minus sig‘imli yuklamani bildiradi. Bir vaqtning o‘zida mustaqil Q va cosφ berish ortiqcha, ba’zan zid ma’lumot yaratadi.',
      'So‘ng I, ΔU va ΔP topiladi, o‘lchov birliklari yoziladi va fizik ma’no baholanadi. Juda katta tok yoki tushuv chiqsa, birlik, formula va kirish ma’lumotlarini qayta tekshiring. Natijani oxirida yaxlitlash oraliq hisob xatosini kamaytiradi.',
    ],
    formula:String.raw`R=r_0l,\ X=x_0l,\ G=g_0l,\ B=b_0l,\qquad Q=P\tan(\arccos(\cos\varphi))`,
    variables:[{symbol:'\\cos\\varphi',meaning:'Quvvat koeffitsiyenti',unit:'o‘lchovsiz'},{symbol:'P, Q',meaning:'Uch fazali aktiv va reaktiv yuklama',unit:'MW, MVAr'},{symbol:'l',meaning:'Bir yo‘nalish bo‘yicha liniya uzunligi',unit:'km'}],
    example:'l = 50 km, r₀ = 0,12 Ω/km, x₀ = 0,4 Ω/km, U = 110 kV, P = 30 MW, Q = 15 MVAr: R = 6 Ω; X = 20 Ω; S = 33,541 MVA; I = 0,17605 kA; ΔU ≈ 4,3636 kV; ΔP ≈ 0,55785 MW.',
    diagram:'pi',question:{prompt:'P va Q ma’lum bo‘lsa, cosφ qanday aniqlanadi?',options:['P/Q','Q/√(P² + Q²)','P/√(P² + Q²)'],correct:2,explanation:'cosφ = P/S va S = √(P² + Q²). Q ishorasi yuklamaning induktiv yoki sig‘imli ekanini ko‘rsatadi.'},
  },
];

export interface Variant { id: number; input: LineInput }
const round = (value: number, places = 6) => Number(value.toFixed(places));

/** All variants use credible educational operating points; they are synthetic
 * exercises, not measurements from a real utility. */
export const variants: Variant[] = Array.from({ length: 30 }, (_, i) => {
  const group = Math.floor(i / 10), k = i % 10;
  const U = [35, 110, 220][group];
  const l = [10 + 2*k, 35 + 5*k, 100 + 12*k][group];
  const r0 = round([0.2 + 0.008*(k%5), 0.11 + 0.006*(k%5), 0.06 + 0.005*(k%5)][group]);
  const x0 = round([0.33 + 0.01*(k%4), 0.35 + 0.012*(k%4), 0.3 + 0.01*(k%4)][group]);
  const P = round([2.5 + 0.3*k, 15 + 1.8*k, 60 + 4*k][group]);
  const cosPhi = round([0.86 + 0.01*(k%8), 0.88 + 0.01*(k%7), 0.9 + 0.01*(k%6)][group]);
  const input: LineInput = { l, r0, x0, g0: 0, b0: [2.4e-6, 2.8e-6, 3.1e-6][group], U, P,
    Q: P*Math.tan(Math.acos(cosPhi)), cosPhi, powerMode:'pf', reactiveKind:'inductive' };
  return { id:i+1, input };
});

export const variantAnswers: Record<number, LineResult> = Object.fromEntries(variants.map(v => [v.id, calculateLine(v.input)]));

export type ProblemTarget = 'R' | 'X' | 'G' | 'B' | 'I' | 'deltaU' | 'deltaP' | 'powerFactor';
export interface Problem { id:number; title:string; input:LineInput; target:ProblemTarget; unit:string; formula:string; hint:string }
const targets: { target:ProblemTarget; title:string; unit:string; formula:string; hint:string }[] = [
  {target:'R',title:'Fazaning aktiv qarshiligi',unit:'Ω',formula:String.raw`R=r_0l`,hint:'Ω/km ni km ga ko‘paytiring. Uch faza borligi uchun R ni 3 ga ko‘paytirmang.'},
  {target:'X',title:'Fazaning induktiv qarshiligi',unit:'Ω',formula:String.raw`X=x_0l`,hint:'x₀ katalogdagi bir kilometrlik qiymat. To‘liq uzunlik l bilan ko‘paytiring.'},
  {target:'G',title:'Shunt aktiv o‘tkazuvchanlik',unit:'S',formula:String.raw`G=g_0l`,hint:'g₀ ni S/km da oling. Masalan, 1 nS = 10⁻⁹ S; javobni ilmiy yozuvda ham kiritishingiz mumkin.'},
  {target:'B',title:'Sig‘im o‘tkazuvchanligi',unit:'S',formula:String.raw`B=b_0l`,hint:'Bu jami B. Faqat π sxemaning bitta shunt yelkasi so‘ralganda B/2 olinadi.'},
  {target:'I',title:'Uch fazali liniyaning toki',unit:'kA',formula:String.raw`I=\frac{\sqrt{P^2+Q^2}}{\sqrt{3}U}`,hint:'Avval Q = P tan(arccos(cosφ)) ni toping yoki I = P/(√3U cosφ) dan foydalaning. Natija kA.'},
  {target:'deltaU',title:'Kuchlanish tushuvi',unit:'kV',formula:String.raw`\Delta U\approx\frac{PR+QX}{U}`,hint:'Avval R = r₀l va X = x₀l ni toping. P va Q uch fazaning jami quvvati; yana 3 ga ko‘paytirish kerak emas.'},
  {target:'deltaP',title:'Simlarda aktiv quvvat yo‘qotishi',unit:'MW',formula:String.raw`\Delta P=3I^2R`,hint:'Tokni kA da ishlating. A da ishlatsangiz natija W bo‘ladi, uni MW ga o‘tkazish zarur.'},
  {target:'powerFactor',title:'Yuklamaning quvvat koeffitsiyenti',unit:'',formula:String.raw`\cos\varphi=\frac{P}{\sqrt{P^2+Q^2}}`,hint:'S = √(P² + Q²) ni topib P ni S ga bo‘ling. Natija 0 va 1 orasida bo‘lishi kerak.'},
];
export const problems: Problem[] = Array.from({length:24},(_,i) => {
  const spec = targets[i%targets.length];
  const input = { ...variants[(i*7+3)%variants.length].input };
  if (spec.target === 'G') input.g0 = (2+Math.floor(i/8))*1e-9;
  if (spec.target === 'powerFactor') { input.powerMode='pq'; input.Q=round(input.P*(0.35+0.07*Math.floor(i/8)),3); }
  return { id:i+1, ...spec, input };
});

export const examQuestions: (Question & {id:number})[] = [
  {id:1,prompt:'Bir fazaning liniya aktiv qarshiligi qanday topiladi?',options:['R = r₀/l','R = r₀l','R = 3r₀l','R = U²/P'],correct:1,explanation:'r₀ birlik uzunlik uchun berilgan. l ga ko‘paytirish bir fazaning to‘liq qarshiligini beradi.'},
  {id:2,prompt:'P va Q MW/MVAr, U kV bo‘lsa, I = S/(√3U) natijasi qaysi birlikda?',options:['A','mA','kA','Ω'],correct:2,explanation:'MVA/kV = kA. Amper olish uchun natijani 1000 ga ko‘paytiring.'},
  {id:3,prompt:'Nominal π sxemadagi har bir shunt tarmoq qaysi qiymatga ega?',options:['Y','2Y','Z/2','Y/2'],correct:3,explanation:'Nominal π modelda jami Y ikkala uchga teng taqsimlanadi; har birida G/2 + jB/2.'},
  {id:4,prompt:'Nominal T modelning ikki ketma-ket yelkasidagi parametrlar qanday?',options:['Har birida Z/2','Har birida Y/2','Har birida Z','Faqat R va G'],correct:0,explanation:'Har bir ketma-ket yelkada R/2 + jX/2, o‘rtadagi shuntda to‘liq G + jB bo‘ladi.'},
  {id:5,prompt:'Bir xil P va cosφ da U ikki marta oshsa, soddalashtirilgan I²R yo‘qotish qanday o‘zgaradi?',options:['2 marta oshadi','4 marta kamayadi','2 marta kamayadi','O‘zgarmaydi'],correct:1,explanation:'I ikki marta kamayadi. Qarshilik o‘zgarmasa, I²R to‘rt marta kamayadi.'},
  {id:6,prompt:'Q < 0 bu laboratoriyada qanday yuklamani bildiradi?',options:['Induktiv','Aktiv quvvat ishlab chiqaruvchi','Sig‘imli','Qisqa tutashgan'],correct:2,explanation:'Q ning musbat ishorasi induktiv iste’molni, manfiy ishorasi sig‘imli reaktiv quvvatni bildiradi.'},
  {id:7,prompt:'G ning o‘lchov birligi nima?',options:['Ω','H','F','S'],correct:3,explanation:'O‘tkazuvchanlik siemens (S) da o‘lchanadi. g₀ esa S/km da beriladi.'},
  {id:8,prompt:'3I²R formulasi nimalarni hisoblaydi?',options:['Uch faza simidagi aktiv issiqlik yo‘qotishini','Butun tizimdagi barcha yo‘qotishlarni','Faqat sig‘imli reaktiv quvvatni','Transformatorning magnitlash tokini'],correct:0,explanation:'Bu ketma-ket qarshilikdagi Joul yo‘qotishi. Shunt va transformator yo‘qotishlari qo‘shimcha model talab qiladi.'},
  {id:9,prompt:'Uzun liniyaning asosiy model farqi nima?',options:['Tok doimo nol','R, X, G, B koordinata bo‘ylab taqsimlangan','Faqat aktiv qarshilik bor','Har bir fazaga alohida chastota beriladi'],correct:1,explanation:'Uzun liniyada tok va kuchlanish yo‘l bo‘ylab o‘zgaradi, parametrlar taqsimlangan hisoblanadi.'},
  {id:10,prompt:'Voltmetr, ampermetr va vattmetr mos ravishda nimani o‘lchaydi?',options:['Tok, quvvat, kuchlanish','Qarshilik, tok, chastota','Kuchlanish, tok, aktiv quvvat','Reaktiv quvvat, sig‘im, induktivlik'],correct:2,explanation:'Voltmetr U ni, ampermetr I ni, vattmetr P ni o‘lchaydi. Ushbu laboratoriyada kuchlanish liniyalararo ko‘rsatiladi.'},
];

export const sources = [
  {title:'NPTEL — Transmission line models: tasnif va ABCD',url:'https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_1.html'},
  {title:'NPTEL — Nominal π representation',url:'https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_4.html'},
  {title:'NPTEL — Nominal T representation',url:'https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_5.html'},
  {title:'NPTEL — Long line model',url:'https://archive.nptel.ac.in/content/storage2/courses/108104051/chapter_2/2_6.html'},
];
