import { examQuestions, problems, theorySections, variants } from '../data/curriculum';
import { calculateLine, compareAnswer } from './physics';
import { freshState, normalizeName, scoreState, type CheckedAnswer, type ChoiceAnswer, type StudentState } from './store';

export interface StudentReport {
  schema: 1;
  app: 'ElektrLab';
  exportedAt: string;
  student: StudentState;
  scores: ReturnType<typeof scoreState>;
}

const routes = ['/', '/nazariya', '/laboratoriya', '/sxemalar', '/kalkulyator', '/masalalar', '/variant', '/natijalar'];
const laboratoryTaskIds = ['inspect', 'energize', 'load', 'height'];
const calculationKeys = ['R', 'X', 'I', 'deltaU', 'deltaP'] as const;
const isObject = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

function fail(message = 'Hisobot tuzilishi noto‘g‘ri yoki bu fayl ElektrLab uchun yaratilmagan.'): never {
  throw new Error(message);
}

function exactStringArray(value: unknown, allowed: readonly string[], label: string): string[] {
  if (!Array.isArray(value) || value.length > allowed.length || value.some(item => typeof item !== 'string' || !allowed.includes(item))) {
    fail(`${label} maydoni noto‘g‘ri.`);
  }
  return Array.from(new Set(value as string[]));
}

function choiceRecord(value: unknown, questions: { id: number; options: string[]; correct: number }[]): Record<string, ChoiceAnswer> {
  if (!isObject(value) || Object.keys(value).length > questions.length) fail('Test javoblari tuzilishi noto‘g‘ri.');
  const result: Record<string, ChoiceAnswer> = {};
  for (const [id, answer] of Object.entries(value)) {
    const question = questions.find(item => String(item.id) === id);
    if (!question || !isObject(answer) || typeof answer.selected !== 'number' || !Number.isInteger(answer.selected) || answer.selected < 0 || answer.selected >= question.options.length) {
      fail('Hisobotda mavjud bo‘lmagan savol yoki noto‘g‘ri javob raqami bor.');
    }
    result[id] = { selected: answer.selected as number, correct: answer.selected === question.correct };
  }
  return result;
}

function numericalAnswer(value: unknown, expected: number): CheckedAnswer {
  if (!isObject(value) || typeof value.entered !== 'string' || value.entered.length > 48 || typeof value.attempts !== 'number' || !Number.isInteger(value.attempts) || value.attempts < 1 || value.attempts > 10000) {
    fail('Hisoblash javobi yoki urinishlar soni noto‘g‘ri.');
  }
  return { entered: value.entered as string, attempts: value.attempts as number, correct: compareAnswer(value.entered as string, expected) };
}

/** Parses an explicit, bounded schema; imported booleans and scores are ignored. */
export function parseReport(text: string): StudentState {
  if (text.length > 256_000) fail('Hisobot fayli juda katta. 256 KB dan kichik ElektrLab JSON faylini tanlang.');
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { fail('Faylni o‘qib bo‘lmadi. To‘g‘ri JSON hisobotini tanlang.'); }
  if (!isObject(parsed) || parsed.schema !== 1 || parsed.app !== 'ElektrLab' || !isObject(parsed.student)) fail();
  const student = parsed.student as Record<string, unknown>;
  if (student.schema !== 1 || typeof student.name !== 'string' || student.name.length > 100 || /[\u0000-\u001f\u007f]/.test(student.name)) fail('Talaba ismi noto‘g‘ri.');
  const variantId = student.variantId;
  if (variantId !== null && (typeof variantId !== 'number' || !Number.isInteger(variantId) || !variants.some(variant => variant.id === variantId))) fail('Variant raqami 1–30 oralig‘ida bo‘lishi kerak.');
  const next = freshState();
  next.name = normalizeName(student.name);
  next.variantId = variantId as number | null;
  next.visited = exactStringArray(student.visited, routes, 'O‘tilgan sahifalar');
  next.labTasks = exactStringArray(student.labTasks, laboratoryTaskIds, 'Laboratoriya topshiriqlari');
  next.theory = choiceRecord(student.theory, theorySections.map(section => ({ ...section.question, id: section.id })));
  next.exam = choiceRecord(student.exam, examQuestions);
  if (!isObject(student.calculations) || Object.keys(student.calculations).length > calculationKeys.length) fail('Hisoblashlar maydoni noto‘g‘ri.');
  const variant = variants.find(item => item.id === next.variantId);
  if (Object.keys(student.calculations).length && !variant) fail('Hisoblash javoblariga variant biriktirilmagan.');
  const answers = variant ? calculateLine(variant.input) : null;
  for (const [key, answer] of Object.entries(student.calculations)) {
    if (!calculationKeys.includes(key as typeof calculationKeys[number]) || !answers) fail('Noma’lum hisoblash topshirig‘i.');
    next.calculations[key] = numericalAnswer(answer, answers[key as typeof calculationKeys[number]]);
  }
  if (!isObject(student.practice) || Object.keys(student.practice).length > problems.length) fail('Mustaqil masalalar maydoni noto‘g‘ri.');
  for (const [key, answer] of Object.entries(student.practice)) {
    const problem = problems.find(item => String(item.id) === key);
    if (!problem) fail('Noma’lum mustaqil masala.');
    next.practice[key] = numericalAnswer(answer, calculateLine(problem!.input)[problem!.target]);
  }
  if (student.variantScheme !== null && (typeof student.variantScheme !== 'string' || !['r', 'short', 'pi', 't', 'long'].includes(student.variantScheme))) fail('Sxema turi noto‘g‘ri.');
  next.variantScheme = student.variantScheme as string | null;
  if (student.variantAnalysis !== null && (typeof student.variantAnalysis !== 'number' || !Number.isInteger(student.variantAnalysis) || student.variantAnalysis < 0 || student.variantAnalysis > 9)) fail('Tahlil javobi noto‘g‘ri.');
  next.variantAnalysis = student.variantAnalysis as number | null;
  return next;
}

export function makeReport(student: StudentState): StudentReport {
  return { schema: 1, app: 'ElektrLab', exportedAt: new Date().toISOString(), student, scores: scoreState(student) };
}

export function downloadText(filename: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function exportJson(student: StudentState) {
  downloadText(`ElektrLab_variant-${student.variantId ?? 'tanlanmagan'}.json`, JSON.stringify(makeReport(student), null, 2), 'application/json;charset=utf-8');
}

function csvCell(value: string | number) {
  let result = String(value);
  if (typeof value === 'string' && /^[=+@\-\t\r]/.test(result)) result = `'${result}`;
  return `"${result.replace(/"/g, '""')}"`;
}

export function exportCsv(student: StudentState) {
  const scores = scoreState(student);
  const row: (string | number)[][] = [
    ['Ko‘rsatkich', 'Qiymat'],
    ['Talaba', student.name || 'Ism kiritilmagan'],
    ['Variant', student.variantId ?? 'Olinmagan'],
    ['Nazariya (20 ball)', Number(scores.theory.toFixed(2))],
    ['Virtual laboratoriya (20 ball)', scores.lab],
    ['Hisoblash topshiriqlari (40 ball)', scores.calculations],
    ['Yakuniy test (20 ball)', scores.exam],
    ['Jami (100 ball)', scores.total],
    ['Hisobot yaratilgan vaqt (UTC)', new Date().toISOString()],
    ['', ''],
    ['Hisoblash', 'Kiritilgan javob', 'Holati', 'Urinishlar'],
    ...calculationKeys.map(key => [key, student.calculations[key]?.entered ?? '', student.calculations[key] ? student.calculations[key].correct ? 'To‘g‘ri' : 'Noto‘g‘ri' : 'Javobsiz', student.calculations[key]?.attempts ?? 0]),
    ['', ''],
    ['Yakuniy savol', 'Tanlangan javob', 'Holati'],
    ...examQuestions.map(question => [question.id, student.exam[question.id] ? question.options[student.exam[question.id].selected] : '', student.exam[question.id] ? student.exam[question.id].correct ? 'To‘g‘ri' : 'Noto‘g‘ri' : 'Javobsiz']),
  ];
  downloadText(`ElektrLab_natija_variant-${student.variantId ?? 'tanlanmagan'}.csv`, '\uFEFF' + row.map(cells => cells.map(csvCell).join(';')).join('\r\n'), 'text/csv;charset=utf-8');
}
