import { describe, expect, it } from 'vitest';
import { calculateLine } from './physics';
import { examQuestions, problems, theorySections, variants } from '../data/curriculum';
import { freshState, scoreState, type StudentState } from './store';
import { makeReport, parseReport } from './report';

const numericKeys = ['R', 'X', 'I', 'deltaU', 'deltaP'] as const;
const serialize = (student: StudentState) => JSON.stringify(makeReport(student));

function populatedStudent(): StudentState {
  const state = freshState();
  state.name = 'O‘tkir G‘aniyev';
  state.variantId = 13;
  state.visited = ['/', '/nazariya', '/laboratoriya', '/variant', '/natijalar'];
  state.labTasks = ['inspect', 'energize'];
  state.variantScheme = 'pi';
  state.variantAnalysis = 1;
  state.theory['1'] = { selected: theorySections[0].question.correct, correct: true };
  state.exam['1'] = { selected: (examQuestions[0].correct + 1) % examQuestions[0].options.length, correct: false };
  const expected = calculateLine(variants[12].input);
  state.calculations.R = { entered: expected.R.toPrecision(8).replace('.', ','), correct: true, attempts: 3 };
  state.calculations.X = { entered: '0', correct: false, attempts: 1 };
  const problem = problems[0];
  state.practice[String(problem.id)] = { entered: String(calculateLine(problem.input)[problem.target]), correct: true, attempts: 2 };
  return state;
}

describe('Portable student JSON reports', () => {
  it('round-trips identity, Uzbek text, progress, raw answers and attempt counts', () => {
    const state = populatedStudent();
    const exported = makeReport(state);
    expect(exported.app).toBe('ElektrLab');
    expect(Number.isNaN(Date.parse(exported.exportedAt))).toBe(false);
    expect(parseReport(JSON.stringify(exported))).toEqual(state);
    expect(scoreState(parseReport(JSON.stringify(exported)))).toEqual(scoreState(state));
  });

  it('recomputes correctness and points instead of trusting edited report flags', () => {
    const state = populatedStudent();
    state.theory['1'].correct = false; // The selected answer is in fact correct.
    state.exam['1'].correct = true; // The selected answer is in fact incorrect.
    state.calculations.R.correct = false;
    state.calculations.X.correct = true;
    state.practice['1'].correct = false;
    const report = makeReport(state);
    report.scores = { theory: 20, lab: 20, calculations: 40, exam: 20, total: 100 };
    const restored = parseReport(JSON.stringify(report));
    expect(restored.theory['1'].correct).toBe(true);
    expect(restored.exam['1'].correct).toBe(false);
    expect(restored.calculations.R.correct).toBe(true);
    expect(restored.calculations.X.correct).toBe(false);
    expect(restored.practice['1'].correct).toBe(true);
    const scores = scoreState(restored);
    expect(scores.theory).toBeCloseTo(20 / 12, 12);
    expect(scores).toMatchObject({ lab: 10, calculations: 8, exam: 0, total: 19.7 });
  });

  it('preserves the five numerical answers and their grading across all 30 variants', () => {
    for (const variant of variants) {
      const state = freshState();
      state.name = `Sinov Talabasi ${variant.id}`;
      state.variantId = variant.id;
      const expected = calculateLine(variant.input);
      for (const key of numericKeys) {
        // JSON preserves both scientific notation and comma-form input text.
        const entered = variant.id % 2 ? expected[key].toExponential(7) : expected[key].toPrecision(8).replace('.', ',');
        state.calculations[key] = { entered, correct: true, attempts: 2 };
      }
      const report = makeReport(state);
      const restored = parseReport(JSON.stringify(report));
      expect(restored.calculations).toEqual(state.calculations);
      expect(report.scores.calculations).toBe(40);
      expect(scoreState(restored).calculations).toBe(40);
    }
  });

  it('rejects unavailable variants, questions, choices, calculation keys and lab IDs', () => {
    const cases: ((state: StudentState) => void)[] = [
      state => { state.variantId = 31; },
      state => { state.variantId = null; }, // Existing calculation has no variant.
      state => { state.theory = { '999': { selected: 0, correct: true } }; },
      state => { state.exam = { '1': { selected: 99, correct: true } }; },
      state => { state.calculations = { G: { entered: '0', correct: true, attempts: 1 } }; },
      state => { state.practice = { '999': { entered: '0', correct: true, attempts: 1 } }; },
      state => { state.labTasks = ['imaginary-task']; },
      state => { state.visited = ['/unknown-page']; },
    ];
    cases.forEach(change => {
      const state = populatedStudent();
      change(state);
      expect(() => parseReport(serialize(state))).toThrow();
    });
  });

  it('rejects malformed JSON and unrelated or unsupported file formats', () => {
    expect(() => parseReport('{broken')).toThrow(/JSON/);
    expect(() => parseReport('[]')).toThrow();
    expect(() => parseReport('null')).toThrow();
    expect(() => parseReport(JSON.stringify({ ...makeReport(freshState()), app: 'OtherApp' }))).toThrow();
    expect(() => parseReport(JSON.stringify({ ...makeReport(freshState()), schema: 2 }))).toThrow();
    expect(() => parseReport(JSON.stringify({ ...makeReport(freshState()), student: [] }))).toThrow();
  });

  it('rejects oversized files and malformed numerical answer records', () => {
    expect(() => parseReport(' '.repeat(256_001))).toThrow(/256 KB/);
    const state = populatedStudent();
    state.calculations.R.attempts = -1;
    expect(() => parseReport(serialize(state))).toThrow(/urinishlar/);
    state.calculations.R.attempts = 2;
    state.calculations.R.entered = '1'.repeat(49);
    expect(() => parseReport(serialize(state))).toThrow(/Hisoblash/);
    state.calculations.R.entered = 'NaN';
    expect(parseReport(serialize(state)).calculations.R.correct).toBe(false);
  });

  it('supports an unfinished anonymous session and imports only student fields', () => {
    const state = freshState();
    state.labTasks = ['inspect'];
    state.visited = ['/laboratoriya'];
    const report = { ...makeReport(state), teacher: true, student: { ...state, teacher: true, total: 100 } };
    const restored = parseReport(JSON.stringify(report));
    expect(restored).toEqual(state);
    expect(scoreState(restored).total).toBe(5);
    expect('teacher' in restored).toBe(false);
    expect('total' in restored).toBe(false);
  });
});
