import { describe, expect, it } from 'vitest';
import { assignVariant, freshState, normalizeName, scoreState } from './store';

describe('Student progress and grading',()=>{
  it('starts at zero and does not award marks for views, practice or assignment',()=>{
    const s=freshState();
    s.name='Sinov Talabasi';s.variantId=12;s.visited=['/','/nazariya','/laboratoriya'];
    s.practice={'1':{entered:'10',correct:true,attempts:5}};
    s.variantScheme='pi';s.variantAnalysis=0;
    expect(scoreState(s).total).toBe(0);
  });
  it('weights the four assessed areas 20 + 20 + 40 + 20',()=>{
    const s=freshState();
    for(let i=1;i<=12;i++)s.theory[i]={selected:0,correct:true};
    for(let i=1;i<=10;i++)s.exam[i]={selected:0,correct:true};
    for(const k of ['R','X','I','deltaU','deltaP'])s.calculations[k]={entered:'1',correct:true,attempts:2};
    s.labTasks=['inspect','energize','load','height'];
    expect(scoreState(s)).toEqual({theory:20,lab:20,calculations:40,exam:20,total:100});
  });
  it('grades the latest checked answer rather than accumulating attempt points',()=>{
    const s=freshState();
    s.calculations.R={entered:'10',correct:true,attempts:1};
    expect(scoreState(s).calculations).toBe(8);
    s.calculations.R={entered:'100',correct:false,attempts:2};
    expect(scoreState(s).calculations).toBe(0);
    s.calculations.R={entered:'10',correct:true,attempts:3};
    expect(scoreState(s).calculations).toBe(8);
  });
  it('awards one credit per known task and ignores unrecognized imported IDs',()=>{
    const s=freshState();
    s.labTasks=['inspect','inspect','not-a-task'];
    s.theory={'999':{selected:0,correct:true}};
    s.exam={'made-up':{selected:0,correct:true}};
    s.calculations={'another':{entered:'1',correct:true,attempts:1}};
    expect(scoreState(s)).toEqual({theory:0,lab:5,calculations:0,exam:0,total:5});
  });
  it('does not interpret a nonboolean correct value as earned credit',()=>{
    const s=freshState();
    // Defensive import boundary: truthy JSON text is not an assessed answer.
    s.theory={'1':{selected:0,correct:'true' as unknown as boolean}};
    s.exam={'1':{selected:0,correct:1 as unknown as boolean}};
    s.calculations={'R':{entered:'1',correct:'yes' as unknown as boolean,attempts:1}};
    expect(scoreState(s).total).toBe(0);
  });
});

describe('Individual variant assignment',()=>{
  it('normalizes whitespace, case and Uzbek apostrophe spellings',()=>{
    expect(normalizeName('  Sinov   Talabasi  ')).toBe('Sinov Talabasi');
    expect(assignVariant('  O‘TKIR   O‘G‘LI ')).toBe(assignVariant("o'tkir o'g'li"));
    expect(assignVariant('Sinov Talabasi')).toBe(assignVariant('sinov talabasi'));
  });
  it('assigns a stable variant in the available 1–30 range',()=>{
    const values=Array.from({length:100},(_,i)=>assignVariant(`Talaba ${i+1}`));
    expect(values.every(n=>Number.isInteger(n)&&n>=1&&n<=30)).toBe(true);
    expect(new Set(values).size).toBeGreaterThan(20);
  });
});
