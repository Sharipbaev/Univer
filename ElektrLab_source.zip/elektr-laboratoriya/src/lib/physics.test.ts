import { describe, expect, it } from 'vitest';
import katex from 'katex';
import { DEFAULT_INPUT, calculateLine, compareAnswer, lineModel, mul, sub, validateInput, type LineInput, type ModelKind } from './physics';
import { examQuestions, problems, theorySections, variantAnswers, variants } from '../data/curriculum';

const example:LineInput = {...DEFAULT_INPUT,l:100,r0:0.1,x0:0.2,g0:0,b0:1e-5,U:100,P:30,Q:40,powerMode:'pq'};

describe('Balanced three-phase engineering calculation',()=>{
  it('maintains MW, MVAr, kV, kA and per-phase resistance consistency',()=>{
    const r=calculateLine(example);
    expect(r.R).toBe(10); expect(r.X).toBe(20); expect(r.B).toBe(0.001);
    expect(r.S).toBe(50); expect(r.I).toBeCloseTo(0.2886751345948129,12);
    expect(r.deltaU).toBe(11); expect(r.deltaP).toBeCloseTo(2.5,12);
    expect(r.powerFactor).toBe(0.6); expect(r.chargingQ).toBe(10);
  });
  it('derives reactive power from power factor and distinguishes capacitive load',()=>{
    const pf={...example,P:30,cosPhi:0.8,powerMode:'pf' as const};
    expect(calculateLine(pf).Q).toBeCloseTo(22.5,12);
    const cap=calculateLine({...pf,reactiveKind:'capacitive'});
    expect(cap.Q).toBeCloseTo(-22.5,12);
    expect(cap.deltaU).toBeCloseTo(-1.5,12);
  });
  it('in pq mode derives PF rather than trusting the unrelated PF field',()=>{
    expect(calculateLine({...example,cosPhi:NaN}).powerFactor).toBe(0.6);
    expect(calculateLine({...example,powerMode:'pf',cosPhi:0.8,Q:NaN}).Q).toBeCloseTo(22.5,12);
  });
  it('applies the expected voltage and length scaling for the simplified model',()=>{
    const a=calculateLine(example),b=calculateLine({...example,U:200}),d=calculateLine({...example,l:200});
    expect(b.I).toBeCloseTo(a.I/2,12); expect(b.deltaP).toBeCloseTo(a.deltaP/4,12);
    expect(d.R).toBe(2*a.R); expect(d.deltaU).toBe(2*a.deltaU); expect(d.deltaP).toBeCloseTo(2*a.deltaP,12);
  });
  it('rejects non-finite, zero-voltage, negative resistance and invalid PF inputs',()=>{
    expect(validateInput({...example,U:0}).U).toBeTruthy();
    expect(validateInput({...example,P:NaN}).P).toBeTruthy();
    expect(validateInput({...example,r0:-1}).r0).toBeTruthy();
    expect(validateInput({...example,powerMode:'pf',cosPhi:1.1}).cosPhi).toBeTruthy();
    expect(()=>calculateLine({...example,U:0})).toThrow(RangeError);
    expect(validateInput({...example,l:1000,r0:10,x0:10,g0:0.01,b0:0.1}).b0).toBeTruthy();
    expect(validateInput({...example,U:1e-323}).U).toBeTruthy();
    expect(validateInput({...example,l:1e-323}).l).toBeTruthy();
    expect(()=>lineModel({...example,l:1000,r0:10,x0:10,g0:0.01,b0:0.1},'long')).toThrow(RangeError);
  });
  it('keeps accepted boundary and near-lossless cases finite',()=>{
    const inputs:LineInput[]=[
      {...example,U:0.001,P:5000,Q:-5000,l:1000,r0:10,x0:10,g0:0,b0:0},
      {...example,U:0.001,P:5000,powerMode:'pf',cosPhi:0.1,l:0.001},
      {...example,l:1000,r0:0,x0:10,g0:0,b0:0.1},
      {...example,l:1000,r0:0.001,x0:10,g0:0,b0:0.1},
    ];
    inputs.forEach(input=>{
      expect(validateInput(input)).toEqual({});
      const result=calculateLine(input);
      Object.values(result).filter(value=>typeof value==='number').forEach(value=>expect(Number.isFinite(value)).toBe(true));
      (['r','short','pi','t','long'] as ModelKind[]).forEach(kind=>{
        const model=lineModel(input,kind);
        [model.sendingVoltage,model.sendingCurrent,model.sendingPower,model.reactivePower,model.efficiency].forEach(value=>expect(Number.isFinite(value)).toBe(true));
      });
    });
  });
  it('makes no-load conventions explicit and leaves shunt charging available',()=>{
    const r=calculateLine({...example,P:0,Q:0});
    expect(r.I).toBe(0); expect(r.deltaP).toBe(0);
    expect(r.warnings.some(w=>w.includes('aniqlanmagan'))).toBe(true);
    expect(lineModel({...example,P:0,Q:0},'pi').sendingCurrent).toBeGreaterThan(0);
  });
});

describe('Transmission-line ABCD model',()=>{
  it('implements the two distinct nominal pi and T equations',()=>{
    const pi=lineModel(example,'pi'),t=lineModel(example,'t');
    expect(pi.A.re).toBeCloseTo(0.99,12); expect(pi.A.im).toBeCloseTo(0.005,12);
    expect(pi.B).toEqual({re:10,im:20});
    expect(pi.C.re).toBeCloseTo(-0.0000025,12); expect(pi.C.im).toBeCloseTo(0.000995,12);
    expect(t.C).toEqual({re:0,im:0.001});
    expect(t.B.re).toBeCloseTo(9.9,12); expect(t.B.im).toBeCloseTo(19.925,12);
  });
  it.each<ModelKind>(['r','short','pi','t','long'])('%s is reciprocal: AD − BC = 1',kind=>{
    const m=lineModel(example,kind),d=sub(mul(m.A,m.D),mul(m.B,m.C));
    expect(d.re).toBeCloseTo(1,10); expect(d.im).toBeCloseTo(0,10);
  });
  it('reduces to the series-only network when shunt admittance is zero',()=>{
    const input={...example,g0:0,b0:0};
    const exact=lineModel(input,'long'),short=lineModel(input,'short');
    expect(exact.A).toEqual({re:1,im:0}); expect(exact.B).toEqual(short.B); expect(exact.C).toEqual({re:0,im:0});
    expect(exact.sendingVoltage).toBeCloseTo(short.sendingVoltage,12);
    expect(short.modelLoss).toBeCloseTo(calculateLine(input).deltaP,10);
  });
  it('resolves the zero-series-impedance limit without dividing by zero',()=>{
    const exact=lineModel({...example,r0:0,x0:0},'long');
    expect(exact.A).toEqual({re:1,im:0}); expect(exact.B).toEqual({re:0,im:0});
    expect(exact.C).toEqual({re:0,im:0.001}); expect(exact.sendingVoltage).toBeCloseTo(example.U,10);
  });
  it('matches the analytic lossless long-line solution',()=>{
    const exact=lineModel({...example,r0:0,g0:0},'long');
    const theta=Math.sqrt(20*0.001),zc=Math.sqrt(20/0.001);
    expect(exact.A.re).toBeCloseTo(Math.cos(theta),12);
    expect(exact.B.im).toBeCloseTo(zc*Math.sin(theta),12);
    expect(exact.C.im).toBeCloseTo(Math.sin(theta)/zc,12);
    expect(exact.modelLoss).toBeCloseTo(0,10);
  });
});

describe('Assessment data and numerical checking',()=>{
  it('renders all lesson, variable and problem formulae with KaTeX',()=>{
    const formulae=[...theorySections.map(s=>s.formula),...theorySections.flatMap(s=>s.variables.map(v=>v.symbol)),...problems.map(p=>p.formula)];
    formulae.forEach(formula=>expect(()=>katex.renderToString(formula,{throwOnError:true,strict:'error'})).not.toThrow());
  });
  it('contains the complete curriculum and distinct physically sensible variants',()=>{
    expect(theorySections).toHaveLength(12); expect(variants).toHaveLength(30);
    expect(problems.length).toBeGreaterThanOrEqual(20); expect(examQuestions.length).toBeGreaterThanOrEqual(10);
    expect(new Set(variants.map(v=>JSON.stringify(v.input))).size).toBe(30);
    variants.forEach(v=>{
      expect(validateInput(v.input)).toEqual({});
      const r=variantAnswers[v.id];
      expect(r.deltaUPercent).toBeGreaterThan(0); expect(r.deltaUPercent).toBeLessThan(10);
      expect(r.I).toBeGreaterThan(0); expect(r.lossPercent).toBeLessThan(10);
      expect(r.R).toBeCloseTo(v.input.l*v.input.r0,12);
    });
    [...theorySections.map(s=>s.question),...examQuestions].forEach(q=>{
      expect(q.correct).toBeGreaterThanOrEqual(0); expect(q.correct).toBeLessThan(q.options.length); expect(q.explanation.length).toBeGreaterThan(30);
    });
  });
  it('accepts decimal commas and scientific notation, rejects empty or partly parsed answers',()=>{
    expect(compareAnswer('0,2887',0.288675)).toBe(true);
    expect(compareAnswer('2e-7',2e-7)).toBe(true);
    expect(compareAnswer('2.2e-7',2e-7)).toBe(false);
    expect(compareAnswer('10.2',10)).toBe(false);
    expect(compareAnswer('',0)).toBe(false); expect(compareAnswer('0',0)).toBe(true);
    expect(compareAnswer('10x',10)).toBe(false); expect(compareAnswer('Infinity',10)).toBe(false);
  });
});
