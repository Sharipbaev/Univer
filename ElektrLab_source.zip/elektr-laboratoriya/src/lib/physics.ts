/** Balanced three-phase steady-state teaching models. All R/X/G/B are per phase.
 * Inputs: km, ohm/km, S/km, line-line RMS kV, total three-phase MW/MVAr.
 * Outputs: line-line RMS kV, line current kA, three-phase MW/MVAr.
 */
export interface LineInput {
  l: number; r0: number; x0: number; g0: number; b0: number;
  U: number; P: number; Q: number; cosPhi: number;
  powerMode: 'pq' | 'pf'; reactiveKind: 'inductive' | 'capacitive';
}

export const DEFAULT_INPUT: LineInput = {
  l: 80, r0: 0.12, x0: 0.4, g0: 0, b0: 2.8e-6,
  U: 110, P: 30, Q: 15, cosPhi: 0.9,
  powerMode: 'pf', reactiveKind: 'inductive',
};

export type ModelKind = 'r' | 'short' | 'pi' | 't' | 'long';
export interface Complex { re: number; im: number }
const c = (re: number, im = 0): Complex => ({ re, im });
export const add = (a: Complex, b: Complex): Complex => c(a.re + b.re, a.im + b.im);
export const sub = (a: Complex, b: Complex): Complex => c(a.re - b.re, a.im - b.im);
export const mul = (a: Complex, b: Complex): Complex => c(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
export const scale = (a: Complex, n: number): Complex => c(a.re * n, a.im * n);
export const abs = (a: Complex): number => Math.hypot(a.re, a.im);
export const conj = (a: Complex): Complex => c(a.re, -a.im);
export const div = (a: Complex, b: Complex): Complex => {
  const d = b.re * b.re + b.im * b.im;
  if (d === 0) throw new RangeError('Kompleks sonni nolga bo‘lish mumkin emas.');
  return c((a.re * b.re + a.im * b.im) / d, (a.im * b.re - a.re * b.im) / d);
};
const sqrt = (a: Complex): Complex => {
  const m = abs(a);
  return c(Math.sqrt(Math.max(0, (m + a.re) / 2)), (a.im < 0 ? -1 : 1) * Math.sqrt(Math.max(0, (m - a.re) / 2)));
};
const sinh = (a: Complex): Complex => c(Math.sinh(a.re) * Math.cos(a.im), Math.cosh(a.re) * Math.sin(a.im));
const cosh = (a: Complex): Complex => c(Math.cosh(a.re) * Math.cos(a.im), Math.sinh(a.re) * Math.sin(a.im));
const assertFiniteResult = (values: number[]) => {
  if (!values.every(Number.isFinite)) {
    throw new RangeError('Hisob natijasi sonli chegaradan tashqariga chiqdi. Kuchlanish, uzunlik va o‘tkazuvchanlik birliklarini tekshirib, qiymatlarni kamaytiring.');
  }
};

export function validateInput(input: LineInput): Record<string, string> {
  const errors: Record<string, string> = {};
  const bounds: [keyof LineInput, number, number, string][] = [
    ['l', 0.001, 1000, 'O‘quv modeli uchun uzunlik 0,001–1000 km oralig‘ida bo‘lsin.'],
    ['r0', 0, 10, 'r₀ 0–10 Ω/km oralig‘ida bo‘lsin.'],
    ['x0', 0, 10, 'x₀ 0–10 Ω/km oralig‘ida bo‘lsin.'],
    ['g0', 0, 0.01, 'g₀ 0–0,01 S/km oralig‘ida bo‘lsin.'],
    ['b0', 0, 0.1, 'b₀ 0–0,1 S/km oralig‘ida bo‘lsin.'],
    ['U', 0.001, 1000, 'Kuchlanish 0,001–1000 kV oralig‘ida bo‘lsin; nol bo‘lishi mumkin emas.'],
    ['P', 0, 5000, 'Aktiv quvvat 0–5000 MW oralig‘ida bo‘lsin.'],
  ];
  if (input.powerMode === 'pq') bounds.push(['Q', -5000, 5000, 'Q −5000 dan +5000 MVAr gacha bo‘lsin.']);
  else bounds.push(['cosPhi', Number.MIN_VALUE, 1, 'cosφ 0 dan katta va 1 dan oshmasligi kerak.']);
  for (const [key, min, max, message] of bounds) {
    const value = input[key];
    if (typeof value !== 'number' || !Number.isFinite(value)) errors[key] = 'Maydonni to‘ldiring: chekli son kiriting.';
    else if (value < min || value > max) errors[key] = message;
  }
  if (!['pq', 'pf'].includes(input.powerMode)) errors.powerMode = 'Quvvatni kiritish usulini tanlang.';
  if (!['inductive', 'capacitive'].includes(input.reactiveKind)) errors.reactiveKind = 'Yuklama turini tanlang.';
  if (input.powerMode === 'pf' && Number.isFinite(input.cosPhi) && input.cosPhi > 0 && input.cosPhi < 0.1) {
    errors.cosPhi = 'Ushbu o‘quv modeli uchun cosφ kamida 0,1 bo‘lsin; sof reaktiv yuklama uchun P, Q rejimini tanlang.';
  }
  if (['l','r0','x0','g0','b0'].every(key => Number.isFinite(input[key as keyof LineInput]))) {
    const electricalLength = sqrt(mul(c(input.r0*input.l,input.x0*input.l),c(input.g0*input.l,input.b0*input.l)));
    if (electricalLength.re > 100) errors.b0 = 'Parametrlar kombinatsiyasi o‘quv modelining sonli chegarasidan tashqarida. g₀, b₀ va birliklarni tekshiring.';
  }
  return errors;
}

export function calculateLine(input: LineInput) {
  const errors = validateInput(input);
  if (Object.keys(errors).length) throw new RangeError(Object.values(errors)[0]);
  const { l, r0, x0, g0, b0, U, P } = input;
  const Q = input.powerMode === 'pq' ? input.Q : P * Math.tan(Math.acos(input.cosPhi)) * (input.reactiveKind === 'capacitive' ? -1 : 1);
  const R = r0 * l, X = x0 * l, G = g0 * l, B = b0 * l;
  const S = Math.hypot(P, Q);
  const I = S / (Math.sqrt(3) * U);
  // No-load power factor is undefined. We expose 1 only as the documented
  // computational convention; the warning prevents it being taught as a fact.
  const powerFactor = S > 0 ? P / S : 1;
  const deltaU = (P * R + Q * X) / U;
  const deltaUPercent = 100 * deltaU / U;
  const deltaP = 3 * I * I * R;
  const lossPercent = P > 0 ? 100 * deltaP / P : 0;
  const chargingQ = U * U * B;
  assertFiniteResult([R, X, G, B, Q, S, I, powerFactor, deltaU, deltaUPercent, deltaP, lossPercent, chargingQ]);
  const warnings: string[] = [];
  if (l >= 80) warnings.push('Bu kuchlanish tushuvi va I²R hisobi shunt toklarini hisobga olmaydigan yaqinlashuvdir. π/T yoki uzun liniya modelini ham tekshiring.');
  if (Math.abs(deltaUPercent) > 10) warnings.push('Hisoblangan |ΔU| 10% dan katta. Soddalashtirilgan formula aniqligi pasayadi; kompleks model bilan solishtiring.');
  if (I > 2) warnings.push('Tok 2 kA dan oshdi. Simning ruxsat etilgan toki bu modelda tekshirilmaydi; kesim va issiqlik shartini alohida baholang.');
  if (S === 0) warnings.push('Yuklama yo‘q: cosφ fizik jihatdan aniqlanmagan; ekranda hisoblash kelishuvi sifatida 1 ko‘rsatiladi. Shunt sig‘imi bo‘lsa zaryad toki saqlanadi.');
  if (Q < 0) warnings.push('Q manfiy: sig‘imli yuklama. ΔU manfiy chiqishi qabul tomonida kuchlanish ko‘tarilishini anglatadi.');
  if (P === 0 && Q !== 0) warnings.push('Sof reaktiv yuklama: cosφ = 0. ΔP/P foizi P = 0 bo‘lgani uchun aniqlanmaydi; 0 hisoblash belgisi sifatida ko‘rsatiladi.');
  return { R, X, G, B, Q, I, S, powerFactor, deltaU, deltaUPercent, deltaP, lossPercent, chargingQ, warnings };
}
export type LineResult = ReturnType<typeof calculateLine>;

/** Exact ABCD relationships of the selected model. Receiving-end voltage is
 * the reference phasor. The parameters are per phase; total power is 3VI*.
 * Long-line evaluation uses sinh(sqrt(ZY))/sqrt(ZY), giving the correct
 * limiting result even when either series impedance or shunt admittance is 0.
 */
export function lineModel(input: LineInput, kind: ModelKind) {
  const result = calculateLine(input);
  const Z = c(result.R, kind === 'r' ? 0 : result.X);
  const Y = ['r', 'short'].includes(kind) ? c(0) : c(result.G, result.B);
  const ZY = mul(Z, Y);
  let A = c(1), B = Z, C = c(0), D = c(1);
  if (kind === 'pi' || kind === 't') {
    A = D = add(c(1), scale(ZY, 0.5));
    if (kind === 'pi') C = mul(Y, add(c(1), scale(ZY, 0.25)));
    else { B = mul(Z, add(c(1), scale(ZY, 0.25))); C = Y; }
  } else if (kind === 'long') {
    const theta = sqrt(ZY);
    // Complex Taylor series is more stable near zero and resolves 0/0.
    const factor = abs(theta) < 1e-5
      ? add(add(c(1), scale(ZY, 1 / 6)), scale(mul(ZY, ZY), 1 / 120))
      : div(sinh(theta), theta);
    A = D = cosh(theta);
    B = mul(Z, factor);
    C = mul(Y, factor);
  }
  const Vr = c(input.U / Math.sqrt(3));
  const Ir = c(input.P / (Math.sqrt(3) * input.U), -result.Q / (Math.sqrt(3) * input.U));
  const Vs = add(mul(A, Vr), mul(B, Ir));
  const Is = add(mul(C, Vr), mul(D, Ir));
  const Ss = scale(mul(Vs, conj(Is)), 3);
  const sendingVoltage = Math.sqrt(3) * abs(Vs);
  const sendingCurrent = abs(Is);
  const sendingPower = Ss.re;
  const reactivePower = Ss.im;
  const efficiency = sendingPower > 0 ? 100 * input.P / sendingPower : (input.P === 0 && sendingPower === 0 ? 100 : 0);
  assertFiniteResult([...[A, B, C, D, Vs, Is].flatMap(value => [value.re, value.im]), sendingVoltage, sendingCurrent, sendingPower, reactivePower, efficiency]);
  return { A, B, C, D, Z, Y, Vs, Is, Vr, Ir, sendingVoltage, sendingCurrent, sendingPower, reactivePower, efficiency,
    modelLoss: sendingPower - input.P,
    voltageDifference: sendingVoltage - input.U,
    voltageDifferencePercent: 100 * (sendingVoltage - input.U) / input.U,
  };
}
export type ModelResult = ReturnType<typeof lineModel>;

/** Accept comma or decimal dot, signed values and scientific notation, not
 * partially parsed text such as '12x'. Relative tolerance is 1%; absolute
 * default is tiny enough for S-valued conductances. A UI may supply its
 * display rounding allowance explicitly (e.g. 0.0005 for a 3-decimal field).
 */
export function compareAnswer(raw: string, expected: number, absoluteTolerance = 1e-12): boolean {
  const normalized = raw.trim().replace(',', '.');
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(normalized)) return false;
  const value = Number(normalized);
  if (!Number.isFinite(value) || !Number.isFinite(expected)) return false;
  return Math.abs(value - expected) <= Math.max(Math.abs(expected) * 0.01, absoluteTolerance);
}

export const MODEL_LABELS: Record<ModelKind, string> = {
  r: 'Faqat R', short: 'Qisqa liniya: R–X', pi: 'π-simon model', t: 'T-simon model', long: 'Uzun liniya',
};
