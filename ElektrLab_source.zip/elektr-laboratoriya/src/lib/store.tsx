import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type CheckedAnswer = { entered: string; correct: boolean; attempts: number };
export type ChoiceAnswer = { selected: number; correct: boolean };
export interface StudentState {
  schema: 1;
  name: string;
  variantId: number | null;
  visited: string[];
  theory: Record<string, ChoiceAnswer>;
  exam: Record<string, ChoiceAnswer>;
  calculations: Record<string, CheckedAnswer>;
  practice: Record<string, CheckedAnswer>;
  labTasks: string[];
  variantScheme: string | null;
  variantAnalysis: number | null;
}
export const STORAGE_KEY = 'elektrlab.student.v1';
export const freshState = (): StudentState => ({ schema: 1, name: '', variantId: null, visited: [], theory: {}, exam: {}, calculations: {}, practice: {}, labTasks: [], variantScheme: null, variantAnalysis: null });
export function normalizeName(name: string) { return name.trim().replace(/\s+/g, ' '); }
export function assignVariant(name: string, count = 30) {
  const normalized = normalizeName(name).toLocaleLowerCase('uz').normalize('NFKC').replace(/[‘’ʻʼ`´]/g, "'");
  let hash = 2166136261;
  for (const c of normalized) { hash ^= c.codePointAt(0)!; hash = Math.imul(hash, 16777619); }
  return (hash >>> 0) % count + 1;
}
export function scoreState(state: StudentState) {
  const theory = Array.from({length:12},(_,i)=>String(i+1)).filter(k=>state.theory[k]?.correct===true).length / 12 * 20;
  const lab = ['inspect','energize','load','height'].filter(k=>state.labTasks.includes(k)).length * 5;
  const calculations = ['R', 'X', 'I', 'deltaU', 'deltaP'].filter(k => state.calculations[k]?.correct===true).length * 8;
  const exam = Array.from({length:10},(_,i)=>String(i+1)).filter(k=>state.exam[k]?.correct===true).length * 2;
  return { theory, lab, calculations, exam, total: Math.round((theory + lab + calculations + exam) * 10) / 10 };
}
function loadSaved(): StudentState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return freshState();
    const v = JSON.parse(raw);
    if (v.schema !== 1 || typeof v.name !== 'string') return freshState();
    return { ...freshState(), ...v,
      variantId: Number.isInteger(v.variantId) && v.variantId >= 1 && v.variantId <= 30 ? v.variantId : null,
      visited: Array.isArray(v.visited) ? v.visited.filter((s: unknown) => typeof s === 'string') : [],
      labTasks: Array.isArray(v.labTasks) ? [...new Set<string>(v.labTasks.filter((s: unknown) => ['inspect', 'energize', 'load', 'height'].includes(String(s))))] : [],
      theory: v.theory && typeof v.theory === 'object' ? v.theory : {},
      exam: v.exam && typeof v.exam === 'object' ? v.exam : {},
      calculations: v.calculations && typeof v.calculations === 'object' ? v.calculations : {},
      practice: v.practice && typeof v.practice === 'object' ? v.practice : {}
    };
  } catch { return freshState(); }
}
type StoreValue = {
  state: StudentState;
  update: (updater: (s: StudentState) => StudentState) => void;
  teacher: boolean;
  setTeacher: (v: boolean) => void;
  storageError: boolean;
};
const StoreContext = createContext<StoreValue | null>(null);
export function StudentProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<StudentState>(loadSaved);
  const [teacher, setTeacher] = useState(false);
  const [storageError, setStorageError] = useState(false);
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); setStorageError(false); } catch { setStorageError(true); } }, [state]);
  return <StoreContext.Provider value={{ state, update: setState, teacher, setTeacher, storageError }}>{children}</StoreContext.Provider>;
}
export function useStudent() { const value = useContext(StoreContext); if (!value) throw new Error('StudentProvider kerak'); return value; }

